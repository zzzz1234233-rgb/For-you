import type { Express, Request, Response, NextFunction } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { 
  insertUserSchema, 
  loginUserSchema, 
  rechargeSchema,
  sendGiftSchema,
  createMessageSchema,
  updateProfileSchema,
  insertRoomSchema,
  generateCodeSchema,
  redeemCodeSchema,
  phoneLoginSchema,
  verifyOtpSchema
} from "@shared/schema";
import bcrypt from "bcrypt";
import cookieParser from "cookie-parser";
import { WebSocketServer, WebSocket } from "ws";
import { registerObjectStorageRoutes } from "./replit_integrations/object_storage";

const SESSION_COOKIE_NAME = "session_token";

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {

  app.use(cookieParser());

  // Register Object Storage Routes
  registerObjectStorageRoutes(app);

  // Auth Routes
  app.post("/api/auth/register", async (req, res) => {
    try {
      const parsed = insertUserSchema.safeParse(req.body);
      if (!parsed.success) {
        return res.status(400).json({ error: "بيانات غير صحيحة" });
      }

      const existing = await storage.getUserByUsername(parsed.data.username!);
      if (existing) {
        return res.status(400).json({ error: "اسم المستخدم موجود مسبقاً" });
      }

      const hashedPassword = await bcrypt.hash(parsed.data.password!, 10);
      const user = await storage.createUser({
        ...parsed.data,
        password: hashedPassword,
      });

      const token = await storage.createSession(user.id);
      
      res.cookie(SESSION_COOKIE_NAME, token, {
        httpOnly: true,
        secure: process.env.NODE_ENV === "production",
        sameSite: "strict",
        maxAge: 30 * 24 * 60 * 60 * 1000,
        path: "/",
      });

      const { password, ...safeUser } = user;
      res.json({ user: safeUser });
    } catch (error) {
      res.status(500).json({ error: "حدث خطأ في الخادم" });
    }
  });

  app.post("/api/auth/login", async (req, res) => {
    try {
      const parsed = loginUserSchema.safeParse(req.body);
      if (!parsed.success) {
        return res.status(400).json({ error: "بيانات غير صحيحة" });
      }

      let user = await storage.getUserByUsername(parsed.data.username);
      if (!user) {
        return res.status(401).json({ error: "اسم المستخدم أو كلمة المرور غير صحيحة" });
      }

      if (user.isBanned) {
        return res.status(403).json({ error: "تم حظر هذا الحساب" });
      }

      const validPassword = await bcrypt.compare(parsed.data.password, user.password || '');
      if (!validPassword) {
        return res.status(401).json({ error: "اسم المستخدم أو كلمة المرور غير صحيحة" });
      }

      const ownerEmail = process.env.OWNER_EMAIL || 'shaqawchi_pro@ح';
      if (user.email === ownerEmail || user.username === ownerEmail) {
        if (!user.isOwner || user.role !== 'super_admin' || !user.hasVipFrame) {
          user = await storage.updateUserProfile(user.id, { 
            isOwner: true, 
            role: 'super_admin',
            hasVipFrame: true
          }) || user;
        }
      }

      const token = await storage.createSession(user.id);
      
      res.cookie(SESSION_COOKIE_NAME, token, {
        httpOnly: true,
        secure: process.env.NODE_ENV === "production",
        sameSite: "strict",
        maxAge: 30 * 24 * 60 * 60 * 1000,
        path: "/",
      });

      const { password, ...safeUser } = user;
      res.json({ user: safeUser });
    } catch (error) {
      res.status(500).json({ error: "حدث خطأ في الخادم" });
    }
  });

  app.get("/api/auth/user", async (req, res) => {
    try {
      const token = req.cookies?.[SESSION_COOKIE_NAME];
      if (!token) {
        return res.status(401).json({ error: "غير مصرح" });
      }

      const result = await storage.getSessionByToken(token);
      if (!result) {
        res.clearCookie(SESSION_COOKIE_NAME);
        return res.status(401).json({ error: "جلسة غير صالحة" });
      }

      const { password, ...safeUser } = result.user;
      res.json(safeUser);
    } catch (error) {
      res.status(500).json({ error: "حدث خطأ في الخادم" });
    }
  });

  app.post("/api/logout", async (req, res) => {
    const token = req.cookies?.[SESSION_COOKIE_NAME];
    if (token) {
      await storage.deleteSession(token);
    }
    res.clearCookie(SESSION_COOKIE_NAME, { path: "/" });
    res.json({ success: true });
  });

  // Phone Login Routes
  app.post("/api/auth/phone/send-otp", async (req, res) => {
    try {
      const parsed = phoneLoginSchema.safeParse(req.body);
      if (!parsed.success) {
        return res.status(400).json({ error: "رقم الهاتف غير صحيح" });
      }

      const phone = parsed.data.phone.replace(/\s/g, '');
      
      const code = Math.floor(100000 + Math.random() * 900000).toString();
      
      const expiresAt = new Date(Date.now() + 5 * 60 * 1000);
      
      await storage.createOtpCode(phone, code, expiresAt);
      
      console.log(`[OTP] رمز التحقق لرقم ${phone}: ${code}`);
      
      res.json({ 
        success: true, 
        message: "تم إرسال رمز التحقق"
      });
    } catch (error) {
      console.error("OTP error:", error);
      res.status(500).json({ error: "حدث خطأ في الخادم" });
    }
  });

  app.post("/api/auth/phone/verify", async (req, res) => {
    try {
      const parsed = verifyOtpSchema.safeParse(req.body);
      if (!parsed.success) {
        return res.status(400).json({ error: "بيانات غير صحيحة" });
      }

      const { phone, code } = parsed.data;
      const cleanPhone = phone.replace(/\s/g, '');
      
      const isValid = await storage.verifyOtpCode(cleanPhone, code);
      if (!isValid) {
        return res.status(401).json({ error: "رمز التحقق غير صحيح أو منتهي الصلاحية" });
      }

      const ownerPhone = process.env.OWNER_PHONE || '07801234567';
      const normalizedOwnerPhone = ownerPhone.replace(/\s/g, '');
      const isOwnerPhone = cleanPhone === normalizedOwnerPhone;
      
      let user = await storage.getUserByPhone(cleanPhone);
      
      if (!user) {
        if (isOwnerPhone) {
          const ownerEmail = process.env.OWNER_EMAIL || 'shaqawchi_pro@ح';
          let ownerUser = await storage.getUserByUsername(ownerEmail);
          
          if (ownerUser) {
            await storage.updateUserPhone(ownerUser.id, cleanPhone);
            user = await storage.getUser(ownerUser.id) || ownerUser;
          } else {
            user = await storage.createUser({
              username: ownerEmail,
              displayName: 'شقاوچي برو',
              authProvider: 'phone',
            });
            await storage.updateUserProfile(user.id, {
              isOwner: true,
              role: 'super_admin',
              hasVipFrame: true,
              phone: cleanPhone,
            });
            user = await storage.getUser(user.id) || user;
          }
        } else {
          const timestamp = Date.now().toString(36);
          const username = `phone_${cleanPhone.slice(-6)}_${timestamp}`;
          user = await storage.createUser({
            username,
            displayName: `مستخدم ${cleanPhone.slice(-4)}`,
            authProvider: 'phone',
          });
          await storage.updateUserPhone(user.id, cleanPhone);
          user = await storage.getUser(user.id) || user;
        }
      }
      
      if (isOwnerPhone && user && (!user.isOwner || user.role !== 'super_admin' || !user.hasVipFrame)) {
        user = await storage.updateUserProfile(user.id, {
          isOwner: true,
          role: 'super_admin',
          hasVipFrame: true,
        }) || user;
      }

      if (user.isBanned) {
        return res.status(403).json({ error: "تم حظر هذا الحساب" });
      }

      const token = await storage.createSession(user.id);
      
      res.cookie(SESSION_COOKIE_NAME, token, {
        httpOnly: true,
        secure: process.env.NODE_ENV === "production",
        sameSite: "strict",
        maxAge: 30 * 24 * 60 * 60 * 1000,
        path: "/",
      });

      const { password, ...safeUser } = user;
      res.json({ user: safeUser });
    } catch (error) {
      console.error("Verify OTP error:", error);
      res.status(500).json({ error: "حدث خطأ في الخادم" });
    }
  });

  // Global Search - Users
  app.get("/api/search/users", async (req, res) => {
    try {
      const query = (req.query.q as string) || '';
      if (!query || query.length < 1) {
        return res.json([]);
      }
      const users = await storage.searchUsers(query);
      const safeUsers = users.map(({ password, ...user }) => user);
      res.json(safeUsers);
    } catch (error) {
      res.status(500).json({ error: "حدث خطأ في البحث" });
    }
  });

  // User Routes
  app.get("/api/users/:id", async (req, res) => {
    try {
      const user = await storage.getUser(req.params.id);
      if (!user) {
        return res.status(404).json({ error: "المستخدم غير موجود" });
      }
      const { password, ...safeUser } = user;
      res.json(safeUser);
    } catch (error) {
      res.status(500).json({ error: "حدث خطأ في الخادم" });
    }
  });

  app.patch("/api/users/:id", async (req, res) => {
    try {
      const parsed = updateProfileSchema.safeParse(req.body);
      if (!parsed.success) {
        return res.status(400).json({ error: "بيانات غير صحيحة" });
      }
      const updated = await storage.updateUserProfile(req.params.id, parsed.data);
      if (!updated) {
        return res.status(404).json({ error: "المستخدم غير موجود" });
      }
      const { password, ...safeUser } = updated;
      res.json(safeUser);
    } catch (error) {
      res.status(500).json({ error: "حدث خطأ في الخادم" });
    }
  });

  // Disabled - Recharge is only available through admin panel
  app.post("/api/users/:id/recharge", async (req, res) => {
    return res.status(403).json({ error: "الشحن متاح فقط من خلال لوحة التحكم" });
  });

  // Admin-only recharge endpoint
  app.post("/api/admin/recharge", async (req, res) => {
    try {
      const { adminEmail, targetUserId, amount } = req.body;
      
      // Only owner can use this endpoint
      const ownerEmail = process.env.OWNER_EMAIL;
      if (adminEmail !== ownerEmail) {
        return res.status(403).json({ error: "غير مصرح لك بهذه العملية" });
      }
      
      const parsed = rechargeSchema.safeParse({ amount });
      if (!parsed.success) {
        return res.status(400).json({ error: "بيانات غير صحيحة" });
      }
      
      const updated = await storage.updateUserCoins(targetUserId, parsed.data.amount);
      if (!updated) {
        return res.status(404).json({ error: "المستخدم غير موجود" });
      }
      
      await storage.createTransaction({
        userId: targetUserId,
        amount: parsed.data.amount,
        type: "admin_recharge",
        currency: "coins",
      });

      const { password, ...safeUser } = updated;
      res.json(safeUser);
    } catch (error) {
      res.status(500).json({ error: "حدث خطأ في الخادم" });
    }
  });

  // Get all users for admin panel
  app.get("/api/admin/users", async (req, res) => {
    try {
      const { adminEmail } = req.query;
      const ownerEmail = process.env.OWNER_EMAIL;
      
      if (adminEmail !== ownerEmail) {
        return res.status(403).json({ error: "غير مصرح لك بهذه العملية" });
      }
      
      const allUsers = await storage.getAllUsers();
      res.json(allUsers.map(u => {
        const { password, ...safe } = u;
        return safe;
      }));
    } catch (error) {
      res.status(500).json({ error: "حدث خطأ في الخادم" });
    }
  });

  // Generate random code
  function generateRandomCode(): string {
    const chars = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
    let code = "";
    for (let i = 0; i < 12; i++) {
      if (i > 0 && i % 4 === 0) code += "-";
      code += chars.charAt(Math.floor(Math.random() * chars.length));
    }
    return code;
  }

  // Admin generate gift codes
  app.post("/api/admin/codes/generate", async (req, res) => {
    try {
      const { adminEmail, amount, count = 1 } = req.body;
      const ownerEmail = process.env.OWNER_EMAIL;
      
      if (adminEmail !== ownerEmail) {
        return res.status(403).json({ error: "غير مصرح لك بهذه العملية" });
      }
      
      const parsed = generateCodeSchema.safeParse({ amount, count });
      if (!parsed.success) {
        return res.status(400).json({ error: "بيانات غير صحيحة" });
      }

      const codes = [];
      for (let i = 0; i < parsed.data.count; i++) {
        const code = generateRandomCode();
        const giftCode = await storage.createGiftCode(code, parsed.data.amount);
        codes.push(giftCode);
      }

      res.json({ codes });
    } catch (error) {
      res.status(500).json({ error: "حدث خطأ في الخادم" });
    }
  });

  // Admin get all gift codes
  app.get("/api/admin/codes", async (req, res) => {
    try {
      const { adminEmail } = req.query;
      const ownerEmail = process.env.OWNER_EMAIL;
      
      if (adminEmail !== ownerEmail) {
        return res.status(403).json({ error: "غير مصرح لك بهذه العملية" });
      }
      
      const codes = await storage.getAllGiftCodes();
      res.json(codes);
    } catch (error) {
      res.status(500).json({ error: "حدث خطأ في الخادم" });
    }
  });

  // Redeem gift code (for users)
  app.post("/api/codes/redeem", async (req, res) => {
    try {
      const parsed = redeemCodeSchema.safeParse(req.body);
      if (!parsed.success) {
        return res.status(400).json({ error: "بيانات غير صحيحة" });
      }

      const result = await storage.redeemGiftCode(parsed.data.code, parsed.data.userId);
      if (!result) {
        return res.status(400).json({ error: "الكود غير صالح أو مستخدم مسبقاً" });
      }

      const { password, ...safeUser } = result.user;
      res.json({ 
        success: true, 
        amount: result.giftCode.amount,
        user: safeUser 
      });
    } catch (error) {
      res.status(500).json({ error: "حدث خطأ في الخادم" });
    }
  });

  // Room Routes - Discovery System
  app.get("/api/rooms", async (req, res) => {
    try {
      const roomsList = await storage.getRoomsWithHosts();
      res.json(roomsList);
    } catch (error) {
      res.status(500).json({ error: "حدث خطأ في الخادم" });
    }
  });

  app.post("/api/rooms", async (req, res) => {
    try {
      const parsed = insertRoomSchema.safeParse(req.body);
      if (!parsed.success) {
        return res.status(400).json({ error: "بيانات غير صحيحة" });
      }
      const room = await storage.createRoom(parsed.data);
      res.json(room);
    } catch (error) {
      res.status(500).json({ error: "حدث خطأ في الخادم" });
    }
  });

  app.delete("/api/rooms/:id", async (req, res) => {
    try {
      const roomId = parseInt(req.params.id);
      const hostId = req.query.hostId as string;
      if (!hostId) {
        return res.status(400).json({ error: "معرف المضيف مطلوب" });
      }
      const deleted = await storage.deleteRoom(roomId, hostId);
      if (!deleted) {
        return res.status(403).json({ error: "لا يمكنك حذف هذه الغرفة" });
      }
      res.json({ success: true });
    } catch (error) {
      res.status(500).json({ error: "حدث خطأ في الخادم" });
    }
  });

  app.delete("/api/admin/rooms/all", async (req, res) => {
    try {
      const adminEmail = req.query.email as string;
      const ownerEmail = process.env.OWNER_EMAIL;
      
      if (!adminEmail || adminEmail !== ownerEmail) {
        return res.status(403).json({ error: "غير مصرح لك بهذه العملية" });
      }
      
      const deletedCount = await storage.deleteAllRooms();
      res.json({ success: true, deletedCount, message: `تم حذف ${deletedCount} غرفة` });
    } catch (error) {
      res.status(500).json({ error: "حدث خطأ في الخادم" });
    }
  });

  app.post("/api/admin/users/:id/ban", async (req, res) => {
    try {
      const { adminEmail, banned } = req.body;
      const ownerEmail = process.env.OWNER_EMAIL;
      
      if (adminEmail !== ownerEmail) {
        return res.status(403).json({ error: "غير مصرح لك بهذه العملية" });
      }

      const targetUser = await storage.getUser(req.params.id);
      if (!targetUser) {
        return res.status(404).json({ error: "المستخدم غير موجود" });
      }

      if (targetUser.isOwner || targetUser.role === 'super_admin') {
        return res.status(403).json({ error: "لا يمكن حظر المسؤول الأعلى" });
      }

      const updated = await storage.banUser(req.params.id, banned);
      if (!updated) {
        return res.status(404).json({ error: "المستخدم غير موجود" });
      }

      const { password, ...safeUser } = updated;
      res.json({ success: true, user: safeUser });
    } catch (error) {
      res.status(500).json({ error: "حدث خطأ في الخادم" });
    }
  });

  app.post("/api/admin/rooms/:id/lock", async (req, res) => {
    try {
      const { adminEmail, locked } = req.body;
      const ownerEmail = process.env.OWNER_EMAIL;
      
      if (adminEmail !== ownerEmail) {
        return res.status(403).json({ error: "غير مصرح لك بهذه العملية" });
      }

      const roomId = parseInt(req.params.id);
      const updated = await storage.lockRoom(roomId, locked);
      if (!updated) {
        return res.status(404).json({ error: "الغرفة غير موجودة" });
      }

      res.json({ success: true, room: updated });
    } catch (error) {
      res.status(500).json({ error: "حدث خطأ في الخادم" });
    }
  });

  // Owner-only: Get live statistics
  app.get("/api/admin/stats", async (req, res) => {
    try {
      const adminEmail = req.query.email as string;
      const ownerEmail = process.env.OWNER_EMAIL;
      
      if (adminEmail !== ownerEmail) {
        return res.status(403).json({ error: "غير مصرح لك بهذه العملية" });
      }

      const stats = await storage.getAdminStats();
      res.json(stats);
    } catch (error) {
      res.status(500).json({ error: "حدث خطأ في الخادم" });
    }
  });

  // Owner-only: Send broadcast message
  app.post("/api/admin/broadcast", async (req, res) => {
    try {
      const { adminEmail, message, expiresInMinutes } = req.body;
      const ownerEmail = process.env.OWNER_EMAIL;
      
      if (adminEmail !== ownerEmail) {
        return res.status(403).json({ error: "غير مصرح لك بهذه العملية" });
      }

      if (!message || message.trim().length === 0) {
        return res.status(400).json({ error: "الرسالة مطلوبة" });
      }

      const broadcast = await storage.createBroadcast(message, expiresInMinutes || 60);
      res.json({ success: true, broadcast });
    } catch (error) {
      res.status(500).json({ error: "حدث خطأ في الخادم" });
    }
  });

  // Get active broadcast messages
  app.get("/api/broadcasts/active", async (_req, res) => {
    try {
      const broadcasts = await storage.getActiveBroadcasts();
      res.json(broadcasts);
    } catch (error) {
      res.status(500).json({ error: "حدث خطأ في الخادم" });
    }
  });

  // Owner-only: Dismiss/deactivate broadcast
  app.post("/api/admin/broadcast/:id/dismiss", async (req, res) => {
    try {
      const { adminEmail } = req.body;
      const ownerEmail = process.env.OWNER_EMAIL;
      
      if (adminEmail !== ownerEmail) {
        return res.status(403).json({ error: "غير مصرح لك بهذه العملية" });
      }

      const broadcastId = parseInt(req.params.id);
      const dismissed = await storage.dismissBroadcast(broadcastId);
      res.json({ success: true, dismissed });
    } catch (error) {
      res.status(500).json({ error: "حدث خطأ في الخادم" });
    }
  });

  // Delete Account (GDPR Compliance) - Requires authentication
  app.delete("/api/account/delete", async (req, res) => {
    try {
      const token = req.cookies[SESSION_COOKIE_NAME];
      if (!token) {
        return res.status(401).json({ error: "غير مصرح - يجب تسجيل الدخول" });
      }

      const sessionData = await storage.getSessionByToken(token);
      if (!sessionData) {
        return res.status(401).json({ error: "جلسة غير صالحة" });
      }

      const { userId } = req.body;
      
      // Security: Only allow users to delete their own account
      if (userId !== sessionData.user.id) {
        return res.status(403).json({ error: "غير مصرح لك بحذف هذا الحساب" });
      }

      // Delete user account permanently
      await storage.deleteUser(userId);
      
      res.clearCookie(SESSION_COOKIE_NAME);
      res.json({ success: true, message: "تم حذف الحساب بنجاح" });
    } catch (error) {
      res.status(500).json({ error: "حدث خطأ في الخادم" });
    }
  });

  // Room Password Management
  app.post("/api/rooms/:id/password", async (req, res) => {
    try {
      const roomId = parseInt(req.params.id);
      const { password, userId } = req.body;

      const room = await storage.getRoom(roomId);
      if (!room) {
        return res.status(404).json({ error: "الغرفة غير موجودة" });
      }

      if (room.hostId !== userId) {
        return res.status(403).json({ error: "فقط صاحب الغرفة يمكنه تعيين كلمة المرور" });
      }

      await storage.updateRoomPassword(roomId, password || null);
      res.json({ success: true, hasPassword: !!password });
    } catch (error) {
      res.status(500).json({ error: "حدث خطأ في الخادم" });
    }
  });

  // Verify Room Password
  app.post("/api/rooms/:id/verify-password", async (req, res) => {
    try {
      const roomId = parseInt(req.params.id);
      const { password } = req.body;

      const room = await storage.getRoom(roomId);
      if (!room) {
        return res.status(404).json({ error: "الغرفة غير موجودة" });
      }

      if (!room.password) {
        return res.json({ valid: true, hasPassword: false });
      }

      const valid = room.password === password;
      res.json({ valid, hasPassword: true });
    } catch (error) {
      res.status(500).json({ error: "حدث خطأ في الخادم" });
    }
  });

  app.get("/api/rooms/:id/messages", async (req, res) => {
    try {
      const roomId = parseInt(req.params.id);
      const msgs = await storage.getRoomMessages(roomId);
      res.json(msgs);
    } catch (error) {
      res.status(500).json({ error: "حدث خطأ في الخادم" });
    }
  });

  app.post("/api/rooms/:id/messages", async (req, res) => {
    try {
      const roomId = parseInt(req.params.id);
      const parsed = createMessageSchema.safeParse(req.body);
      if (!parsed.success) {
        return res.status(400).json({ error: "بيانات غير صحيحة" });
      }
      const msg = await storage.createMessage({ 
        roomId, 
        userId: parsed.data.userId, 
        content: parsed.data.content, 
        type: parsed.data.type || "text" 
      });
      res.json(msg);
    } catch (error) {
      res.status(500).json({ error: "حدث خطأ في الخادم" });
    }
  });

  // Gifts Routes
  app.get("/api/gifts", async (req, res) => {
    try {
      const giftsList = await storage.getGifts();
      res.json(giftsList);
    } catch (error) {
      res.status(500).json({ error: "حدث خطأ في الخادم" });
    }
  });

  app.post("/api/gifts/send", async (req, res) => {
    try {
      const parsed = sendGiftSchema.safeParse(req.body);
      if (!parsed.success) {
        return res.status(400).json({ error: "بيانات غير صحيحة" });
      }
      
      const { senderId, receiverId, giftId, price } = parsed.data;
      
      const sender = await storage.getUser(senderId);
      if (!sender || (sender.coins || 0) < price) {
        return res.status(400).json({ error: "رصيد غير كافٍ" });
      }

      await storage.updateUserCoins(senderId, -price);
      
      await storage.createTransaction({
        userId: senderId,
        amount: -price,
        type: "gift_send",
        currency: "coins",
      });

      res.json({ success: true });
    } catch (error) {
      res.status(500).json({ error: "حدث خطأ في الخادم" });
    }
  });

  // WebRTC Signaling Server
  const wss = new WebSocketServer({ server: httpServer, path: "/ws" });
  
  interface RoomParticipant {
    ws: WebSocket;
    oderId: number;
    slotNumber: number;
    displayName: string;
    avatar: string;
    hasVipFrame?: boolean;
    isOwner?: boolean;
    role?: string;
  }
  
  const rooms = new Map<string, Map<number, RoomParticipant>>();
  
  wss.on("connection", (ws: WebSocket) => {
    let currentRoomId: string | null = null;
    let currentUserId: number | null = null;
    let currentSlot: number | null = null;
    
    ws.on("message", (data: Buffer) => {
      try {
        const message = JSON.parse(data.toString());
        
        switch (message.type) {
          case "join-room": {
            const { roomId, userId, slotNumber, displayName, avatar, hasVipFrame, isOwner, role } = message;
            currentRoomId = roomId;
            currentUserId = userId;
            currentSlot = slotNumber;
            
            if (!rooms.has(roomId)) {
              rooms.set(roomId, new Map());
            }
            
            const room = rooms.get(roomId)!;
            room.set(userId, { ws, oderId: userId, slotNumber, displayName, avatar, hasVipFrame, isOwner, role });
            
            // Notify all participants about new user
            room.forEach((participant, pId) => {
              if (participant.ws !== ws && participant.ws.readyState === WebSocket.OPEN) {
                participant.ws.send(JSON.stringify({
                  type: "user-joined",
                  userId,
                  slotNumber,
                  displayName,
                  avatar,
                  hasVipFrame,
                  isOwner,
                  role
                }));
              }
            });
            
            // Send existing participants to new user
            room.forEach((participant, pId) => {
              if (pId !== userId && participant.ws.readyState === WebSocket.OPEN) {
                ws.send(JSON.stringify({
                  type: "existing-user",
                  userId: pId,
                  slotNumber: participant.slotNumber,
                  displayName: participant.displayName,
                  avatar: participant.avatar,
                  hasVipFrame: participant.hasVipFrame,
                  isOwner: participant.isOwner,
                  role: participant.role
                }));
              }
            });
            break;
          }
          
          case "offer": {
            const { targetUserId, sdp, roomId } = message;
            const room = rooms.get(roomId);
            if (room) {
              const target = room.get(targetUserId);
              if (target && target.ws.readyState === WebSocket.OPEN) {
                target.ws.send(JSON.stringify({
                  type: "offer",
                  fromUserId: currentUserId,
                  sdp
                }));
              }
            }
            break;
          }
          
          case "answer": {
            const { targetUserId, sdp, roomId } = message;
            const room = rooms.get(roomId);
            if (room) {
              const target = room.get(targetUserId);
              if (target && target.ws.readyState === WebSocket.OPEN) {
                target.ws.send(JSON.stringify({
                  type: "answer",
                  fromUserId: currentUserId,
                  sdp
                }));
              }
            }
            break;
          }
          
          case "ice-candidate": {
            const { targetUserId, candidate, roomId } = message;
            const room = rooms.get(roomId);
            if (room) {
              const target = room.get(targetUserId);
              if (target && target.ws.readyState === WebSocket.OPEN) {
                target.ws.send(JSON.stringify({
                  type: "ice-candidate",
                  fromUserId: currentUserId,
                  candidate
                }));
              }
            }
            break;
          }
          
          case "leave-room": {
            if (currentRoomId && currentUserId !== null) {
              const room = rooms.get(currentRoomId);
              if (room) {
                room.delete(currentUserId);
                room.forEach((participant) => {
                  if (participant.ws.readyState === WebSocket.OPEN) {
                    participant.ws.send(JSON.stringify({
                      type: "user-left",
                      userId: currentUserId,
                      slotNumber: currentSlot
                    }));
                  }
                });
                if (room.size === 0) {
                  rooms.delete(currentRoomId);
                }
              }
            }
            currentRoomId = null;
            currentUserId = null;
            currentSlot = null;
            break;
          }
          
          case "mute-status": {
            const { isMuted, roomId, userId } = message;
            const room = rooms.get(roomId);
            if (room) {
              room.forEach((participant, pId) => {
                if (pId !== userId && participant.ws.readyState === WebSocket.OPEN) {
                  participant.ws.send(JSON.stringify({
                    type: "mute-status",
                    userId,
                    isMuted
                  }));
                }
              });
            }
            break;
          }
        }
      } catch (err) {
        console.error("WebSocket message error:", err);
      }
    });
    
    ws.on("close", () => {
      if (currentRoomId && currentUserId !== null) {
        const room = rooms.get(currentRoomId);
        if (room) {
          room.delete(currentUserId);
          room.forEach((participant) => {
            if (participant.ws.readyState === WebSocket.OPEN) {
              participant.ws.send(JSON.stringify({
                type: "user-left",
                userId: currentUserId,
                slotNumber: currentSlot
              }));
            }
          });
          if (room.size === 0) {
            rooms.delete(currentRoomId);
          }
        }
      }
    });
  });

  return httpServer;
}
