import { sql } from "drizzle-orm";
import { pgTable, text, varchar, integer, boolean, timestamp, serial } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export * from "./models/auth";

export const users = pgTable("users", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  shortId: serial("short_id").unique(),
  username: text("username").unique(),
  password: text("password"),
  displayName: text("display_name").notNull().default("مستخدم"),
  avatar: text("avatar"),
  email: text("email"),
  phone: text("phone").unique(),
  level: integer("level").default(1),
  coins: integer("coins").default(0),
  diamonds: integer("diamonds").default(0),
  followers: integer("followers").default(0),
  following: integer("following").default(0),
  bio: text("bio"),
  isDeveloper: boolean("is_developer").default(false),
  isOwner: boolean("is_owner").default(false),
  isBanned: boolean("is_banned").default(false),
  role: text("role").default("user"),
  hasVipFrame: boolean("has_vip_frame").default(false),
  status: text("status").default("online"),
  authProvider: text("auth_provider").default("email"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const rooms = pgTable("rooms", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  description: text("description"),
  image: text("image"),
  category: text("category").notNull(),
  hostId: varchar("host_id").references(() => users.id),
  isLive: boolean("is_live").default(true),
  isLocked: boolean("is_locked").default(false),
  password: text("password"),
  listenersCount: integer("listeners_count").default(0),
  tags: text("tags").array(),
  createdAt: timestamp("created_at").defaultNow(),
});

export const messages = pgTable("messages", {
  id: serial("id").primaryKey(),
  roomId: integer("room_id").references(() => rooms.id),
  userId: varchar("user_id").references(() => users.id),
  content: text("content").notNull(),
  type: text("type").default("text"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const gifts = pgTable("gifts", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  icon: text("icon").notNull(),
  price: integer("price").notNull(),
});

export const transactions = pgTable("transactions", {
  id: serial("id").primaryKey(),
  userId: varchar("user_id").references(() => users.id),
  amount: integer("amount").notNull(),
  type: text("type").notNull(),
  currency: text("currency").notNull(),
  createdAt: timestamp("created_at").defaultNow(),
});

export const giftCodes = pgTable("gift_codes", {
  id: serial("id").primaryKey(),
  code: text("code").notNull().unique(),
  amount: integer("amount").notNull(),
  isUsed: boolean("is_used").default(false),
  usedBy: varchar("used_by").references(() => users.id),
  usedAt: timestamp("used_at"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const sessions = pgTable("sessions", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").references(() => users.id).notNull(),
  token: text("token").notNull().unique(),
  expiresAt: timestamp("expires_at").notNull(),
  createdAt: timestamp("created_at").defaultNow(),
});

export const otpCodes = pgTable("otp_codes", {
  id: serial("id").primaryKey(),
  phone: text("phone").notNull(),
  code: text("code").notNull(),
  expiresAt: timestamp("expires_at").notNull(),
  isUsed: boolean("is_used").default(false),
  createdAt: timestamp("created_at").defaultNow(),
});

export const broadcastMessages = pgTable("broadcast_messages", {
  id: serial("id").primaryKey(),
  message: text("message").notNull(),
  sentBy: varchar("sent_by").references(() => users.id),
  isActive: boolean("is_active").default(true),
  expiresAt: timestamp("expires_at"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
  displayName: true,
  avatar: true,
  authProvider: true,
});

export const loginUserSchema = z.object({
  username: z.string().min(1),
  password: z.string().min(1),
});

export const socialLoginSchema = z.object({
  provider: z.enum(["google", "facebook", "phone"]),
  displayName: z.string().optional(),
  providerId: z.string().optional(),
});

export const rechargeSchema = z.object({
  amount: z.number().positive(),
});

export const sendGiftSchema = z.object({
  senderId: z.string(),
  receiverId: z.string(),
  giftId: z.number(),
  price: z.number().positive(),
});

export const createMessageSchema = z.object({
  userId: z.string(),
  content: z.string().min(1),
  type: z.enum(["text", "emoji", "gift"]).optional(),
});

export const updateProfileSchema = z.object({
  displayName: z.string().optional(),
  bio: z.string().optional(),
  avatar: z.string().optional(),
});

export const insertRoomSchema = createInsertSchema(rooms).omit({ id: true, createdAt: true });
export const insertMessageSchema = createInsertSchema(messages).omit({ id: true, createdAt: true });
export const insertGiftSchema = createInsertSchema(gifts).omit({ id: true });
export const insertTransactionSchema = createInsertSchema(transactions).omit({ id: true, createdAt: true });
export const insertGiftCodeSchema = createInsertSchema(giftCodes).omit({ id: true, createdAt: true, isUsed: true, usedBy: true, usedAt: true });

export const generateCodeSchema = z.object({
  amount: z.number().positive(),
  count: z.number().min(1).max(100).default(1),
});

export const redeemCodeSchema = z.object({
  code: z.string().min(1),
  userId: z.string(),
});

export const phoneLoginSchema = z.object({
  phone: z.string().min(10).max(15),
});

export const verifyOtpSchema = z.object({
  phone: z.string().min(10).max(15),
  code: z.string().length(6),
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type OtpCode = typeof otpCodes.$inferSelect;
export type User = typeof users.$inferSelect;
export type Room = typeof rooms.$inferSelect;
export type InsertRoom = z.infer<typeof insertRoomSchema>;
export type Message = typeof messages.$inferSelect;
export type Gift = typeof gifts.$inferSelect;
export type Transaction = typeof transactions.$inferSelect;
export type InsertTransaction = z.infer<typeof insertTransactionSchema>;
export type GiftCode = typeof giftCodes.$inferSelect;
export type InsertGiftCode = z.infer<typeof insertGiftCodeSchema>;
export type Session = typeof sessions.$inferSelect;
