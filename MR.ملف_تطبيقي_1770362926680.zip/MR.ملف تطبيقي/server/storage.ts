import { 
  users, rooms, messages, gifts, transactions, giftCodes, sessions, otpCodes, broadcastMessages,
  type User, type InsertUser, type Room, type InsertRoom, type Message, type Gift, type GiftCode, type Session, type OtpCode
} from "@shared/schema";
import { db } from "./db";
import { eq, desc, and, gt, lt } from "drizzle-orm";
import crypto from "crypto";

export interface IStorage {
  // Users
  getUser(id: string): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  getAllUsers(): Promise<User[]>;
  searchUsers(query: string): Promise<User[]>;
  createUser(user: InsertUser): Promise<User>;
  updateUserCoins(userId: string, amount: number): Promise<User | undefined>;
  updateUserProfile(userId: string, data: Partial<User>): Promise<User | undefined>;
  
  // Rooms
  getRooms(): Promise<Room[]>;
  getRoomsWithHosts(): Promise<(Room & { host: Omit<User, 'password'> | null })[]>;
  getRoom(id: number): Promise<Room | undefined>;
  createRoom(room: InsertRoom): Promise<Room>;
  deleteRoom(id: number, hostId: string): Promise<boolean>;
  deleteAllRooms(): Promise<number>;
  updateRoomPassword(roomId: number, password: string | null): Promise<Room | undefined>;
  
  // User deletion
  deleteUser(userId: string): Promise<boolean>;
  
  // Messages
  getRoomMessages(roomId: number): Promise<Message[]>;
  createMessage(message: { roomId: number; userId: string; content: string; type: string }): Promise<Message>;
  
  // Gifts
  getGifts(): Promise<Gift[]>;
  
  // Transactions
  createTransaction(tx: { userId: string; amount: number; type: string; currency: string }): Promise<void>;
  
  // Gift Codes
  createGiftCode(code: string, amount: number): Promise<GiftCode>;
  getGiftCodeByCode(code: string): Promise<GiftCode | undefined>;
  getAllGiftCodes(): Promise<GiftCode[]>;
  redeemGiftCode(code: string, userId: string): Promise<{ giftCode: GiftCode; user: User } | undefined>;

  // Sessions
  createSession(userId: string): Promise<string>;
  getSessionByToken(token: string): Promise<{ session: Session; user: User } | undefined>;
  deleteSession(token: string): Promise<void>;
  
  // Admin operations
  banUser(userId: string, banned: boolean): Promise<User | undefined>;
  lockRoom(roomId: number, locked: boolean): Promise<Room | undefined>;
  setUserRole(userId: string, role: string): Promise<User | undefined>;
  getAdminStats(): Promise<{ onlineUsers: number; openRooms: number; totalGiftsSent: number }>;
  createBroadcast(message: string, expiresInMinutes: number): Promise<any>;
  getActiveBroadcasts(): Promise<any[]>;
  dismissBroadcast(broadcastId: number): Promise<boolean>;
  
  // Phone auth
  getUserByPhone(phone: string): Promise<User | undefined>;
  updateUserPhone(userId: string, phone: string): Promise<User | undefined>;
  createOtpCode(phone: string, code: string, expiresAt: Date): Promise<OtpCode>;
  verifyOtpCode(phone: string, code: string): Promise<boolean>;
}

export class DatabaseStorage implements IStorage {
  async getUser(id: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user;
  }

  async getAllUsers(): Promise<User[]> {
    return db.select().from(users).orderBy(desc(users.createdAt));
  }

  async searchUsers(query: string): Promise<User[]> {
    const allUsers = await db.select().from(users);
    const lowerQuery = query.toLowerCase().trim();
    
    const filtered = allUsers.filter(user => {
      const matchesId = user.id.toLowerCase() === lowerQuery || user.id.toLowerCase().includes(lowerQuery);
      const matchesShortId = user.shortId?.toString() === query.trim();
      const matchesUsername = user.username?.toLowerCase().includes(lowerQuery);
      const matchesDisplayName = user.displayName?.toLowerCase().includes(lowerQuery);
      return matchesId || matchesShortId || matchesUsername || matchesDisplayName;
    });
    
    // Sort results: owners first, then by exact ID match, then by relevance
    filtered.sort((a, b) => {
      // Owner always first
      if (a.isOwner && !b.isOwner) return -1;
      if (!a.isOwner && b.isOwner) return 1;
      
      // Exact ID match takes priority
      const aExactId = a.id.toLowerCase() === lowerQuery;
      const bExactId = b.id.toLowerCase() === lowerQuery;
      if (aExactId && !bExactId) return -1;
      if (!aExactId && bExactId) return 1;
      
      // Exact username match
      const aExactUsername = a.username?.toLowerCase() === lowerQuery;
      const bExactUsername = b.username?.toLowerCase() === lowerQuery;
      if (aExactUsername && !bExactUsername) return -1;
      if (!aExactUsername && bExactUsername) return 1;
      
      return 0;
    });
    
    return filtered.slice(0, 20);
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const [user] = await db.insert(users).values(insertUser).returning();
    return user;
  }

  async updateUserCoins(userId: string, amount: number): Promise<User | undefined> {
    const user = await this.getUser(userId);
    if (!user) return undefined;
    
    const newCoins = (user.coins || 0) + amount;
    const [updated] = await db.update(users)
      .set({ coins: newCoins })
      .where(eq(users.id, userId))
      .returning();
    return updated;
  }

  async updateUserProfile(userId: string, data: Partial<User>): Promise<User | undefined> {
    const [updated] = await db.update(users)
      .set(data)
      .where(eq(users.id, userId))
      .returning();
    return updated;
  }

  async getRooms(): Promise<Room[]> {
    return db.select().from(rooms).orderBy(desc(rooms.createdAt));
  }

  async getRoomsWithHosts(): Promise<(Room & { host: Omit<User, 'password'> | null })[]> {
    const allRooms = await db.select().from(rooms).orderBy(desc(rooms.createdAt));
    const roomsWithHosts = await Promise.all(
      allRooms.map(async (room) => {
        const host = room.hostId ? await this.getUser(room.hostId) : null;
        if (host) {
          const { password, ...safeHost } = host;
          return { ...room, host: safeHost };
        }
        return { ...room, host: null };
      })
    );
    return roomsWithHosts;
  }

  async getRoom(id: number): Promise<Room | undefined> {
    const [room] = await db.select().from(rooms).where(eq(rooms.id, id));
    return room;
  }

  async createRoom(room: InsertRoom): Promise<Room> {
    const [created] = await db.insert(rooms).values(room).returning();
    return created;
  }

  async deleteRoom(id: number, hostId: string): Promise<boolean> {
    const room = await this.getRoom(id);
    if (!room || room.hostId !== hostId) return false;
    await db.delete(rooms).where(eq(rooms.id, id));
    return true;
  }

  async deleteAllRooms(): Promise<number> {
    const allRooms = await this.getRooms();
    await db.delete(rooms);
    return allRooms.length;
  }

  async getRoomMessages(roomId: number): Promise<Message[]> {
    return db.select().from(messages)
      .where(eq(messages.roomId, roomId))
      .orderBy(messages.createdAt);
  }

  async createMessage(message: { roomId: number; userId: string; content: string; type: string }): Promise<Message> {
    const [created] = await db.insert(messages).values(message).returning();
    return created;
  }

  async getGifts(): Promise<Gift[]> {
    return db.select().from(gifts);
  }

  async createTransaction(tx: { userId: string; amount: number; type: string; currency: string }): Promise<void> {
    await db.insert(transactions).values(tx);
  }

  async createGiftCode(code: string, amount: number): Promise<GiftCode> {
    const [created] = await db.insert(giftCodes).values({ code, amount }).returning();
    return created;
  }

  async getGiftCodeByCode(code: string): Promise<GiftCode | undefined> {
    const [giftCode] = await db.select().from(giftCodes).where(eq(giftCodes.code, code));
    return giftCode;
  }

  async getAllGiftCodes(): Promise<GiftCode[]> {
    return db.select().from(giftCodes).orderBy(desc(giftCodes.createdAt));
  }

  async redeemGiftCode(code: string, userId: string): Promise<{ giftCode: GiftCode; user: User } | undefined> {
    const giftCode = await this.getGiftCodeByCode(code);
    if (!giftCode || giftCode.isUsed) return undefined;

    const user = await this.getUser(userId);
    if (!user) return undefined;

    const [updatedCode] = await db.update(giftCodes)
      .set({ isUsed: true, usedBy: userId, usedAt: new Date() })
      .where(and(eq(giftCodes.code, code), eq(giftCodes.isUsed, false)))
      .returning();

    if (!updatedCode) return undefined;

    const updatedUser = await this.updateUserCoins(userId, giftCode.amount);
    if (!updatedUser) return undefined;

    return { giftCode: updatedCode, user: updatedUser };
  }

  async createSession(userId: string): Promise<string> {
    const token = crypto.randomBytes(32).toString('hex');
    const expiresAt = new Date(Date.now() + 30 * 24 * 60 * 60 * 1000); // 30 days
    
    await db.insert(sessions).values({
      userId,
      token,
      expiresAt,
    });
    
    return token;
  }

  async getSessionByToken(token: string): Promise<{ session: Session; user: User } | undefined> {
    const [result] = await db.select()
      .from(sessions)
      .where(and(
        eq(sessions.token, token),
        gt(sessions.expiresAt, new Date())
      ));
    
    if (!result) return undefined;
    
    const user = await this.getUser(result.userId);
    if (!user) return undefined;
    
    return { session: result, user };
  }

  async deleteSession(token: string): Promise<void> {
    await db.delete(sessions).where(eq(sessions.token, token));
  }

  async banUser(userId: string, banned: boolean): Promise<User | undefined> {
    const [updated] = await db.update(users)
      .set({ isBanned: banned })
      .where(eq(users.id, userId))
      .returning();
    return updated;
  }

  async lockRoom(roomId: number, locked: boolean): Promise<Room | undefined> {
    const [updated] = await db.update(rooms)
      .set({ isLocked: locked })
      .where(eq(rooms.id, roomId))
      .returning();
    return updated;
  }

  async setUserRole(userId: string, role: string): Promise<User | undefined> {
    const [updated] = await db.update(users)
      .set({ role })
      .where(eq(users.id, userId))
      .returning();
    return updated;
  }

  async getUserByPhone(phone: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.phone, phone));
    return user;
  }

  async updateUserPhone(userId: string, phone: string): Promise<User | undefined> {
    const [updated] = await db.update(users)
      .set({ phone })
      .where(eq(users.id, userId))
      .returning();
    return updated;
  }

  async createOtpCode(phone: string, code: string, expiresAt: Date): Promise<OtpCode> {
    await db.delete(otpCodes).where(eq(otpCodes.phone, phone));
    
    const [created] = await db.insert(otpCodes).values({
      phone,
      code,
      expiresAt,
    }).returning();
    return created;
  }

  async verifyOtpCode(phone: string, code: string): Promise<boolean> {
    const [otp] = await db.select()
      .from(otpCodes)
      .where(and(
        eq(otpCodes.phone, phone),
        eq(otpCodes.code, code),
        eq(otpCodes.isUsed, false),
        gt(otpCodes.expiresAt, new Date())
      ));
    
    if (!otp) return false;
    
    await db.update(otpCodes)
      .set({ isUsed: true })
      .where(eq(otpCodes.id, otp.id));
    
    return true;
  }

  async getAdminStats(): Promise<{ onlineUsers: number; openRooms: number; totalGiftsSent: number }> {
    const allUsers = await db.select().from(users).where(eq(users.status, 'online'));
    const onlineUsers = await db.select().from(users).where(eq(users.status, 'online'));
    const openRooms = await db.select().from(rooms).where(eq(rooms.isLive, true));
    const totalGifts = await db.select().from(transactions).where(eq(transactions.type, 'gift'));
    
    return {
      onlineUsers: onlineUsers.length,
      openRooms: openRooms.length,
      totalGiftsSent: totalGifts.length,
    };
    

  async createBroadcast(message: string, expiresInMinutes: number): Promise<any> {
    const expiresAt = new Date(Date.now() + expiresInMinutes * 60 * 1000);
    const [broadcast] = await db.insert(broadcastMessages).values({
      message,
      isActive: true,
      expiresAt,
    }).returning();
    return broadcast;
  }

  async getActiveBroadcasts(): Promise<any[]> {
    return db.select()
      .from(broadcastMessages)
      .where(and(
        eq(broadcastMessages.isActive, true),
        gt(broadcastMessages.expiresAt, new Date())
      ))
      .orderBy(desc(broadcastMessages.createdAt));
  }

  async dismissBroadcast(broadcastId: number): Promise<boolean> {
    const [updated] = await db.update(broadcastMessages)
      .set({ isActive: false })
      .where(eq(broadcastMessages.id, broadcastId))
      .returning();
    return !!updated;
  }

  async updateRoomPassword(roomId: number, password: string | null): Promise<Room | undefined> {
    const [updated] = await db.update(rooms)
      .set({ password, isLocked: !!password })
      .where(eq(rooms.id, roomId))
      .returning();
    return updated;
  }

  async deleteUser(userId: string): Promise<boolean> {
    // Delete related records first
    await db.delete(messages).where(eq(messages.userId, userId));
    await db.delete(transactions).where(eq(transactions.userId, userId));
    await db.delete(sessions).where(eq(sessions.userId, userId));
    await db.delete(rooms).where(eq(rooms.hostId, userId));
    
    // Finally delete the user
    const [deleted] = await db.delete(users).where(eq(users.id, userId)).returning();
    return !!deleted;
  }
}

export const storage = new DatabaseStorage();
