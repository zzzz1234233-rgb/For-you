# Shaqawchiya - Voice Chat Application

## Overview

Shaqawchiya (شقاوچية) is an Arabic voice chat application featuring voice rooms, user profiles, virtual gifts, and social features. The application provides a modern real-time communication platform with support for coins/diamonds economy, user levels, and room-based audio interactions.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript
- **Routing**: Wouter (lightweight router)
- **State Management**: TanStack React Query for server state
- **UI Components**: Shadcn/ui with Radix UI primitives
- **Styling**: Tailwind CSS v4 with custom theme variables
- **Build Tool**: Vite with custom plugins for Replit integration

The frontend follows a component-based architecture with:
- Page components in `client/src/pages/`
- Reusable UI components in `client/src/components/ui/`
- Custom hooks in `client/src/hooks/`
- RTL (right-to-left) layout for Arabic language support

### Backend Architecture
- **Runtime**: Node.js with Express
- **Language**: TypeScript with ESM modules
- **API Style**: REST endpoints under `/api/`
- **Password Hashing**: bcrypt for secure authentication

The server uses a storage abstraction pattern (`IStorage` interface) to separate data access from business logic, making it easier to swap implementations.

### Data Storage
- **ORM**: Drizzle ORM with PostgreSQL dialect
- **Schema Location**: `shared/schema.ts`
- **Migrations**: Managed via `drizzle-kit push`

Database tables include:
- `users` - User accounts with coins, diamonds, levels, and social metrics
- `rooms` - Voice chat rooms with categories and host information
- `messages` - Room messages with types
- `gifts` - Virtual gift items with prices
- `transactions` - Financial transaction records
- `gift_codes` - Recharge codes with amount, used status, and redemption info

### Authentication
- Local username/password authentication with bcrypt hashing
- Client-side session persistence via localStorage
- Schema validation using Zod with drizzle-zod integration
- Owner account system (zzzz1234233@gmail.com) with exclusive admin privileges

### Economy System
- **Gift Codes**: Owner-controlled currency system where only admin can generate recharge codes
- **Code Redemption**: Users redeem codes through the "Shop" to add coins to their balance
- **Admin Panel**: Owner can generate codes, view all codes status, and manage user balances
- **No Free Recharge**: Regular users cannot recharge without valid codes from owner

### Progressive Web App
- Service worker for offline caching (`client/public/sw.js`)
- Web app manifest for installability
- Audio capture permissions for voice features

## External Dependencies

### Database
- PostgreSQL (configured via `DATABASE_URL` environment variable)
- Connection pooling via `pg` package

### Third-Party Libraries
- **UI Framework**: Full Shadcn/ui component library with Radix primitives
- **Form Handling**: React Hook Form with Zod resolvers
- **Date Utilities**: date-fns
- **Session Storage**: connect-pg-simple for PostgreSQL session store

### Replit-Specific Integrations
- `@replit/vite-plugin-runtime-error-modal` - Error overlay in development
- `@replit/vite-plugin-cartographer` - Dev tooling
- `@replit/vite-plugin-dev-banner` - Development environment indicator
- Custom `metaImagesPlugin` for OpenGraph image handling with Replit domains

### Build Configuration
- Vite for frontend bundling to `dist/public`
- esbuild for server bundling to `dist/index.cjs`
- Selective dependency bundling to optimize cold start times