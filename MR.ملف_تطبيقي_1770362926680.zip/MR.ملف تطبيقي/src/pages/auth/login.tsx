import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Crown, Lock, LogIn, Mail, Eye, EyeOff, Phone } from "lucide-react";
import { useLocation } from "wouter";
import { useAuth } from "@/hooks/use-auth";

export default function Login() {
  const [, setLocation] = useLocation();
  const { isAuthenticated, isLoading, login } = useAuth();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (!isLoading && isAuthenticated) {
      setLocation("/");
    }
  }, [isAuthenticated, isLoading, setLocation]);

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setError("");
    setLoading(true);

    try {
      const res = await fetch("/api/auth/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ username: email, password }),
      });

      const data = await res.json();
      
      if (!res.ok) {
        setError(data.error || "حدث خطأ");
        return;
      }

      login(data.user);
      setLocation("/");
    } catch (err) {
      setError("حدث خطأ في الاتصال");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-dvh bg-[#121212] text-white font-cairo flex flex-col p-6 relative overflow-hidden" dir="rtl">
      <div className="absolute top-[-10%] right-[-10%] size-64 bg-orange-600/20 blur-[100px] rounded-full" />
      <div className="absolute bottom-[-10%] left-[-10%] size-64 bg-purple-600/20 blur-[100px] rounded-full" />

      <div className="flex-1 flex flex-col justify-center items-center">
        <div className="size-24 rounded-[32px] bg-gradient-to-br from-purple-500 to-indigo-600 flex items-center justify-center shadow-2xl shadow-purple-500/20 mb-8">
          <Crown className="size-12 text-white" />
        </div>

        <div className="text-center space-y-2 mb-8">
          <h1 className="text-4xl font-black tracking-tight">شقاوچية</h1>
          <p className="text-white/40 font-bold">مرحباً بك مجدداً 👑</p>
        </div>

        <form onSubmit={handleLogin} className="w-full max-w-sm space-y-4 mb-6">
          <div className="relative">
            <Mail className="absolute right-4 top-1/2 -translate-y-1/2 size-5 text-white/40" />
            <Input
              type="text"
              data-testid="input-email"
              placeholder="البريد الإلكتروني أو اسم المستخدم"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className="w-full h-14 bg-white/5 border-white/10 text-white placeholder:text-white/30 rounded-2xl pr-12 text-right"
              required
            />
          </div>

          <div className="relative">
            <Lock className="absolute right-4 top-1/2 -translate-y-1/2 size-5 text-white/40" />
            <Input
              type={showPassword ? "text" : "password"}
              data-testid="input-password"
              placeholder="كلمة المرور"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="w-full h-14 bg-white/5 border-white/10 text-white placeholder:text-white/30 rounded-2xl pr-12 pl-12 text-right"
              required
            />
            <button
              type="button"
              onClick={() => setShowPassword(!showPassword)}
              className="absolute left-4 top-1/2 -translate-y-1/2 text-white/40 hover:text-white/60"
            >
              {showPassword ? <EyeOff className="size-5" /> : <Eye className="size-5" />}
            </button>
          </div>

          {error && (
            <p className="text-red-400 text-sm text-center bg-red-500/10 border border-red-500/20 rounded-xl py-3 px-4">
              {error}
            </p>
          )}

          <Button
            type="submit"
            data-testid="button-login-submit"
            disabled={loading}
            className="w-full h-14 bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 text-white rounded-2xl font-bold flex items-center justify-center gap-3 shadow-xl shadow-purple-500/20"
          >
            <LogIn className="size-5" />
            {loading ? "جاري تسجيل الدخول..." : "تسجيل الدخول"}
          </Button>

          <div className="text-center pt-4">
            <button
              type="button"
              data-testid="link-signup"
              onClick={() => setLocation("/signup")}
              className="text-purple-400 hover:text-purple-300 text-sm font-bold"
            >
              ليس لديك حساب؟ أنشئ حساباً جديداً
            </button>
          </div>

          <div className="relative flex items-center gap-4 pt-4">
            <div className="flex-1 h-px bg-white/10" />
            <span className="text-white/30 text-xs">أو</span>
            <div className="flex-1 h-px bg-white/10" />
          </div>

          <Button
            type="button"
            data-testid="button-phone-login"
            onClick={() => setLocation("/phone-login")}
            className="w-full h-14 bg-white/5 border border-white/10 hover:bg-white/10 text-white rounded-2xl font-bold flex items-center justify-center gap-3"
          >
            <Phone className="size-5 text-green-400" />
            تسجيل الدخول برقم الهاتف
          </Button>
        </form>

        <p className="text-white/30 text-xs text-center max-w-sm">
          بالضغط على تسجيل الدخول، أنت توافق على شروط الاستخدام وسياسة الخصوصية
        </p>
      </div>
    </div>
  );
}
