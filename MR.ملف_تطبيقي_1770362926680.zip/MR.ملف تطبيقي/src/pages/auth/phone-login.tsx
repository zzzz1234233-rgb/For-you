import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Crown, Phone, KeyRound, ArrowLeft, CheckCircle } from "lucide-react";
import { useLocation } from "wouter";
import { useAuth } from "@/hooks/use-auth";

export default function PhoneLogin() {
  const [, setLocation] = useLocation();
  const { isAuthenticated, isLoading, login } = useAuth();
  const [phone, setPhone] = useState("");
  const [otp, setOtp] = useState("");
  const [step, setStep] = useState<"phone" | "otp">("phone");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);
  const [codeSent, setCodeSent] = useState(false);

  useEffect(() => {
    if (!isLoading && isAuthenticated) {
      setLocation("/");
    }
  }, [isAuthenticated, isLoading, setLocation]);

  if (isLoading) {
    return (
      <div className="min-h-dvh bg-[#07070a] flex items-center justify-center">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-purple-500"></div>
      </div>
    );
  }

  const handleSendOtp = async (e: React.FormEvent) => {
    e.preventDefault();
    setError("");
    setLoading(true);

    try {
      const res = await fetch("/api/auth/phone/send-otp", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ phone }),
      });

      const data = await res.json();
      
      if (!res.ok) {
        setError(data.error || "حدث خطأ");
        return;
      }

      setCodeSent(true);
      setStep("otp");
    } catch (err) {
      setError("حدث خطأ في الاتصال");
    } finally {
      setLoading(false);
    }
  };

  const handleVerifyOtp = async (e: React.FormEvent) => {
    e.preventDefault();
    setError("");
    setLoading(true);

    try {
      const res = await fetch("/api/auth/phone/verify", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ phone, code: otp }),
      });

      const data = await res.json();
      
      if (!res.ok) {
        setError(data.error || "حدث خطأ");
        return;
      }

      login(data.user);
      setLocation("/");
    } catch (err) {
      setError("حدث خطأ في الاتصال");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-dvh bg-[#07070a] text-white font-cairo flex flex-col p-6 relative overflow-hidden">
      <div className="absolute top-[-10%] right-[-10%] size-64 bg-green-600/20 blur-[100px] rounded-full" />
      <div className="absolute bottom-[-10%] left-[-10%] size-64 bg-teal-600/20 blur-[100px] rounded-full" />

      <div className="flex-1 flex flex-col justify-center items-center">
        <motion.div 
          initial={{ scale: 0.8, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          className="size-24 rounded-[32px] bg-gradient-to-br from-green-500 to-teal-600 flex items-center justify-center shadow-2xl shadow-green-500/20 mb-8"
        >
          {step === "phone" ? (
            <Phone className="size-12 text-white" />
          ) : (
            <KeyRound className="size-12 text-white" />
          )}
        </motion.div>

        <motion.div 
          initial={{ y: 20, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ delay: 0.1 }}
          className="text-center space-y-2 mb-8"
        >
          <h1 className="text-3xl font-black tracking-tight">
            {step === "phone" ? "تسجيل الدخول" : "رمز التحقق"}
          </h1>
          <p className="text-white/40 font-bold">
            {step === "phone" 
              ? "أدخل رقم هاتفك للمتابعة 📱" 
              : "أدخل رمز التحقق المرسل"}
          </p>
        </motion.div>

        <AnimatePresence mode="wait">
          {step === "phone" ? (
            <motion.form
              key="phone-form"
              initial={{ y: 20, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              exit={{ y: -20, opacity: 0 }}
              transition={{ delay: 0.15 }}
              onSubmit={handleSendOtp}
              className="w-full max-w-sm space-y-4 mb-6"
            >
              <div className="relative">
                <Phone className="absolute right-4 top-1/2 -translate-y-1/2 size-5 text-white/40" />
                <Input
                  type="tel"
                  data-testid="input-phone"
                  placeholder="رقم الهاتف (مثال: 07801234567)"
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                  className="w-full h-14 bg-white/5 border-white/10 text-white placeholder:text-white/30 rounded-2xl pr-12 text-right"
                  dir="ltr"
                  required
                />
              </div>

              {error && (
                <motion.p 
                  initial={{ opacity: 0, y: -10 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="text-red-400 text-sm text-center bg-red-500/10 border border-red-500/20 rounded-xl py-3 px-4"
                >
                  {error}
                </motion.p>
              )}

              <Button
                type="submit"
                data-testid="button-send-otp"
                disabled={loading || phone.length < 10}
                className="w-full h-14 bg-gradient-to-r from-green-600 to-teal-600 hover:from-green-500 hover:to-teal-500 text-white rounded-2xl font-bold flex items-center justify-center gap-3 shadow-xl shadow-green-500/20"
              >
                <Phone className="size-5" />
                {loading ? "جاري الإرسال..." : "إرسال رمز التحقق"}
              </Button>

              <div className="text-center pt-4">
                <button
                  type="button"
                  data-testid="link-email-login"
                  onClick={() => setLocation("/login")}
                  className="text-green-400 hover:text-green-300 text-sm font-bold"
                >
                  تسجيل الدخول بالبريد الإلكتروني
                </button>
              </div>
            </motion.form>
          ) : (
            <motion.form
              key="otp-form"
              initial={{ y: 20, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              exit={{ y: -20, opacity: 0 }}
              transition={{ delay: 0.15 }}
              onSubmit={handleVerifyOtp}
              className="w-full max-w-sm space-y-4 mb-6"
            >
              {codeSent && (
                <motion.div
                  initial={{ opacity: 0, scale: 0.9 }}
                  animate={{ opacity: 1, scale: 1 }}
                  className="bg-green-500/10 border border-green-500/20 rounded-2xl p-4 text-center"
                >
                  <p className="text-green-400 text-sm">تم إرسال رمز التحقق إلى رقم:</p>
                  <p className="text-lg font-bold text-white mt-1" dir="ltr">{phone}</p>
                </motion.div>
              )}

              <div className="relative">
                <KeyRound className="absolute right-4 top-1/2 -translate-y-1/2 size-5 text-white/40" />
                <Input
                  type="text"
                  data-testid="input-otp"
                  placeholder="أدخل رمز التحقق"
                  value={otp}
                  onChange={(e) => setOtp(e.target.value.replace(/\D/g, '').slice(0, 6))}
                  className="w-full h-14 bg-white/5 border-white/10 text-white placeholder:text-white/30 rounded-2xl pr-12 text-center text-2xl tracking-[0.5em] font-bold"
                  dir="ltr"
                  maxLength={6}
                  required
                />
              </div>

              {error && (
                <motion.p 
                  initial={{ opacity: 0, y: -10 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="text-red-400 text-sm text-center bg-red-500/10 border border-red-500/20 rounded-xl py-3 px-4"
                >
                  {error}
                </motion.p>
              )}

              <Button
                type="submit"
                data-testid="button-verify-otp"
                disabled={loading || otp.length !== 6}
                className="w-full h-14 bg-gradient-to-r from-green-600 to-teal-600 hover:from-green-500 hover:to-teal-500 text-white rounded-2xl font-bold flex items-center justify-center gap-3 shadow-xl shadow-green-500/20"
              >
                <CheckCircle className="size-5" />
                {loading ? "جاري التحقق..." : "تأكيد وتسجيل الدخول"}
              </Button>

              <div className="text-center pt-4">
                <button
                  type="button"
                  data-testid="button-back-to-phone"
                  onClick={() => {
                    setStep("phone");
                    setOtp("");
                    setError("");
                    setCodeSent(false);
                  }}
                  className="text-white/50 hover:text-white/70 text-sm font-bold flex items-center justify-center gap-2 mx-auto"
                >
                  <ArrowLeft className="size-4" />
                  تغيير رقم الهاتف
                </button>
              </div>
            </motion.form>
          )}
        </AnimatePresence>

        <motion.p
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.3 }}
          className="text-white/30 text-xs text-center max-w-sm"
        >
          بالضغط على تسجيل الدخول، أنت توافق على شروط الاستخدام وسياسة الخصوصية
        </motion.p>
      </div>
    </div>
  );
}
