import { useState, useEffect } from "react";
import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Crown, User, Lock, UserPlus, Mail, Eye, EyeOff } from "lucide-react";
import { useLocation } from "wouter";
import { useAuth } from "@/hooks/use-auth";

export default function Signup() {
  const [, setLocation] = useLocation();
  const { isAuthenticated, isLoading, login } = useAuth();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [displayName, setDisplayName] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (!isLoading && isAuthenticated) {
      setLocation("/");
    }
  }, [isAuthenticated, isLoading, setLocation]);

  if (isLoading) {
    return (
      <div className="min-h-dvh bg-[#07070a] flex items-center justify-center">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-purple-500"></div>
      </div>
    );
  }

  const handleSignup = async (e: React.FormEvent) => {
    e.preventDefault();
    setError("");

    if (password !== confirmPassword) {
      setError("كلمتا المرور غير متطابقتين");
      return;
    }

    if (password.length < 6) {
      setError("كلمة المرور يجب أن تكون 6 أحرف على الأقل");
      return;
    }

    setLoading(true);

    try {
      const res = await fetch("/api/auth/register", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ 
          username: email, 
          password,
          displayName: displayName || email.split("@")[0],
          email: email.includes("@") ? email : undefined,
        }),
      });

      const data = await res.json();
      
      if (!res.ok) {
        setError(data.error || "حدث خطأ");
        return;
      }

      login(data.user);
      setLocation("/");
    } catch (err) {
      setError("حدث خطأ في الاتصال");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-dvh bg-[#07070a] text-white font-cairo flex flex-col p-6 relative overflow-hidden">
      <div className="absolute top-[-10%] left-[-10%] size-64 bg-indigo-600/20 blur-[100px] rounded-full" />
      <div className="absolute bottom-[-10%] right-[-10%] size-64 bg-purple-600/20 blur-[100px] rounded-full" />

      <div className="flex-1 flex flex-col justify-center items-center">
        <motion.div 
          initial={{ scale: 0.8, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          className="size-20 rounded-[28px] bg-gradient-to-br from-indigo-500 to-purple-600 flex items-center justify-center shadow-2xl shadow-indigo-500/20 mb-6"
        >
          <Crown className="size-10 text-white" />
        </motion.div>

        <motion.div 
          initial={{ y: 20, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ delay: 0.1 }}
          className="text-center space-y-2 mb-6"
        >
          <h1 className="text-3xl font-black tracking-tight">إنشاء حساب</h1>
          <p className="text-white/40 font-bold">انضم إلى عائلة شقاوچية 👑</p>
        </motion.div>

        <motion.form
          initial={{ y: 20, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ delay: 0.15 }}
          onSubmit={handleSignup}
          className="w-full max-w-sm space-y-4 mb-6"
        >
          <div className="relative">
            <User className="absolute right-4 top-1/2 -translate-y-1/2 size-5 text-white/40" />
            <Input
              type="text"
              data-testid="input-display-name"
              placeholder="الاسم المعروض"
              value={displayName}
              onChange={(e) => setDisplayName(e.target.value)}
              className="w-full h-14 bg-white/5 border-white/10 text-white placeholder:text-white/30 rounded-2xl pr-12 text-right"
            />
          </div>

          <div className="relative">
            <Mail className="absolute right-4 top-1/2 -translate-y-1/2 size-5 text-white/40" />
            <Input
              type="text"
              data-testid="input-email"
              placeholder="البريد الإلكتروني أو اسم المستخدم"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className="w-full h-14 bg-white/5 border-white/10 text-white placeholder:text-white/30 rounded-2xl pr-12 text-right"
              required
            />
          </div>

          <div className="relative">
            <Lock className="absolute right-4 top-1/2 -translate-y-1/2 size-5 text-white/40" />
            <Input
              type={showPassword ? "text" : "password"}
              data-testid="input-password"
              placeholder="كلمة المرور"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="w-full h-14 bg-white/5 border-white/10 text-white placeholder:text-white/30 rounded-2xl pr-12 pl-12 text-right"
              required
            />
            <button
              type="button"
              onClick={() => setShowPassword(!showPassword)}
              className="absolute left-4 top-1/2 -translate-y-1/2 text-white/40 hover:text-white/60"
            >
              {showPassword ? <EyeOff className="size-5" /> : <Eye className="size-5" />}
            </button>
          </div>

          <div className="relative">
            <Lock className="absolute right-4 top-1/2 -translate-y-1/2 size-5 text-white/40" />
            <Input
              type={showPassword ? "text" : "password"}
              data-testid="input-confirm-password"
              placeholder="تأكيد كلمة المرور"
              value={confirmPassword}
              onChange={(e) => setConfirmPassword(e.target.value)}
              className="w-full h-14 bg-white/5 border-white/10 text-white placeholder:text-white/30 rounded-2xl pr-12 text-right"
              required
            />
          </div>

          {error && (
            <motion.p 
              initial={{ opacity: 0, y: -10 }}
              animate={{ opacity: 1, y: 0 }}
              className="text-red-400 text-sm text-center bg-red-500/10 border border-red-500/20 rounded-xl py-3 px-4"
            >
              {error}
            </motion.p>
          )}

          <Button
            type="submit"
            data-testid="button-signup-submit"
            disabled={loading}
            className="w-full h-14 bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-500 hover:to-purple-500 text-white rounded-2xl font-bold flex items-center justify-center gap-3 shadow-xl shadow-indigo-500/20"
          >
            <UserPlus className="size-5" />
            {loading ? "جاري إنشاء الحساب..." : "إنشاء حساب"}
          </Button>

          <div className="text-center pt-4">
            <button
              type="button"
              data-testid="link-login"
              onClick={() => setLocation("/login")}
              className="text-indigo-400 hover:text-indigo-300 text-sm font-bold"
            >
              لديك حساب بالفعل؟ سجل دخولك
            </button>
          </div>
        </motion.form>

        <motion.p
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.3 }}
          className="text-white/30 text-xs text-center max-w-sm"
        >
          بإنشاء حساب، أنت توافق على شروط الاستخدام وسياسة الخصوصية
        </motion.p>
      </div>
    </div>
  );
}
