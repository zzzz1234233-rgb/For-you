import { useState } from "react";
import { motion } from "framer-motion";
import { useLocation } from "wouter";
import { useAuth } from "@/hooks/use-auth";
import { useQuery } from "@tanstack/react-query";
import { cn } from "@/lib/utils";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Home, Users, MessageCircle, User, Plus, Crown, Heart } from "lucide-react";

const categories = [
  { id: "all", label: "الكل" },
  { id: "friends", label: "صداقة" },
  { id: "music", label: "موسيقى" },
  { id: "family", label: "عائلة" },
  { id: "games", label: "ألعاب" },
];

const mockRooms = [
  { 
    id: 1, 
    title: "Urjhe", 
    host: "MNTZR", 
    level: 1,
    category: "صداقة",
    gradient: "from-pink-400 via-orange-300 to-yellow-200",
    isLive: true
  },
  { 
    id: 2, 
    title: "نن", 
    host: "MNTZR", 
    level: 1,
    category: "صداقة",
    gradient: "from-gray-200 to-gray-100",
    isLive: true
  },
  { 
    id: 3, 
    title: "سوالف الليل", 
    host: "أبو فهد", 
    level: 5,
    category: "موسيقى",
    gradient: "from-purple-400 via-pink-300 to-blue-300",
    isLive: true
  },
  { 
    id: 4, 
    title: "ليالي السهر", 
    host: "نجمة", 
    level: 3,
    category: "صداقة",
    gradient: "from-teal-300 via-cyan-200 to-blue-200",
    isLive: true
  },
];

export default function HomePage() {
  const [, setLocation] = useLocation();
  const { user, isLoading } = useAuth();
  const [activeCategory, setActiveCategory] = useState("all");

  const { data: dbRooms = [] } = useQuery({
    queryKey: ["/api/rooms"],
    queryFn: async () => {
      const res = await fetch("/api/rooms");
      if (!res.ok) return [];
      return res.json();
    },
  });

  const rooms = dbRooms.length > 0 ? dbRooms : mockRooms;

  if (isLoading) {
    return (
      <div className="min-h-dvh bg-[#121212] flex items-center justify-center">
        <div className="size-10 rounded-full border-4 border-transparent border-t-orange-500 animate-spin"></div>
      </div>
    );
  }

  return (
    <div className="min-h-dvh bg-[#121212] font-cairo flex flex-col" dir="rtl">
      {/* Header */}
      <div className="px-4 py-3 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <button className="p-2 text-white/60">
            <svg className="size-5" viewBox="0 0 24 24" fill="currentColor">
              <path d="M15.41 7.41L14 6l-6 6 6 6 1.41-1.41L10.83 12z"/>
            </svg>
          </button>
          <div className="flex items-center gap-1 bg-[#1e1e1e] rounded-full px-3 py-1.5">
            <span className="text-white text-sm font-bold">0</span>
            <Heart className="size-4 text-yellow-500 fill-yellow-500" />
          </div>
        </div>
        
        <div className="flex items-center gap-3">
          <div className="text-left">
            <p className="text-white/60 text-xs">مرحباً بك</p>
            <p className="text-white font-bold text-sm flex items-center gap-1">
              مستخدم
              <Crown className="size-4 text-yellow-500" />
            </p>
          </div>
          <Avatar className="size-12 border-2 border-orange-500">
            <AvatarImage src={user?.avatar || "https://api.dicebear.com/7.x/avataaars/svg?seed=user"} />
            <AvatarFallback className="bg-orange-500 text-white">
              {user?.username?.charAt(0) || "م"}
            </AvatarFallback>
          </Avatar>
        </div>
      </div>

      {/* Hero Banner */}
      <div className="px-4 mb-4">
        <div className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-purple-600 via-purple-500 to-indigo-600 p-6 min-h-[160px]">
          <div className="absolute inset-0 bg-[url('data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMTAwIiBoZWlnaHQ9IjEwMCIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48ZGVmcz48cGF0dGVybiBpZD0iZ3JpZCIgd2lkdGg9IjIwIiBoZWlnaHQ9IjIwIiBwYXR0ZXJuVW5pdHM9InVzZXJTcGFjZU9uVXNlIj48cGF0aCBkPSJNIDIwIDAgTCAwIDAgMCAyMCIgZmlsbD0ibm9uZSIgc3Ryb2tlPSJyZ2JhKDI1NSwyNTUsMjU1LDAuMSkiIHN0cm9rZS13aWR0aD0iMSIvPjwvcGF0dGVybj48L2RlZnM+PHJlY3QgZmlsbD0idXJsKCNncmlkKSIgd2lkdGg9IjEwMCUiIGhlaWdodD0iMTAwJSIvPjwvc3ZnPg==')] opacity-30"></div>
          <div className="relative z-10 flex flex-col justify-center h-full">
            <h2 className="text-white text-2xl font-black leading-tight">
              انضم إلى أكبر
              <br />
              تجمع صوتي في
              <br />
              العراق
            </h2>
          </div>
        </div>
      </div>

      {/* Category Pills */}
      <div className="px-4 mb-4">
        <div className="flex gap-2 overflow-x-auto pb-2">
          {categories.map((cat) => (
            <button
              key={cat.id}
              onClick={() => setActiveCategory(cat.id)}
              className={cn(
                "px-6 py-2.5 rounded-full text-sm font-bold whitespace-nowrap transition-all",
                activeCategory === cat.id
                  ? "bg-orange-500 text-white"
                  : "bg-[#2a2a2a] text-white/70 hover:bg-[#333]"
              )}
            >
              {cat.label}
            </button>
          ))}
        </div>
      </div>

      {/* Rooms Section */}
      <div className="flex-1 px-4 pb-28">
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-white text-lg font-bold">اكتشف الغرف</h2>
          <button 
            onClick={() => setLocation("/room")}
            className="flex items-center gap-1 text-orange-500 text-sm font-bold"
          >
            <Plus className="size-4" />
            إنشاء غرفة
          </button>
        </div>

        <div className="grid grid-cols-2 gap-3">
          {rooms.map((room: any) => (
            <RoomCard 
              key={room.id} 
              room={room} 
              onClick={() => setLocation("/room")} 
            />
          ))}
        </div>
      </div>

      {/* Bottom Navigation */}
      <div className="fixed bottom-0 left-0 right-0 z-50 bg-[#121212] border-t border-white/5">
        <div className="flex justify-around items-end py-2 pb-4 px-2">
          <NavItem icon={<HomeIcon />} label="الرئيسية" active />
          <NavItem icon={<GridIcon />} label="المنتدى" />
          
          {/* Center Button - غرفتي */}
          <div className="flex flex-col items-center -mt-6">
            <button 
              onClick={() => setLocation("/room")}
              className="bg-orange-500 p-4 rounded-full shadow-lg shadow-orange-500/30"
            >
              <MicIcon className="size-7 text-white" />
            </button>
            <span className="text-white/60 text-[10px] mt-1">غرفتي</span>
          </div>
          
          <NavItem icon={<MessagesIcon />} label="الرسائل" badge="99+" />
          <NavItem icon={<UserIcon />} label="أنا" onClick={() => setLocation("/profile")} />
        </div>
      </div>
    </div>
  );
}

function RoomCard({ room, onClick }: { room: any; onClick: () => void }) {
  return (
    <motion.div
      whileTap={{ scale: 0.97 }}
      onClick={onClick}
      className="relative cursor-pointer rounded-2xl overflow-hidden aspect-[4/5]"
    >
      {/* Gradient Background */}
      <div className={cn(
        "absolute inset-0 bg-gradient-to-br",
        room.gradient || "from-pink-400 via-orange-300 to-yellow-200"
      )}></div>
      
      {/* Content */}
      <div className="relative h-full p-3 flex flex-col">
        {/* Top - LIVE & Category */}
        <div className="flex items-start justify-between">
          {room.isLive && (
            <div className="flex items-center gap-1 bg-red-500 rounded-full px-2 py-0.5">
              <div className="size-1.5 bg-white rounded-full animate-pulse"></div>
              <span className="text-white text-[10px] font-bold">LIVE</span>
            </div>
          )}
          <div className="bg-orange-500 text-white text-[10px] font-bold px-2 py-1 rounded-lg">
            {room.category || "صداقة"}
          </div>
        </div>
        
        {/* Bottom - Host Info */}
        <div className="mt-auto">
          <div className="flex items-center gap-2 mb-1">
            <Avatar className="size-8 border-2 border-white">
              <AvatarImage src={`https://api.dicebear.com/7.x/avataaars/svg?seed=${room.host}`} />
              <AvatarFallback className="bg-gray-500 text-white text-xs">
                {room.host?.charAt(0) || "م"}
              </AvatarFallback>
            </Avatar>
            <span className="text-black/80 text-xs font-bold">{room.host || "مستخدم"}</span>
            <span className="bg-black/20 text-black/80 text-[10px] px-1.5 py-0.5 rounded font-bold">
              Lv.{room.level || 1}
            </span>
          </div>
          <h3 className="text-black font-bold text-base">{room.title}</h3>
        </div>
      </div>
    </motion.div>
  );
}

function NavItem({ icon, label, active = false, onClick, badge }: { 
  icon: React.ReactNode; 
  label: string; 
  active?: boolean; 
  onClick?: () => void;
  badge?: string;
}) {
  return (
    <button onClick={onClick} className="flex flex-col items-center gap-0.5 px-3 relative">
      <div className={cn(active ? "text-orange-500" : "text-white/40")}>
        {icon}
      </div>
      {badge && (
        <div className="absolute -top-1 right-1 bg-red-500 text-white text-[8px] font-bold px-1.5 py-0.5 rounded-full">
          {badge}
        </div>
      )}
      <span className={cn(
        "text-[10px] font-bold",
        active ? "text-orange-500" : "text-white/40"
      )}>{label}</span>
    </button>
  );
}

function HomeIcon() {
  return (
    <svg className="size-6" viewBox="0 0 24 24" fill="currentColor">
      <path d="M10 20v-6h4v6h5v-8h3L12 3 2 12h3v8z"/>
    </svg>
  );
}

function GridIcon() {
  return (
    <svg className="size-6" viewBox="0 0 24 24" fill="currentColor">
      <path d="M4 4h4v4H4V4zm6 0h4v4h-4V4zm6 0h4v4h-4V4zM4 10h4v4H4v-4zm6 0h4v4h-4v-4zm6 0h4v4h-4v-4zM4 16h4v4H4v-4zm6 0h4v4h-4v-4zm6 0h4v4h-4v-4z"/>
    </svg>
  );
}

function MicIcon({ className }: { className?: string }) {
  return (
    <svg className={className} viewBox="0 0 24 24" fill="currentColor">
      <path d="M12 14c1.66 0 3-1.34 3-3V5c0-1.66-1.34-3-3-3S9 3.34 9 5v6c0 1.66 1.34 3 3 3zm-1 1.93c-3.94-.49-7-3.85-7-7.93h2c0 3.31 2.69 6 6 6s6-2.69 6-6h2c0 4.08-3.06 7.44-7 7.93V22h-2v-6.07z"/>
    </svg>
  );
}

function MessagesIcon() {
  return (
    <svg className="size-6" viewBox="0 0 24 24" fill="currentColor">
      <path d="M20 2H4c-1.1 0-2 .9-2 2v18l4-4h14c1.1 0 2-.9 2-2V4c0-1.1-.9-2-2-2zm0 14H6l-2 2V4h16v12z"/>
    </svg>
  );
}

function UserIcon() {
  return (
    <svg className="size-6" viewBox="0 0 24 24" fill="currentColor">
      <path d="M12 12c2.21 0 4-1.79 4-4s-1.79-4-4-4-4 1.79-4 4 1.79 4 4 4zm0 2c-2.67 0-8 1.34-8 4v2h16v-2c0-2.66-5.33-4-8-4z"/>
    </svg>
  );
}
