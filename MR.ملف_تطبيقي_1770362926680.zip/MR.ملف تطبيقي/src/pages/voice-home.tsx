import { useMemo, useState, useEffect, useRef, useCallback } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { useAuth } from "@/hooks/use-auth";
import {
  Bell,
  Crown,
  Eye,
  Hash,
  Heart,
  MessageCircle,
  Mic,
  MicOff,
  Plus,
  Search,
  ShieldCheck,
  Sparkles,
  UserPlus,
  UserMinus,
  Volume2,
  VolumeX,
  Share2,
  Settings,
  Users,
  Power,
  Gift,
  Smile,
  MessageSquare,
  Home,
  MessageCircle as MsgCircle,
  Activity,
  User,
  LayoutGrid,
  Trophy,
  Star,
  Flame,
  Music,
  ChevronLeft,
  Camera,
  Gem,
  Medal,
  Award,
  MapPin,
  Calendar,
  ChevronRight,
  Shield,
  Lock,
  BellRing,
  Smartphone,
  Languages,
  LogOut,
  ChevronDown,
  Wallet,
  CreditCard,
  Zap,
  History,
  Info,
  Send,
  Copy,
  Trash2,
  Phone,
  X,
  Ban,
  UserX,
  Megaphone,
  ScrollText,
  Palette,
  RefreshCw,
  FileText,
  Globe,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { cn } from "@/lib/utils";
import { toast } from "sonner";
import { Switch } from "@/components/ui/switch";

// --- Types ---
type RoomFromApi = {
  id: number;
  title: string;
  description: string | null;
  image: string | null;
  category: string;
  hostId: string | null;
  isLive: boolean | null;
  listenersCount: number | null;
  tags: string[] | null;
  createdAt: string | null;
  host: {
    id: string;
    displayName: string | null;
    level: number | null;
    avatar?: string;
  } | null;
};

type Room = {
  id: string;
  title: string;
  category: string;
  live: boolean;
  listeners: number;
  tags: string[];
  image: string | null;
  host: { id?: string; name: string; displayName?: string; avatar: string; level: number };
  hostId?: string | null;
};

// --- Room Categories ---
const ROOM_CATEGORIES = ["صداقة", "موسيقى", "عائلة", "ألعاب", "سوالف", "شعر"];

// --- Audio Hook ---
function useVoiceChat(isActive: boolean) {
  const [stream, setStream] = useState<MediaStream | null>(null);
  useEffect(() => {
    if (isActive) {
      navigator.mediaDevices.getUserMedia({ audio: true })
        .then(setStream)
        .catch(() => toast.error("فشل الوصول للميكروفون"));
    }
    return () => stream?.getTracks().forEach(t => t.stop());
  }, [isActive]);
  return { stream };
}

// --- Gift Code Shop View ---

function WalletView({ onBack, coins, onAddCoins, isOwner, userId }: { onBack: () => void; coins: number; onAddCoins: (amount: number) => void; isOwner: boolean; userId: string }) {
  const [isAnimating, setIsAnimating] = useState(false);
  const [giftCode, setGiftCode] = useState("");
  const [isRedeeming, setIsRedeeming] = useState(false);

  const handleRedeemCode = async () => {
    if (!giftCode.trim()) {
      toast.error("أدخل كود الشحن");
      return;
    }
    
    setIsRedeeming(true);
    try {
      const res = await fetch("/api/codes/redeem", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ code: giftCode.trim().toUpperCase(), userId })
      });

      if (res.ok) {
        const data = await res.json();
        setIsAnimating(true);
        setTimeout(() => {
          onAddCoins(data.amount);
          setIsAnimating(false);
          setGiftCode("");
          toast.success(`تم شحن ${data.amount.toLocaleString()} كوينز بنجاح! 🎉💎`);
        }, 500);
      } else {
        const error = await res.json();
        toast.error(error.error || "الكود غير صالح أو مستخدم مسبقاً ❌");
      }
    } catch {
      toast.error("حدث خطأ، حاول مرة أخرى");
    } finally {
      setIsRedeeming(false);
    }
  };

  return (
    <motion.div 
      initial={{ x: "100%" }}
      animate={{ x: 0 }}
      exit={{ x: "100%" }}
      className="fixed inset-0 z-[200] bg-black flex flex-col font-cairo overflow-y-auto pb-10"
    >
      <header className="p-4 flex items-center justify-between sticky top-0 bg-black/80 backdrop-blur-xl z-10 border-b border-white/5">
        <Button variant="ghost" size="icon" className="text-white bg-white/5 rounded-2xl" onClick={onBack}>
          <ChevronLeft className="size-6" />
        </Button>
        <h2 className="text-lg font-black text-white">متجر الشحن</h2>
        <Button variant="ghost" size="icon" className="text-white bg-white/5 rounded-2xl">
          <History className="size-5" />
        </Button>
      </header>

      <div className="p-6">
        {/* Balance Card */}
        <div className="relative overflow-hidden rounded-[32px] p-6 bg-gradient-to-br from-gray-800 to-gray-900 shadow-2xl shadow-amber-500/20 mb-8">
          <div className="absolute top-0 right-0 size-40 bg-white/10 rounded-full blur-3xl -mr-10 -mt-10" />
          <div className="relative z-10 flex items-center justify-between">
            <div>
              <div className="text-white/60 text-xs font-bold mb-1">رصيدك الحالي</div>
              <div className="flex items-center gap-2">
                <motion.div
                  animate={isAnimating ? { scale: [1, 1.5, 1], rotate: [0, 20, -20, 0] } : {}}
                  transition={{ duration: 0.5, repeat: isAnimating ? Infinity : 0 }}
                >
                  <Gem className="size-6 text-yellow-400 fill-yellow-400" />
                </motion.div>
                <motion.span 
                  key={coins}
                  initial={{ scale: 1.2, color: "#facc15" }}
                  animate={{ scale: 1, color: "#ffffff" }}
                  className="text-3xl font-black text-white"
                >
                  {coins.toLocaleString()}
                </motion.span>
              </div>
            </div>
            <div className="size-14 rounded-2xl bg-white/10 backdrop-blur-md flex items-center justify-center border border-white/20">
              <Wallet className="size-8 text-white" />
            </div>
          </div>
        </div>

        {/* Gift Code Redemption */}
        <div className="bg-gradient-to-br from-emerald-500/10 to-teal-500/10 border border-emerald-500/20 rounded-3xl p-6 mb-6">
          <div className="flex items-center gap-3 mb-4">
            <div className="size-10 rounded-2xl bg-emerald-500/20 flex items-center justify-center">
              <Gift className="size-5 text-emerald-400" />
            </div>
            <div>
              <h3 className="text-sm font-black text-white">شحن بكود الهدية</h3>
              <p className="text-[10px] text-white/40">أدخل كود الشحن لإضافة الرصيد</p>
            </div>
          </div>
          
          <div className="space-y-4">
            <Input
              value={giftCode}
              onChange={e => setGiftCode(e.target.value.toUpperCase())}
              placeholder="XXXX-XXXX-XXXX"
              className="bg-white/5 border-white/10 text-white rounded-2xl h-14 text-center text-xl font-mono tracking-widest placeholder:text-white/20"
              maxLength={14}
            />
            
            <Button
              onClick={handleRedeemCode}
              disabled={isRedeeming || !giftCode.trim()}
              className="w-full bg-emerald-600 hover:bg-emerald-500 text-white rounded-2xl py-4 font-black text-sm disabled:opacity-50"
            >
              {isRedeeming ? (
                <div className="flex items-center gap-2">
                  <div className="size-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                  جاري التحقق...
                </div>
              ) : (
                "🎁 تفعيل الكود"
              )}
            </Button>
          </div>
        </div>

        {/* Info Section */}
        <div className="bg-white/5 border border-white/5 rounded-2xl p-4 space-y-3">
          <h4 className="text-xs font-bold text-white/60">كيف أحصل على أكواد الشحن؟</h4>
          <div className="space-y-2 text-[11px] text-white/40">
            <p>• يمكنك شراء أكواد الشحن من الموزعين المعتمدين</p>
            <p>• تواصل مع إدارة التطبيق للحصول على أكواد</p>
            <p>• الكود يُستخدم مرة واحدة فقط</p>
          </div>
        </div>
      </div>
    </motion.div>
  );
}

// --- Sub-Settings Views ---

function EditProfileView({ onBack }: { onBack: () => void }) {
  return (
    <motion.div 
      initial={{ x: "100%" }}
      animate={{ x: 0 }}
      exit={{ x: "100%" }}
      className="fixed inset-0 z-[250] bg-black flex flex-col font-cairo"
    >
      <header className="p-4 flex items-center justify-between border-b border-white/5">
        <Button variant="ghost" size="icon" onClick={onBack} className="text-white"><ChevronLeft /></Button>
        <h2 className="text-lg font-black text-white">تعديل الملف الشخصي</h2>
        <Button variant="ghost" onClick={() => { toast.success("تم حفظ التغييرات"); onBack(); }} className="text-amber-400 font-bold">حفظ</Button>
      </header>
      <div className="p-6 space-y-6">
        <div className="flex flex-col items-center gap-4">
          <div className="relative">
            <Avatar className="size-24 border-2 border-amber-500/30">
              <AvatarImage src="https://api.dicebear.com/7.x/avataaars/svg?seed=Me" />
            </Avatar>
            <div className="absolute bottom-0 right-0 size-8 bg-amber-600 rounded-full flex items-center justify-center border-2 border-[#07070a]">
              <Camera className="size-4 text-white" />
            </div>
          </div>
          <span className="text-xs text-white/40">تغيير صورة الملف الشخصي</span>
        </div>
        <div className="space-y-4">
          <div>
            <label className="text-[10px] font-black text-white/40 uppercase mb-2 block">الاسم</label>
            <Input className="bg-white/5 border-white/10 text-white rounded-2xl h-12" defaultValue="مستخدم" />
          </div>
          <div>
            <label className="text-[10px] font-black text-white/40 uppercase mb-2 block">السيرة الذاتية</label>
            <Input className="bg-white/5 border-white/10 text-white rounded-2xl h-12" placeholder="اكتب شيئاً عن نفسك..." />
          </div>
        </div>
      </div>
    </motion.div>
  );
}

function SecurityView({ onBack }: { onBack: () => void }) {
  const { user, logout } = useAuth();
  const [showDeleteConfirm, setShowDeleteConfirm] = useState(false);
  const [isDeleting, setIsDeleting] = useState(false);

  const handleDeleteAccount = async () => {
    if (!user?.id) return;
    
    setIsDeleting(true);
    try {
      const res = await fetch("/api/account/delete", {
        method: "DELETE",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ userId: user.id }),
      });
      
      if (res.ok) {
        toast.success("تم حذف حسابك بنجاح");
        logout();
      } else {
        const data = await res.json();
        toast.error(data.error || "حدث خطأ");
      }
    } catch {
      toast.error("حدث خطأ في الاتصال");
    } finally {
      setIsDeleting(false);
      setShowDeleteConfirm(false);
    }
  };

  return (
    <motion.div 
      initial={{ x: "100%" }}
      animate={{ x: 0 }}
      exit={{ x: "100%" }}
      className="fixed inset-0 z-[250] bg-black flex flex-col font-cairo overflow-y-auto"
    >
      <header className="p-4 flex items-center justify-between border-b border-white/5 sticky top-0 bg-black/90 backdrop-blur-xl z-10">
        <Button variant="ghost" size="icon" onClick={onBack} className="text-white"><ChevronLeft /></Button>
        <h2 className="text-lg font-black text-white">الأمان والخصوصية</h2>
        <div className="size-10" />
      </header>
      <div className="p-6 space-y-6 pb-20">
        {/* Privacy Settings */}
        <div className="bg-white/5 rounded-3xl overflow-hidden border border-white/5">
          <div className="p-4 flex items-center justify-between border-b border-white/5">
            <span className="text-sm font-bold text-white">حساب محمي</span>
            <Switch checked={true} />
          </div>
          <div className="p-4 flex items-center justify-between">
            <span className="text-sm font-bold text-white">إظهار حالة الاتصال</span>
            <Switch checked={true} />
          </div>
        </div>

        {/* Encryption Indicator */}
        <div className="bg-gradient-to-r from-emerald-500/10 to-teal-500/10 rounded-3xl p-5 border border-emerald-500/20">
          <div className="flex items-center gap-3 mb-3">
            <div className="size-10 rounded-xl bg-emerald-500/20 flex items-center justify-center">
              <Shield className="size-5 text-emerald-400" />
            </div>
            <div>
              <h3 className="text-sm font-black text-white">تشفير شامل</h3>
              <p className="text-xs text-emerald-300/70">جميع محادثاتك محمية</p>
            </div>
          </div>
          <div className="space-y-2 text-[11px] text-white/60">
            <div className="flex items-center gap-2">
              <Lock className="size-3 text-emerald-400" />
              <span>الرسائل مشفرة أثناء النقل (TLS/SSL)</span>
            </div>
            <div className="flex items-center gap-2">
              <Shield className="size-3 text-emerald-400" />
              <span>حماية من لقطات الشاشة داخل الغرف</span>
            </div>
            <div className="flex items-center gap-2">
              <Lock className="size-3 text-emerald-400" />
              <span>البيانات مؤمنة على الخوادم</span>
            </div>
          </div>
        </div>

        <button className="w-full p-4 bg-white/5 rounded-3xl text-right text-sm font-bold text-white border border-white/5">تغيير كلمة المرور</button>

        {/* Delete Account Section */}
        <div className="bg-red-500/10 rounded-3xl p-5 border border-red-500/20">
          <div className="flex items-center gap-3 mb-3">
            <div className="size-10 rounded-xl bg-red-500/20 flex items-center justify-center">
              <Trash2 className="size-5 text-red-400" />
            </div>
            <div>
              <h3 className="text-sm font-black text-white">حذف الحساب</h3>
              <p className="text-xs text-red-300/70">إزالة جميع بياناتك نهائياً</p>
            </div>
          </div>
          <p className="text-[11px] text-white/50 mb-4">
            سيؤدي حذف حسابك إلى إزالة جميع بياناتك بشكل دائم، بما في ذلك الرسائل والغرف والعملات. هذا الإجراء لا يمكن التراجع عنه.
          </p>
          <button 
            onClick={() => setShowDeleteConfirm(true)}
            className="w-full p-3 bg-red-500/20 hover:bg-red-500/30 rounded-xl text-sm font-bold text-red-400 transition-colors"
            data-testid="btn-delete-account"
          >
            حذف حسابي نهائياً
          </button>
        </div>
      </div>

      {/* Delete Confirmation Dialog */}
      <AnimatePresence>
        {showDeleteConfirm && (
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-[300] bg-black/80 backdrop-blur-sm flex items-center justify-center p-6"
          >
            <motion.div 
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              className="bg-gradient-to-b from-zinc-900 to-black rounded-3xl p-6 border border-red-500/30 max-w-sm w-full"
            >
              <div className="text-center mb-6">
                <div className="size-16 rounded-full bg-red-500/20 flex items-center justify-center mx-auto mb-4">
                  <Trash2 className="size-8 text-red-400" />
                </div>
                <h3 className="text-lg font-black text-white mb-2">تأكيد حذف الحساب</h3>
                <p className="text-sm text-white/60">هل أنت متأكد من رغبتك في حذف حسابك؟ لا يمكن التراجع عن هذا الإجراء.</p>
              </div>
              <div className="flex gap-3">
                <button 
                  onClick={() => setShowDeleteConfirm(false)}
                  className="flex-1 p-3 bg-white/10 rounded-xl text-white font-bold text-sm"
                  disabled={isDeleting}
                >
                  إلغاء
                </button>
                <button 
                  onClick={handleDeleteAccount}
                  className="flex-1 p-3 bg-red-500 rounded-xl text-white font-bold text-sm"
                  disabled={isDeleting}
                >
                  {isDeleting ? "جاري الحذف..." : "حذف نهائياً"}
                </button>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </motion.div>
  );
}

// --- Private Messages View ---
function PrivateMessagesView({ onBack }: { onBack: () => void }) {
  const [selectedChat, setSelectedChat] = useState<any | null>(null);
  const [message, setMessage] = useState("");
  const [isInCall, setIsInCall] = useState(false);
  const [isMuted, setIsMuted] = useState(false);
  const [callDuration, setCallDuration] = useState(0);

  const mockChats = [
    { id: 1, name: "أحمد العراقي", avatar: "https://api.dicebear.com/7.x/avataaars/svg?seed=ahmed", lastMessage: "مرحباً، كيف حالك؟", time: "منذ 5 دقائق", online: true, unread: 2 },
    { id: 2, name: "فاطمة الزهراء", avatar: "https://api.dicebear.com/7.x/avataaars/svg?seed=fatima", lastMessage: "شكراً على الهدية! 🎁", time: "منذ ساعة", online: true, unread: 0 },
    { id: 3, name: "محمد علي", avatar: "https://api.dicebear.com/7.x/avataaars/svg?seed=mohammed", lastMessage: "هل ستكون في الغرفة الليلة؟", time: "منذ 3 ساعات", online: false, unread: 0 },
    { id: 4, name: "سارة الجميلة", avatar: "https://api.dicebear.com/7.x/avataaars/svg?seed=sara", lastMessage: "صوتك جميل جداً 🎤", time: "أمس", online: false, unread: 1 },
  ];

  const [chatMessages, setChatMessages] = useState<{[key: number]: any[]}>({
    1: [
      { id: 1, text: "مرحباً!", sender: "them", time: "10:30" },
      { id: 2, text: "أهلاً وسهلاً، كيف حالك؟", sender: "me", time: "10:31" },
      { id: 3, text: "مرحباً، كيف حالك؟", sender: "them", time: "10:32" },
    ],
    2: [
      { id: 1, text: "شكراً على الهدية! 🎁", sender: "them", time: "09:15" },
    ],
  });

  useEffect(() => {
    let interval: NodeJS.Timeout;
    if (isInCall) {
      interval = setInterval(() => setCallDuration(prev => prev + 1), 1000);
    }
    return () => clearInterval(interval);
  }, [isInCall]);

  const formatCallDuration = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  const startCall = () => {
    setIsInCall(true);
    setCallDuration(0);
    toast.success("جاري الاتصال...");
  };

  const endCall = () => {
    setIsInCall(false);
    setCallDuration(0);
    toast.info("تم إنهاء المكالمة");
  };

  const sendMessage = () => {
    if (!message.trim() || !selectedChat) return;
    const newMsg = { id: Date.now(), text: message, sender: "me", time: new Date().toLocaleTimeString('ar-EG', { hour: '2-digit', minute: '2-digit' }) };
    setChatMessages(prev => ({
      ...prev,
      [selectedChat.id]: [...(prev[selectedChat.id] || []), newMsg]
    }));
    setMessage("");
  };

  if (selectedChat) {
    return (
      <motion.div 
        initial={{ x: "100%" }}
        animate={{ x: 0 }}
        exit={{ x: "100%" }}
        className="fixed inset-0 z-[260] bg-gradient-to-b from-[#0a0a15] to-black flex flex-col font-cairo"
      >
        {/* Call Overlay */}
        <AnimatePresence>
          {isInCall && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="absolute inset-0 z-50 bg-gradient-to-b from-purple-900/95 to-black/95 backdrop-blur-xl flex flex-col items-center justify-center"
            >
              <div className="relative mb-8">
                <div className="size-32 rounded-full bg-gradient-to-br from-green-400 to-emerald-600 p-1 animate-pulse">
                  <Avatar className="size-full">
                    <AvatarImage src={selectedChat.avatar} />
                  </Avatar>
                </div>
                <div className="absolute -bottom-2 left-1/2 -translate-x-1/2 bg-green-500 px-3 py-1 rounded-full">
                  <span className="text-xs font-bold text-white">متصل</span>
                </div>
              </div>
              <h3 className="text-2xl font-black text-white mb-2">{selectedChat.name}</h3>
              <p className="text-lg text-green-400 font-bold mb-8">{formatCallDuration(callDuration)}</p>
              
              <div className="flex items-center gap-6">
                <button
                  onClick={() => setIsMuted(!isMuted)}
                  className={cn(
                    "size-14 rounded-full flex items-center justify-center transition-all",
                    isMuted ? "bg-rose-500/30 text-rose-400" : "bg-white/10 text-white"
                  )}
                >
                  {isMuted ? <MicOff className="size-6" /> : <Mic className="size-6" />}
                </button>
                <button
                  onClick={endCall}
                  className="size-16 rounded-full bg-rose-500 flex items-center justify-center shadow-lg shadow-rose-500/30"
                >
                  <Phone className="size-7 text-white rotate-[135deg]" />
                </button>
                <button className="size-14 rounded-full bg-white/10 flex items-center justify-center text-white">
                  <Volume2 className="size-6" />
                </button>
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Chat Header */}
        <header className="p-4 flex items-center justify-between border-b border-white/5 bg-black/50 backdrop-blur-xl">
          <div className="flex items-center gap-3">
            <Button variant="ghost" size="icon" onClick={() => setSelectedChat(null)} className="text-white">
              <ChevronRight className="size-5" />
            </Button>
            <div className="relative">
              <Avatar className="size-10 border-2 border-purple-500/50">
                <AvatarImage src={selectedChat.avatar} />
              </Avatar>
              {selectedChat.online && (
                <div className="absolute -bottom-0.5 -right-0.5 size-3 bg-green-500 rounded-full border-2 border-black" />
              )}
            </div>
            <div>
              <h3 className="text-sm font-black text-white">{selectedChat.name}</h3>
              <p className="text-[10px] text-green-400">{selectedChat.online ? "متصل الآن" : "غير متصل"}</p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <Button 
              variant="ghost" 
              size="icon" 
              onClick={startCall}
              className="bg-green-500/20 text-green-400 rounded-full hover:bg-green-500/30"
            >
              <Phone className="size-5" />
            </Button>
          </div>
        </header>

        {/* Messages */}
        <div className="flex-1 overflow-y-auto p-4 space-y-3">
          {(chatMessages[selectedChat.id] || []).map((msg: any) => (
            <div key={msg.id} className={cn("flex", msg.sender === "me" ? "justify-start" : "justify-end")}>
              <div className={cn(
                "max-w-[75%] px-4 py-2.5 rounded-2xl",
                msg.sender === "me" 
                  ? "bg-purple-600 text-white rounded-bl-sm" 
                  : "bg-white/10 text-white rounded-br-sm"
              )}>
                <p className="text-sm">{msg.text}</p>
                <p className="text-[9px] text-white/50 mt-1">{msg.time}</p>
              </div>
            </div>
          ))}
        </div>

        {/* Input */}
        <div className="p-4 border-t border-white/5 bg-black/50 backdrop-blur-xl">
          <div className="flex items-center gap-3">
            <Input
              value={message}
              onChange={(e) => setMessage(e.target.value)}
              onKeyPress={(e) => e.key === "Enter" && sendMessage()}
              placeholder="اكتب رسالة..."
              className="flex-1 bg-white/5 border-white/10 text-white rounded-full h-12 px-5"
            />
            <Button 
              onClick={sendMessage}
              className="size-12 rounded-full bg-purple-600 hover:bg-purple-700"
            >
              <Send className="size-5" />
            </Button>
          </div>
        </div>
      </motion.div>
    );
  }

  return (
    <motion.div 
      initial={{ x: "100%" }}
      animate={{ x: 0 }}
      exit={{ x: "100%" }}
      className="fixed inset-0 z-[250] bg-gradient-to-b from-[#0a0a15] to-black flex flex-col font-cairo"
    >
      <header className="p-4 flex items-center justify-between border-b border-white/5">
        <Button variant="ghost" size="icon" onClick={onBack} className="text-white"><ChevronLeft /></Button>
        <h2 className="text-lg font-black text-white">الرسائل الخاصة</h2>
        <div className="size-10" />
      </header>

      <div className="flex-1 overflow-y-auto">
        {mockChats.map(chat => (
          <div 
            key={chat.id}
            onClick={() => setSelectedChat(chat)}
            className="p-4 flex items-center gap-3 border-b border-white/5 hover:bg-white/5 cursor-pointer transition-colors"
          >
            <div className="relative">
              <Avatar className="size-14 border-2 border-purple-500/30">
                <AvatarImage src={chat.avatar} />
              </Avatar>
              {chat.online && (
                <div className="absolute -bottom-0.5 -right-0.5 size-4 bg-green-500 rounded-full border-2 border-black" />
              )}
            </div>
            <div className="flex-1 min-w-0">
              <div className="flex items-center justify-between mb-1">
                <h3 className="text-sm font-black text-white">{chat.name}</h3>
                <span className="text-[10px] text-white/40">{chat.time}</span>
              </div>
              <p className="text-xs text-white/60 truncate">{chat.lastMessage}</p>
            </div>
            {chat.unread > 0 && (
              <div className="size-6 bg-purple-600 rounded-full flex items-center justify-center">
                <span className="text-[10px] font-bold text-white">{chat.unread}</span>
              </div>
            )}
          </div>
        ))}
      </div>
    </motion.div>
  );
}

// --- Forum View ---
function ForumView({ onBack }: { onBack: () => void }) {
  const [posts, setPosts] = useState([
    { id: 1, user: "أحمد العراقي", avatar: "https://api.dicebear.com/7.x/avataaars/svg?seed=ahmed", content: "مرحباً بالجميع! كيف حالكم اليوم؟ 👋", likes: 24, comments: 5, time: "منذ 10 دقائق", liked: false },
    { id: 2, user: "فاطمة الزهراء", avatar: "https://api.dicebear.com/7.x/avataaars/svg?seed=fatima", content: "الجو جميل اليوم! من يريد الانضمام لغرفتي؟ 🎤✨", likes: 42, comments: 12, time: "منذ ساعة", liked: true },
    { id: 3, user: "محمد علي", avatar: "https://api.dicebear.com/7.x/avataaars/svg?seed=mohammed", content: "شكراً لكل من دعمني في البث الأخير! أنتم الأفضل 🏆❤️", likes: 156, comments: 34, time: "منذ 3 ساعات", liked: false },
    { id: 4, user: "سارة الجميلة", avatar: "https://api.dicebear.com/7.x/avataaars/svg?seed=sara", content: "نصيحة اليوم: كن لطيفاً مع الجميع، فأنت لا تعرف ما يمرون به 🌸", likes: 89, comments: 15, time: "منذ 5 ساعات", liked: false },
  ]);
  const [newPost, setNewPost] = useState("");
  const [showComments, setShowComments] = useState<number | null>(null);

  const handleLike = (postId: number) => {
    setPosts(prev => prev.map(post => 
      post.id === postId 
        ? { ...post, liked: !post.liked, likes: post.liked ? post.likes - 1 : post.likes + 1 }
        : post
    ));
  };

  const handlePost = () => {
    if (!newPost.trim()) return;
    const post = {
      id: Date.now(),
      user: "أنت",
      avatar: "https://api.dicebear.com/7.x/avataaars/svg?seed=me",
      content: newPost,
      likes: 0,
      comments: 0,
      time: "الآن",
      liked: false
    };
    setPosts(prev => [post, ...prev]);
    setNewPost("");
    toast.success("تم نشر المنشور! 🎉");
  };

  return (
    <motion.div 
      initial={{ x: "100%" }}
      animate={{ x: 0 }}
      exit={{ x: "100%" }}
      className="fixed inset-0 z-[250] bg-white flex flex-col font-cairo"
    >
      <header className="p-4 flex items-center justify-between border-b border-gray-200 bg-white sticky top-0 z-10">
        <Button variant="ghost" size="icon" onClick={onBack} className="text-gray-700"><ChevronLeft /></Button>
        <h2 className="text-lg font-black text-gray-900">المنتدى</h2>
        <div className="size-10" />
      </header>

      {/* New Post Input */}
      <div className="p-4 border-b border-gray-100 bg-gray-50">
        <div className="flex gap-3">
          <Avatar className="size-10 border-2 border-amber-500/30">
            <AvatarImage src="https://api.dicebear.com/7.x/avataaars/svg?seed=me" />
          </Avatar>
          <div className="flex-1">
            <textarea
              value={newPost}
              onChange={(e) => setNewPost(e.target.value)}
              placeholder="شارك أفكارك مع الجميع..."
              className="w-full bg-white border border-gray-200 rounded-2xl p-3 text-sm text-gray-900 placeholder:text-gray-400 resize-none h-20 focus:outline-none focus:ring-2 focus:ring-amber-500/50"
            />
            <div className="flex justify-end mt-2">
              <Button 
                onClick={handlePost}
                disabled={!newPost.trim()}
                className="bg-amber-600 hover:bg-amber-700 text-white rounded-full px-6 font-bold disabled:opacity-50"
              >
                نشر
              </Button>
            </div>
          </div>
        </div>
      </div>

      {/* Posts Feed */}
      <div className="flex-1 overflow-y-auto">
        {posts.map(post => (
          <div key={post.id} className="p-4 border-b border-gray-100">
            {/* Post Header */}
            <div className="flex items-center gap-3 mb-3">
              <Avatar className="size-12 border-2 border-amber-500/20">
                <AvatarImage src={post.avatar} />
              </Avatar>
              <div className="flex-1">
                <h3 className="text-sm font-black text-gray-900">{post.user}</h3>
                <p className="text-[10px] text-gray-400">{post.time}</p>
              </div>
            </div>

            {/* Post Content */}
            <p className="text-sm text-gray-800 leading-relaxed mb-4">{post.content}</p>

            {/* Post Actions */}
            <div className="flex items-center gap-6">
              <button 
                onClick={() => handleLike(post.id)}
                className={cn(
                  "flex items-center gap-2 text-sm font-bold transition-colors",
                  post.liked ? "text-rose-500" : "text-gray-400 hover:text-rose-500"
                )}
              >
                <Heart className={cn("size-5", post.liked && "fill-current")} />
                <span>{post.likes}</span>
              </button>
              <button 
                onClick={() => setShowComments(showComments === post.id ? null : post.id)}
                className="flex items-center gap-2 text-sm font-bold text-gray-400 hover:text-amber-500 transition-colors"
              >
                <MessageCircle className="size-5" />
                <span>{post.comments}</span>
              </button>
              <button className="flex items-center gap-2 text-sm font-bold text-gray-400 hover:text-blue-500 transition-colors">
                <Share2 className="size-5" />
              </button>
            </div>

            {/* Comments Section */}
            <AnimatePresence>
              {showComments === post.id && (
                <motion.div
                  initial={{ height: 0, opacity: 0 }}
                  animate={{ height: "auto", opacity: 1 }}
                  exit={{ height: 0, opacity: 0 }}
                  className="mt-4 pt-4 border-t border-gray-100 overflow-hidden"
                >
                  <div className="space-y-3">
                    <div className="flex gap-2 items-start">
                      <Avatar className="size-8">
                        <AvatarImage src="https://api.dicebear.com/7.x/avataaars/svg?seed=user1" />
                      </Avatar>
                      <div className="bg-gray-100 rounded-2xl px-3 py-2 flex-1">
                        <p className="text-xs font-bold text-gray-900">مستخدم</p>
                        <p className="text-xs text-gray-600">رائع جداً! 👏</p>
                      </div>
                    </div>
                    <div className="flex gap-2">
                      <Avatar className="size-8">
                        <AvatarImage src="https://api.dicebear.com/7.x/avataaars/svg?seed=me" />
                      </Avatar>
                      <Input 
                        placeholder="اكتب تعليقاً..."
                        className="flex-1 bg-gray-100 border-0 rounded-full h-8 text-xs"
                      />
                    </div>
                  </div>
                </motion.div>
              )}
            </AnimatePresence>
          </div>
        ))}
      </div>
    </motion.div>
  );
}

// --- Admin Panel View ---

function AdminPanelView({ onBack, userEmail }: { onBack: () => void; userEmail: string }) {
  const [activeTab, setActiveTab] = useState<"codes" | "users" | "rooms">("codes");
  const [users, setUsers] = useState<any[]>([]);
  const [codes, setCodes] = useState<any[]>([]);
  const [rooms, setRooms] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedUser, setSelectedUser] = useState<any | null>(null);
  const [rechargeAmount, setRechargeAmount] = useState("");
  const [codeAmount, setCodeAmount] = useState("");
  const [codeCount, setCodeCount] = useState("1");
  const [isGenerating, setIsGenerating] = useState(false);
  const [generatedCodes, setGeneratedCodes] = useState<any[]>([]);
  const [isDeletingRooms, setIsDeletingRooms] = useState(false);

  useEffect(() => {
    Promise.all([
      fetch(`/api/admin/users?adminEmail=${encodeURIComponent(userEmail)}`).then(r => r.json()),
      fetch(`/api/admin/codes?adminEmail=${encodeURIComponent(userEmail)}`).then(r => r.json()),
      fetch("/api/rooms").then(r => r.json())
    ]).then(([usersData, codesData, roomsData]) => {
      if (Array.isArray(usersData)) setUsers(usersData);
      if (Array.isArray(codesData)) setCodes(codesData);
      if (Array.isArray(roomsData)) setRooms(roomsData);
      setLoading(false);
    }).catch(() => setLoading(false));
  }, [userEmail]);

  const handleDeleteAllRooms = async () => {
    if (!confirm("هل أنت متأكد من حذف جميع الغرف؟ لا يمكن التراجع عن هذا الإجراء!")) return;
    
    setIsDeletingRooms(true);
    try {
      const res = await fetch(`/api/admin/rooms/all?email=${encodeURIComponent(userEmail)}`, {
        method: "DELETE"
      });
      
      if (res.ok) {
        const data = await res.json();
        setRooms([]);
        toast.success(`تم حذف ${data.deletedCount} غرفة بنجاح! 🗑️`);
      } else {
        toast.error("فشل في حذف الغرف");
      }
    } catch {
      toast.error("حدث خطأ");
    } finally {
      setIsDeletingRooms(false);
    }
  };

  const handleGenerateCodes = async () => {
    const amount = parseInt(codeAmount);
    const count = parseInt(codeCount);
    
    if (isNaN(amount) || amount <= 0) {
      toast.error("أدخل قيمة صحيحة للكود");
      return;
    }

    setIsGenerating(true);
    try {
      const res = await fetch("/api/admin/codes/generate", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ adminEmail: userEmail, amount, count: count || 1 })
      });

      if (res.ok) {
        const data = await res.json();
        setGeneratedCodes(data.codes);
        setCodes(prev => [...data.codes, ...prev]);
        toast.success(`تم إنشاء ${data.codes.length} كود بنجاح! 🎉`);
        setCodeAmount("");
        setCodeCount("1");
      } else {
        toast.error("فشل في إنشاء الأكواد");
      }
    } catch {
      toast.error("حدث خطأ");
    } finally {
      setIsGenerating(false);
    }
  };

  const copyCode = (code: string) => {
    navigator.clipboard.writeText(code);
    toast.success("تم نسخ الكود! 📋");
  };

  const handleRecharge = async () => {
    if (!selectedUser || !rechargeAmount) return;
    
    const amount = parseInt(rechargeAmount);
    if (isNaN(amount) || amount <= 0) {
      toast.error("أدخل مبلغ صحيح");
      return;
    }

    try {
      const res = await fetch("/api/admin/recharge", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          adminEmail: userEmail,
          targetUserId: selectedUser.id,
          amount
        })
      });

      if (res.ok) {
        const updated = await res.json();
        setUsers(prev => prev.map(u => u.id === updated.id ? updated : u));
        toast.success(`تم شحن ${amount} كوينز لـ ${selectedUser.displayName} ✅`);
        setSelectedUser(null);
        setRechargeAmount("");
      } else {
        toast.error("فشل في الشحن");
      }
    } catch {
      toast.error("حدث خطأ");
    }
  };

  return (
    <motion.div 
      initial={{ x: "100%" }}
      animate={{ x: 0 }}
      exit={{ x: "100%" }}
      className="fixed inset-0 z-[250] bg-black flex flex-col font-cairo overflow-y-auto pb-10"
    >
      <header className="p-4 flex items-center justify-between sticky top-0 bg-black/80 backdrop-blur-xl z-10 border-b border-white/5">
        <Button variant="ghost" size="icon" className="text-white bg-white/5 rounded-2xl" onClick={onBack}>
          <ChevronLeft className="size-6" />
        </Button>
        <h2 className="text-lg font-black text-white">👑 لوحة تحكم المالك</h2>
        <div className="size-10" />
      </header>

      {/* Tabs */}
      <div className="px-6 pt-4">
        <div className="flex gap-2 bg-white/5 rounded-2xl p-1">
          <button
            onClick={() => setActiveTab("codes")}
            className={cn(
              "flex-1 py-3 rounded-xl text-xs font-bold transition-all",
              activeTab === "codes" ? "bg-emerald-600 text-white" : "text-white/60"
            )}
          >
            🎁 الأكواد
          </button>
          <button
            onClick={() => setActiveTab("users")}
            className={cn(
              "flex-1 py-3 rounded-xl text-xs font-bold transition-all",
              activeTab === "users" ? "bg-amber-600 text-white" : "text-white/60"
            )}
          >
            👥 المستخدمين
          </button>
          <button
            onClick={() => setActiveTab("rooms")}
            className={cn(
              "flex-1 py-3 rounded-xl text-xs font-bold transition-all",
              activeTab === "rooms" ? "bg-red-600 text-white" : "text-white/60"
            )}
          >
            🏠 الغرف
          </button>
        </div>
      </div>

      <div className="p-6 space-y-6">
        {activeTab === "codes" && (
          <>
            {/* Generate Codes Section */}
            <div className="bg-gradient-to-br from-emerald-500/10 to-teal-500/10 border border-emerald-500/20 rounded-3xl p-6">
              <div className="flex items-center gap-3 mb-4">
                <div className="size-10 rounded-2xl bg-emerald-500/20 flex items-center justify-center">
                  <Gift className="size-5 text-emerald-400" />
                </div>
                <div>
                  <h3 className="text-sm font-black text-white">إنشاء أكواد شحن جديدة</h3>
                  <p className="text-[10px] text-white/40">أنشئ أكواد لبيعها للمستخدمين</p>
                </div>
              </div>

              <div className="space-y-4">
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="text-[10px] font-black text-white/40 uppercase mb-2 block">قيمة الكود</label>
                    <Input
                      type="number"
                      value={codeAmount}
                      onChange={e => setCodeAmount(e.target.value)}
                      placeholder="مثال: 1000"
                      className="bg-white/5 border-white/10 text-white rounded-xl h-12 text-center"
                    />
                  </div>
                  <div>
                    <label className="text-[10px] font-black text-white/40 uppercase mb-2 block">عدد الأكواد</label>
                    <Input
                      type="number"
                      value={codeCount}
                      onChange={e => setCodeCount(e.target.value)}
                      placeholder="1"
                      min="1"
                      max="100"
                      className="bg-white/5 border-white/10 text-white rounded-xl h-12 text-center"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-4 gap-2">
                  {[100, 500, 1000, 5000].map(amt => (
                    <button
                      key={amt}
                      onClick={() => setCodeAmount(amt.toString())}
                      className="bg-white/5 hover:bg-white/10 border border-white/10 rounded-xl py-2 text-xs font-bold text-white transition-all"
                    >
                      {amt.toLocaleString()}
                    </button>
                  ))}
                </div>

                <Button
                  onClick={handleGenerateCodes}
                  disabled={isGenerating || !codeAmount}
                  className="w-full bg-emerald-600 hover:bg-emerald-500 text-white rounded-2xl py-4 font-black"
                >
                  {isGenerating ? "جاري الإنشاء..." : "🎫 إنشاء الأكواد"}
                </Button>
              </div>
            </div>

            {/* Generated Codes Preview */}
            {generatedCodes.length > 0 && (
              <div className="bg-yellow-500/10 border border-yellow-500/20 rounded-2xl p-4">
                <h4 className="text-sm font-bold text-yellow-400 mb-3">✨ الأكواد الجديدة</h4>
                <div className="space-y-2">
                  {generatedCodes.map(code => (
                    <div
                      key={code.id}
                      onClick={() => copyCode(code.code)}
                      className="bg-black/30 rounded-xl p-3 flex items-center justify-between cursor-pointer hover:bg-black/50 transition-all"
                    >
                      <span className="font-mono text-sm text-white tracking-wider">{code.code}</span>
                      <div className="flex items-center gap-2">
                        <span className="text-yellow-500 text-sm font-bold">{code.amount.toLocaleString()} 💎</span>
                        <Copy className="size-4 text-white/40" />
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* All Codes List */}
            <div>
              <h3 className="text-sm font-black text-white/80 px-2 mb-3">جميع الأكواد ({codes.length})</h3>
              {loading ? (
                <div className="text-center text-white/40 py-8">جاري التحميل...</div>
              ) : codes.length === 0 ? (
                <div className="text-center text-white/40 py-8">لا توجد أكواد بعد</div>
              ) : (
                <div className="space-y-2 max-h-[300px] overflow-y-auto">
                  {codes.map(code => (
                    <div
                      key={code.id}
                      onClick={() => !code.isUsed && copyCode(code.code)}
                      className={cn(
                        "bg-white/5 rounded-xl p-3 flex items-center justify-between border transition-all",
                        code.isUsed 
                          ? "border-red-500/20 opacity-50" 
                          : "border-white/5 cursor-pointer hover:bg-white/10"
                      )}
                    >
                      <div>
                        <span className={cn(
                          "font-mono text-sm tracking-wider",
                          code.isUsed ? "text-white/40 line-through" : "text-white"
                        )}>
                          {code.code}
                        </span>
                        {code.isUsed && (
                          <div className="text-[10px] text-red-400 mt-1">مستخدم</div>
                        )}
                      </div>
                      <div className="flex items-center gap-2">
                        <span className={cn(
                          "text-sm font-bold",
                          code.isUsed ? "text-white/40" : "text-yellow-500"
                        )}>
                          {code.amount.toLocaleString()} 💎
                        </span>
                        {!code.isUsed && <Copy className="size-4 text-white/40" />}
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </>
        )}

        {activeTab === "users" && (
          <>
            <h3 className="text-sm font-black text-white/80 px-2">المستخدمين ({users.length})</h3>
            
            {loading ? (
              <div className="text-center text-white/40 py-8">جاري التحميل...</div>
            ) : (
              <div className="space-y-3">
                {users.map(user => (
                  <button
                    key={user.id}
                    onClick={() => setSelectedUser(user)}
                    className={cn(
                      "w-full bg-white/5 border rounded-2xl p-4 flex items-center justify-between transition-all",
                      selectedUser?.id === user.id ? "border-amber-500/50 bg-amber-500/10" : "border-white/5 hover:bg-white/10"
                    )}
                  >
                    <div className="flex items-center gap-3">
                      <Avatar className="size-10 border border-white/10">
                        <AvatarImage src={user.avatar || `https://api.dicebear.com/7.x/avataaars/svg?seed=${user.id}`} />
                      </Avatar>
                      <div className="text-right">
                        <div className="flex items-center gap-2">
                          <span className="text-sm font-bold text-white">{user.displayName}</span>
                          {user.isOwner && <Crown className="size-4 text-yellow-400 fill-yellow-400" />}
                        </div>
                        <div className="text-[10px] text-white/40">{user.email || user.username || "بدون بريد"}</div>
                      </div>
                    </div>
                    <div className="text-right">
                      <div className="flex items-center gap-1 text-yellow-500">
                        <Gem className="size-4 fill-yellow-500" />
                        <span className="text-sm font-black">{(user.coins || 0).toLocaleString()}</span>
                      </div>
                      <div className="text-[10px] text-white/40">Lv.{user.level || 1}</div>
                    </div>
                  </button>
                ))}
              </div>
            )}
          </>
        )}

        {activeTab === "rooms" && (
          <>
            <div className="bg-gradient-to-br from-red-500/10 to-orange-500/10 border border-red-500/20 rounded-3xl p-6">
              <div className="flex items-center gap-3 mb-4">
                <div className="size-10 rounded-2xl bg-red-500/20 flex items-center justify-center">
                  <Trash2 className="size-5 text-red-400" />
                </div>
                <div>
                  <h3 className="text-sm font-black text-white">حذف جميع الغرف</h3>
                  <p className="text-[10px] text-white/40">إزالة كل الغرف من التطبيق</p>
                </div>
              </div>
              
              <Button
                onClick={handleDeleteAllRooms}
                disabled={isDeletingRooms || rooms.length === 0}
                className="w-full bg-red-600 hover:bg-red-700 text-white rounded-2xl py-3 font-bold"
              >
                {isDeletingRooms ? "جاري الحذف..." : `🗑️ حذف جميع الغرف (${rooms.length})`}
              </Button>
            </div>

            <h3 className="text-sm font-black text-white/80 px-2 mt-6">الغرف الحالية ({rooms.length})</h3>
            
            {loading ? (
              <div className="text-center text-white/40 py-8">جاري التحميل...</div>
            ) : rooms.length === 0 ? (
              <div className="text-center text-white/40 py-8">لا توجد غرف</div>
            ) : (
              <div className="space-y-3">
                {rooms.map((room: any) => (
                  <div
                    key={room.id}
                    className="w-full bg-white/5 border border-white/5 rounded-2xl p-4 flex items-center justify-between"
                  >
                    <div className="flex items-center gap-3">
                      <div className="size-12 rounded-xl bg-gradient-to-br from-purple-600 to-indigo-700 flex items-center justify-center">
                        {room.coverImage ? (
                          <img src={room.coverImage} alt="" className="size-full rounded-xl object-cover" />
                        ) : (
                          <span className="text-lg">{room.category === "صداقة" ? "💕" : room.category === "موسيقى" ? "🎵" : room.category === "ألعاب" ? "🎮" : "🎤"}</span>
                        )}
                      </div>
                      <div className="text-right">
                        <div className="text-sm font-bold text-white">{room.name}</div>
                        <div className="text-[10px] text-white/40">{room.category} • {room.isLocked ? "🔒" : "🔓"}</div>
                      </div>
                    </div>
                    <div className="flex items-center gap-2 text-white/40">
                      <Users className="size-4" />
                      <span className="text-xs">{room.listenerCount || 0}</span>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </>
        )}

        {/* Recharge Modal */}
        <AnimatePresence>
          {selectedUser && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="fixed inset-0 z-[300] bg-black/80 backdrop-blur-xl flex items-center justify-center p-6"
              onClick={() => setSelectedUser(null)}
            >
              <motion.div
                initial={{ scale: 0.9, y: 20 }}
                animate={{ scale: 1, y: 0 }}
                exit={{ scale: 0.9, y: 20 }}
                className="bg-gray-900 rounded-3xl p-6 max-w-sm w-full border border-white/10 shadow-2xl"
                onClick={e => e.stopPropagation()}
              >
                <div className="text-center mb-6">
                  <Avatar className="size-16 mx-auto border-2 border-amber-500/30 mb-3">
                    <AvatarImage src={selectedUser.avatar || `https://api.dicebear.com/7.x/avataaars/svg?seed=${selectedUser.id}`} />
                  </Avatar>
                  <h3 className="text-lg font-black text-white">{selectedUser.displayName}</h3>
                  <div className="text-sm text-yellow-500 font-bold mt-1">
                    الرصيد الحالي: {(selectedUser.coins || 0).toLocaleString()} 💎
                  </div>
                </div>

                <div className="space-y-4">
                  <div>
                    <label className="text-[10px] font-black text-white/40 uppercase mb-2 block">مبلغ الشحن</label>
                    <Input
                      type="number"
                      value={rechargeAmount}
                      onChange={e => setRechargeAmount(e.target.value)}
                      placeholder="أدخل عدد الكوينز..."
                      className="bg-white/5 border-white/10 text-white rounded-2xl h-12 text-center text-lg"
                    />
                  </div>

                  <div className="grid grid-cols-3 gap-2">
                    {[100, 500, 1000, 5000, 10000, 50000].map(amt => (
                      <button
                        key={amt}
                        onClick={() => setRechargeAmount(amt.toString())}
                        className="bg-white/5 hover:bg-white/10 border border-white/10 rounded-xl py-2 text-xs font-bold text-white transition-all"
                      >
                        +{amt.toLocaleString()}
                      </button>
                    ))}
                  </div>

                  <div className="flex gap-3 mt-6">
                    <Button
                      onClick={() => setSelectedUser(null)}
                      className="flex-1 bg-white/10 hover:bg-white/20 text-white rounded-2xl py-3"
                    >
                      إلغاء
                    </Button>
                    <Button
                      onClick={handleRecharge}
                      disabled={!rechargeAmount}
                      className="flex-1 bg-amber-600 hover:bg-amber-500 text-white rounded-2xl py-3"
                    >
                      شحن الرصيد
                    </Button>
                  </div>
                </div>
              </motion.div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </motion.div>
  );
}

// --- Settings View ---

function SettingsView({ onBack, onWallet, onEditProfile, onSecurity, onLogout, isOwner, onAdminPanel, onAdminLogs }: { onBack: () => void; onWallet: () => void; onEditProfile: () => void; onSecurity: () => void; onLogout: () => void; isOwner: boolean; onAdminPanel: () => void; onAdminLogs: () => void }) {
  const [cacheSize] = useState("24.5 MB");
  const [musicCacheSize] = useState("12.3 MB");
  const appVersion = "1.0.0";

  const SettingsItem = ({ icon, title, subtitle, onClick, showArrow = true }: { icon: React.ReactNode; title: string; subtitle?: string; onClick?: () => void; showArrow?: boolean }) => (
    <button 
      onClick={onClick}
      className="w-full px-4 py-3.5 flex items-center justify-between hover:bg-gray-50 transition-colors"
    >
      <div className="flex items-center gap-3">
        <div className="size-8 rounded-lg bg-gray-100 flex items-center justify-center">
          {icon}
        </div>
        <div className="text-right">
          <div className="text-sm font-semibold text-gray-800">{title}</div>
          {subtitle && <div className="text-xs text-gray-500">{subtitle}</div>}
        </div>
      </div>
      {showArrow && <ChevronLeft className="size-4 text-gray-400" />}
    </button>
  );

  return (
    <motion.div 
      initial={{ x: "100%" }}
      animate={{ x: 0 }}
      exit={{ x: "100%" }}
      className="fixed inset-0 z-[150] bg-white flex flex-col font-cairo overflow-y-auto"
    >
      {/* Header */}
      <header className="p-4 flex items-center justify-between sticky top-0 bg-white z-10 border-b border-gray-200">
        <Button variant="ghost" size="icon" className="text-gray-600 rounded-full" onClick={onBack}>
          <ChevronLeft className="size-6" />
        </Button>
        <h2 className="text-lg font-bold text-gray-800">الإعدادات</h2>
        <div className="size-10" />
      </header>

      <div className="flex-1">
        {/* Account Section */}
        <section className="mt-4">
          <h3 className="text-xs font-bold text-gray-500 px-4 mb-2">الحساب</h3>
          <div className="bg-white border-y border-gray-200">
            <SettingsItem
              icon={<UserPlus className="size-4 text-blue-500" />}
              title="ربط الحساب"
              subtitle="ربط حساباتك الاجتماعية"
              onClick={onSecurity}
            />
          </div>
        </section>

        {/* Features Section */}
        <section className="mt-6">
          <h3 className="text-xs font-bold text-gray-500 px-4 mb-2">الميزة</h3>
          <div className="bg-white border-y border-gray-200 divide-y divide-gray-100">
            <SettingsItem
              icon={<Bell className="size-4 text-orange-500" />}
              title="إعدادات الإشعارات"
            />
            <SettingsItem
              icon={<Shield className="size-4 text-green-500" />}
              title="إعدادات الخصوصية"
              onClick={onSecurity}
            />
            <SettingsItem
              icon={<Trash2 className="size-4 text-purple-500" />}
              title="مسح التخزين المؤقت"
              subtitle={cacheSize}
            />
            <SettingsItem
              icon={<Music className="size-4 text-pink-500" />}
              title="مسح التخزين المؤقت للموسيقى"
              subtitle={musicCacheSize}
            />
            <SettingsItem
              icon={<Ban className="size-4 text-red-500" />}
              title="القائمة السوداء"
            />
            <SettingsItem
              icon={<Palette className="size-4 text-indigo-500" />}
              title="إعدادات التخصيص"
              subtitle="جاء المظهر الداكن!"
            />
          </div>
        </section>

        {/* Admin Panel - Owner Only */}
        {isOwner && (
          <section className="mt-6">
            <h3 className="text-xs font-bold text-gray-500 px-4 mb-2">إدارة التطبيق</h3>
            <div className="bg-white border-y border-gray-200 divide-y divide-gray-100">
              <button 
                onClick={onAdminPanel}
                className="w-full px-4 py-3.5 flex items-center justify-between hover:bg-amber-50 transition-colors"
              >
                <div className="flex items-center gap-3">
                  <div className="size-8 rounded-lg bg-amber-100 flex items-center justify-center">
                    <Crown className="size-4 text-amber-600" />
                  </div>
                  <div className="text-right">
                    <div className="text-sm font-semibold text-amber-700">لوحة تحكم المالك</div>
                    <div className="text-xs text-amber-500">إدارة أرصدة المستخدمين</div>
                  </div>
                </div>
                <ChevronLeft className="size-4 text-amber-400" />
              </button>
              <button 
                onClick={onAdminLogs}
                className="w-full px-4 py-3.5 flex items-center justify-between hover:bg-amber-50 transition-colors"
              >
                <div className="flex items-center gap-3">
                  <div className="size-8 rounded-lg bg-gradient-to-br from-amber-400 to-yellow-500 flex items-center justify-center">
                    <Crown className="size-4 text-white" />
                  </div>
                  <div className="text-right">
                    <div className="text-sm font-semibold text-amber-700">سجلات النظام</div>
                    <div className="text-xs text-amber-500">إحصائيات، حظر، رسائل عامة</div>
                  </div>
                </div>
                <ChevronLeft className="size-4 text-amber-400" />
              </button>
            </div>
          </section>
        )}

        {/* Other Section */}
        <section className="mt-6">
          <h3 className="text-xs font-bold text-gray-500 px-4 mb-2">الآخر</h3>
          <div className="bg-white border-y border-gray-200 divide-y divide-gray-100">
            <SettingsItem
              icon={<RefreshCw className="size-4 text-teal-500" />}
              title="التحقق من التحديثات"
              subtitle={`الإصدار الحالي: ${appVersion}`}
            />
            <SettingsItem
              icon={<FileText className="size-4 text-gray-500" />}
              title="سياسة النظام الأساسي"
            />
          </div>
        </section>

        {/* Logout Button */}
        <section className="mt-8 px-4 pb-8">
          <button 
            data-testid="button-logout"
            onClick={onLogout}
            className="w-full py-3.5 bg-red-500 hover:bg-red-600 text-white font-bold rounded-xl transition-colors flex items-center justify-center gap-2"
          >
            <LogOut className="size-5" />
            تسجيل الخروج
          </button>
        </section>
      </div>
    </motion.div>
  );
}

// --- Profile View ---

function ProfileView({ onBack, onSettings, coins, followers, isOwner, onRemoveAllFollowers }: { onBack: () => void; onSettings: () => void; coins: number; followers: number; isOwner: boolean; onRemoveAllFollowers: () => void }) {
  const [showRemoveFollowersConfirm, setShowRemoveFollowersConfirm] = useState(false);
  const [activeTab, setActiveTab] = useState<'posts' | 'profile' | 'honor' | 'relation'>('profile');
  const userRank = "ولد الشايب";
  const userZodiac = "الثور ♉";
  const userRegion = "العراق 🇮🇶";
  const appAge = "180 يوم";
  const userFamily = "عائلة الذهب 👑";
  const userId = "12345";
  
  const tabs = [
    { id: 'posts' as const, label: 'منشورات' },
    { id: 'profile' as const, label: 'الملف الشخصي' },
    { id: 'honor' as const, label: 'الشرف' },
    { id: 'relation' as const, label: 'العلاقة' },
  ];

  return (
    <motion.div 
      initial={{ x: "100%" }}
      animate={{ x: 0 }}
      exit={{ x: "100%" }}
      className="fixed inset-0 z-[100] bg-white flex flex-col font-cairo overflow-y-auto"
    >
      {/* Large Profile Background - Top Half */}
      <div className="relative h-72 w-full">
        <img 
          src="https://api.dicebear.com/7.x/avataaars/svg?seed=Me" 
          className="h-full w-full object-cover"
          alt="profile background"
        />
        <div className="absolute inset-0 bg-gradient-to-b from-black/30 via-transparent to-white" />
        
        {/* Back Button - Top Right */}
        <div className="absolute top-4 right-4">
          <Button variant="ghost" size="icon" className="bg-black/30 backdrop-blur-md rounded-full text-white" onClick={onBack}>
            <ChevronLeft className="size-6" />
          </Button>
        </div>
        
        {/* Share Button - Top Left */}
        <div className="absolute top-4 left-4">
          <Button variant="ghost" size="icon" className="bg-black/30 backdrop-blur-md rounded-full text-white">
            <Share2 className="size-5" />
          </Button>
        </div>
      </div>

      {/* Account Info Section */}
      <div className="px-4 -mt-16 relative z-10">
        <div className="flex items-start gap-4">
          {/* Small Profile Picture in Circle */}
          <div className="relative">
            {isOwner && (
              <div className="absolute -top-2 left-1/2 -translate-x-1/2 text-xl z-30">👑</div>
            )}
            <Avatar className="size-20 border-4 border-white shadow-xl">
              <AvatarImage src="https://api.dicebear.com/7.x/avataaars/svg?seed=Me" />
              <AvatarFallback>Me</AvatarFallback>
            </Avatar>
            <div className="absolute bottom-0 right-0 size-6 bg-green-500 rounded-full border-2 border-white" />
          </div>
          
          {/* Name, ID, Followers */}
          <div className="flex-1 pt-8">
            <div className="flex items-center gap-2">
              <h2 className="text-xl font-bold text-gray-800">مستخدم</h2>
              {isOwner && <Crown className="size-5 text-yellow-500" />}
              <ShieldCheck className="size-4 text-blue-500" />
            </div>
            <div className="flex items-center gap-3 mt-1 text-sm text-gray-500">
              <span>ID: {userId}</span>
              <span>•</span>
              <span>{followers.toLocaleString()} متابع</span>
            </div>
          </div>
          
          {/* Settings Button */}
          <Button variant="ghost" size="icon" className="mt-8 text-gray-500" onClick={onSettings}>
            <Settings className="size-5" />
          </Button>
        </div>

        {/* Rank and Badges */}
        <div className="mt-4 flex items-center gap-2 flex-wrap">
          <div className="bg-purple-100 text-purple-700 px-3 py-1 rounded-full text-xs font-bold flex items-center gap-1">
            <Medal className="size-3" />
            {userRank}
          </div>
          <div className="flex gap-1">
            <span className="text-xl">🎁</span>
            <span className="text-xl">🏆</span>
            <span className="text-xl">⭐</span>
            <span className="text-xl">💎</span>
          </div>
        </div>

        {/* Tabs */}
        <div className="mt-6 border-b border-gray-200">
          <div className="flex">
            {tabs.map((tab) => (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={cn(
                  "flex-1 py-3 text-sm font-semibold transition-colors relative",
                  activeTab === tab.id ? "text-purple-600" : "text-gray-500"
                )}
              >
                {tab.label}
                {activeTab === tab.id && (
                  <motion.div
                    layoutId="activeTab"
                    className="absolute bottom-0 left-0 right-0 h-0.5 bg-purple-600"
                  />
                )}
              </button>
            ))}
          </div>
        </div>

        {/* Tab Content */}
        {activeTab === 'profile' && (
          <div className="mt-4 space-y-4">
            {/* About Me Section */}
            <div className="bg-gray-50 rounded-2xl p-4">
              <h3 className="text-sm font-bold text-gray-800 mb-3">عني</h3>
              <div className="space-y-3">
                <div className="flex items-center gap-3">
                  <div className="size-8 rounded-lg bg-orange-100 flex items-center justify-center">
                    <Star className="size-4 text-orange-500" />
                  </div>
                  <div>
                    <div className="text-xs text-gray-500">الكوكبة</div>
                    <div className="text-sm font-medium text-gray-800">{userZodiac}</div>
                  </div>
                </div>
                <div className="flex items-center gap-3">
                  <div className="size-8 rounded-lg bg-blue-100 flex items-center justify-center">
                    <MapPin className="size-4 text-blue-500" />
                  </div>
                  <div>
                    <div className="text-xs text-gray-500">المنطقة</div>
                    <div className="text-sm font-medium text-gray-800">{userRegion}</div>
                  </div>
                </div>
                <div className="flex items-center gap-3">
                  <div className="size-8 rounded-lg bg-green-100 flex items-center justify-center">
                    <Calendar className="size-4 text-green-500" />
                  </div>
                  <div>
                    <div className="text-xs text-gray-500">العمر في التطبيق</div>
                    <div className="text-sm font-medium text-gray-800">{appAge}</div>
                  </div>
                </div>
              </div>
            </div>

            {/* Family Section */}
            <div className="bg-gradient-to-r from-amber-50 to-yellow-50 rounded-2xl p-4 border border-amber-200">
              <h3 className="text-sm font-bold text-gray-800 mb-3">العائلة</h3>
              <div className="flex items-center gap-3">
                <div className="size-12 rounded-xl bg-gradient-to-br from-amber-400 to-yellow-500 flex items-center justify-center">
                  <Users className="size-6 text-white" />
                </div>
                <div>
                  <div className="text-base font-bold text-amber-700">{userFamily}</div>
                  <div className="text-xs text-amber-600">عضو نشط</div>
                </div>
                <ChevronLeft className="size-5 text-amber-400 mr-auto" />
              </div>
            </div>

            {/* Currency Display */}
            <div className="grid grid-cols-2 gap-3">
              <div className="bg-gray-50 rounded-2xl p-4">
                <div className="text-xs text-gray-500 mb-1">العملات</div>
                <div className="flex items-center gap-2">
                  <Gem className="size-5 text-yellow-500" />
                  <span className="text-lg font-bold text-gray-800">{coins.toLocaleString()}</span>
                </div>
              </div>
              <div className="bg-gray-50 rounded-2xl p-4">
                <div className="text-xs text-gray-500 mb-1">الياقوت</div>
                <div className="flex items-center gap-2">
                  <Sparkles className="size-5 text-rose-500" />
                  <span className="text-lg font-bold text-gray-800">∞</span>
                </div>
              </div>
            </div>
          </div>
        )}

        {activeTab === 'posts' && (
          <div className="mt-4 space-y-4 pb-8">
            {/* Create Post Button */}
            <button className="w-full bg-purple-50 border-2 border-dashed border-purple-200 rounded-2xl p-4 flex items-center justify-center gap-2 hover:bg-purple-100 transition-colors">
              <Plus className="size-5 text-purple-500" />
              <span className="text-purple-600 font-semibold">إنشاء منشور جديد</span>
            </button>
            
            {/* Sample Posts */}
            <div className="bg-white rounded-2xl border border-gray-200 overflow-hidden">
              <div className="p-4">
                <div className="flex items-center gap-3 mb-3">
                  <Avatar className="size-10">
                    <AvatarImage src="https://api.dicebear.com/7.x/avataaars/svg?seed=Me" />
                    <AvatarFallback>م</AvatarFallback>
                  </Avatar>
                  <div>
                    <div className="text-sm font-bold text-gray-800">مستخدم</div>
                    <div className="text-xs text-gray-500">منذ ساعتين</div>
                  </div>
                </div>
                <p className="text-gray-700 text-sm leading-relaxed">مرحباً بالجميع! سعيد بالانضمام إلى هذا المجتمع الرائع 🎉</p>
              </div>
              <div className="px-4 py-3 bg-gray-50 flex items-center gap-6 border-t border-gray-100">
                <button className="flex items-center gap-1 text-gray-500 hover:text-rose-500 transition-colors">
                  <Heart className="size-4" />
                  <span className="text-xs">24</span>
                </button>
                <button className="flex items-center gap-1 text-gray-500 hover:text-blue-500 transition-colors">
                  <MessageCircle className="size-4" />
                  <span className="text-xs">8</span>
                </button>
                <button className="flex items-center gap-1 text-gray-500 hover:text-green-500 transition-colors">
                  <Share2 className="size-4" />
                </button>
              </div>
            </div>

            <div className="bg-white rounded-2xl border border-gray-200 overflow-hidden">
              <div className="p-4">
                <div className="flex items-center gap-3 mb-3">
                  <Avatar className="size-10">
                    <AvatarImage src="https://api.dicebear.com/7.x/avataaars/svg?seed=Me" />
                    <AvatarFallback>م</AvatarFallback>
                  </Avatar>
                  <div>
                    <div className="text-sm font-bold text-gray-800">مستخدم</div>
                    <div className="text-xs text-gray-500">منذ يوم</div>
                  </div>
                </div>
                <p className="text-gray-700 text-sm leading-relaxed">شكراً لكل من دعمني في رحلتي هنا! أنتم الأفضل 💜</p>
              </div>
              <div className="px-4 py-3 bg-gray-50 flex items-center gap-6 border-t border-gray-100">
                <button className="flex items-center gap-1 text-rose-500">
                  <Heart className="size-4 fill-rose-500" />
                  <span className="text-xs">156</span>
                </button>
                <button className="flex items-center gap-1 text-gray-500 hover:text-blue-500 transition-colors">
                  <MessageCircle className="size-4" />
                  <span className="text-xs">32</span>
                </button>
                <button className="flex items-center gap-1 text-gray-500 hover:text-green-500 transition-colors">
                  <Share2 className="size-4" />
                </button>
              </div>
            </div>
          </div>
        )}

        {activeTab === 'honor' && (
          <div className="mt-4 space-y-4 pb-8">
            {/* Honor Level */}
            <div className="bg-gradient-to-r from-amber-50 to-orange-50 rounded-2xl p-4 border border-amber-200">
              <div className="flex items-center justify-between mb-3">
                <h3 className="text-sm font-bold text-amber-800">مستوى الشرف</h3>
                <div className="bg-amber-500 text-white text-xs font-bold px-2 py-1 rounded-full">المستوى 5</div>
              </div>
              <div className="w-full bg-amber-200 rounded-full h-2 mb-2">
                <div className="bg-gradient-to-r from-amber-400 to-orange-500 h-2 rounded-full" style={{ width: '75%' }} />
              </div>
              <div className="text-xs text-amber-600">750 / 1000 نقطة للمستوى التالي</div>
            </div>

            {/* Badges */}
            <div className="bg-white rounded-2xl border border-gray-200 p-4">
              <h3 className="text-sm font-bold text-gray-800 mb-3">الأوسمة المكتسبة</h3>
              <div className="grid grid-cols-4 gap-3">
                <div className="flex flex-col items-center">
                  <div className="size-14 rounded-xl bg-yellow-100 flex items-center justify-center mb-1">
                    <span className="text-2xl">🏆</span>
                  </div>
                  <span className="text-[10px] text-gray-600 text-center">البطل</span>
                </div>
                <div className="flex flex-col items-center">
                  <div className="size-14 rounded-xl bg-purple-100 flex items-center justify-center mb-1">
                    <span className="text-2xl">⭐</span>
                  </div>
                  <span className="text-[10px] text-gray-600 text-center">نجم</span>
                </div>
                <div className="flex flex-col items-center">
                  <div className="size-14 rounded-xl bg-blue-100 flex items-center justify-center mb-1">
                    <span className="text-2xl">💎</span>
                  </div>
                  <span className="text-[10px] text-gray-600 text-center">ماسي</span>
                </div>
                <div className="flex flex-col items-center">
                  <div className="size-14 rounded-xl bg-rose-100 flex items-center justify-center mb-1">
                    <span className="text-2xl">🎁</span>
                  </div>
                  <span className="text-[10px] text-gray-600 text-center">كريم</span>
                </div>
                <div className="flex flex-col items-center">
                  <div className="size-14 rounded-xl bg-green-100 flex items-center justify-center mb-1">
                    <span className="text-2xl">🎤</span>
                  </div>
                  <span className="text-[10px] text-gray-600 text-center">متحدث</span>
                </div>
                <div className="flex flex-col items-center">
                  <div className="size-14 rounded-xl bg-indigo-100 flex items-center justify-center mb-1">
                    <span className="text-2xl">👑</span>
                  </div>
                  <span className="text-[10px] text-gray-600 text-center">ملك</span>
                </div>
                <div className="flex flex-col items-center opacity-40">
                  <div className="size-14 rounded-xl bg-gray-100 flex items-center justify-center mb-1">
                    <span className="text-2xl">🔒</span>
                  </div>
                  <span className="text-[10px] text-gray-400 text-center">مقفل</span>
                </div>
                <div className="flex flex-col items-center opacity-40">
                  <div className="size-14 rounded-xl bg-gray-100 flex items-center justify-center mb-1">
                    <span className="text-2xl">🔒</span>
                  </div>
                  <span className="text-[10px] text-gray-400 text-center">مقفل</span>
                </div>
              </div>
            </div>

            {/* Achievements */}
            <div className="bg-white rounded-2xl border border-gray-200 p-4">
              <h3 className="text-sm font-bold text-gray-800 mb-3">الإنجازات</h3>
              <div className="space-y-3">
                <div className="flex items-center gap-3">
                  <div className="size-10 rounded-lg bg-green-100 flex items-center justify-center">
                    <Trophy className="size-5 text-green-600" />
                  </div>
                  <div className="flex-1">
                    <div className="text-sm font-medium text-gray-800">أول 100 متابع</div>
                    <div className="text-xs text-gray-500">تم الحصول عليه</div>
                  </div>
                  <span className="text-green-500 text-xl">✓</span>
                </div>
                <div className="flex items-center gap-3">
                  <div className="size-10 rounded-lg bg-blue-100 flex items-center justify-center">
                    <Mic className="size-5 text-blue-600" />
                  </div>
                  <div className="flex-1">
                    <div className="text-sm font-medium text-gray-800">10 ساعات بث</div>
                    <div className="text-xs text-gray-500">تم الحصول عليه</div>
                  </div>
                  <span className="text-green-500 text-xl">✓</span>
                </div>
                <div className="flex items-center gap-3 opacity-60">
                  <div className="size-10 rounded-lg bg-gray-100 flex items-center justify-center">
                    <Gift className="size-5 text-gray-400" />
                  </div>
                  <div className="flex-1">
                    <div className="text-sm font-medium text-gray-600">إرسال 1000 هدية</div>
                    <div className="text-xs text-gray-400">456 / 1000</div>
                  </div>
                  <span className="text-gray-300 text-xl">🔒</span>
                </div>
              </div>
            </div>
          </div>
        )}

        {activeTab === 'relation' && (
          <div className="mt-4 space-y-4 pb-8">
            {/* Relationship Status */}
            <div className="bg-gradient-to-r from-pink-50 to-rose-50 rounded-2xl p-4 border border-pink-200">
              <div className="flex items-center gap-3">
                <div className="size-12 rounded-full bg-gradient-to-br from-pink-400 to-rose-500 flex items-center justify-center">
                  <Heart className="size-6 text-white fill-white" />
                </div>
                <div>
                  <div className="text-sm font-bold text-rose-700">الحالة العاطفية</div>
                  <div className="text-xs text-rose-500">أعزب 💔</div>
                </div>
              </div>
            </div>

            {/* Best Friends */}
            <div className="bg-white rounded-2xl border border-gray-200 p-4">
              <h3 className="text-sm font-bold text-gray-800 mb-3">أفضل الأصدقاء</h3>
              <div className="space-y-3">
                <div className="flex items-center gap-3">
                  <Avatar className="size-12 border-2 border-purple-200">
                    <AvatarImage src="https://api.dicebear.com/7.x/avataaars/svg?seed=friend1" />
                    <AvatarFallback>أ</AvatarFallback>
                  </Avatar>
                  <div className="flex-1">
                    <div className="text-sm font-bold text-gray-800">أحمد</div>
                    <div className="text-xs text-gray-500">صديق منذ 90 يوم</div>
                  </div>
                  <div className="bg-purple-100 text-purple-600 text-xs font-bold px-2 py-1 rounded-full">💜 BFF</div>
                </div>
                <div className="flex items-center gap-3">
                  <Avatar className="size-12 border-2 border-blue-200">
                    <AvatarImage src="https://api.dicebear.com/7.x/avataaars/svg?seed=friend2" />
                    <AvatarFallback>س</AvatarFallback>
                  </Avatar>
                  <div className="flex-1">
                    <div className="text-sm font-bold text-gray-800">سارة</div>
                    <div className="text-xs text-gray-500">صديقة منذ 45 يوم</div>
                  </div>
                  <div className="bg-blue-100 text-blue-600 text-xs font-bold px-2 py-1 rounded-full">💙</div>
                </div>
                <div className="flex items-center gap-3">
                  <Avatar className="size-12 border-2 border-green-200">
                    <AvatarImage src="https://api.dicebear.com/7.x/avataaars/svg?seed=friend3" />
                    <AvatarFallback>م</AvatarFallback>
                  </Avatar>
                  <div className="flex-1">
                    <div className="text-sm font-bold text-gray-800">محمد</div>
                    <div className="text-xs text-gray-500">صديق منذ 30 يوم</div>
                  </div>
                  <div className="bg-green-100 text-green-600 text-xs font-bold px-2 py-1 rounded-full">💚</div>
                </div>
              </div>
            </div>

            {/* Gifts Received */}
            <div className="bg-white rounded-2xl border border-gray-200 p-4">
              <h3 className="text-sm font-bold text-gray-800 mb-3">الهدايا المستلمة</h3>
              <div className="flex gap-2 flex-wrap">
                <div className="bg-amber-50 rounded-xl p-3 flex flex-col items-center min-w-[70px]">
                  <span className="text-2xl mb-1">🌹</span>
                  <span className="text-xs font-bold text-amber-700">×24</span>
                </div>
                <div className="bg-purple-50 rounded-xl p-3 flex flex-col items-center min-w-[70px]">
                  <span className="text-2xl mb-1">💎</span>
                  <span className="text-xs font-bold text-purple-700">×12</span>
                </div>
                <div className="bg-pink-50 rounded-xl p-3 flex flex-col items-center min-w-[70px]">
                  <span className="text-2xl mb-1">❤️</span>
                  <span className="text-xs font-bold text-pink-700">×156</span>
                </div>
                <div className="bg-blue-50 rounded-xl p-3 flex flex-col items-center min-w-[70px]">
                  <span className="text-2xl mb-1">🎁</span>
                  <span className="text-xs font-bold text-blue-700">×8</span>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
      
      {/* Remove All Followers Confirmation */}
      <AnimatePresence>
        {showRemoveFollowersConfirm && (
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0.9 }}
            className="fixed inset-0 z-[200] bg-black/80 backdrop-blur-xl flex items-center justify-center p-6"
            onClick={() => setShowRemoveFollowersConfirm(false)}
          >
            <motion.div
              initial={{ y: 20 }}
              animate={{ y: 0 }}
              className="bg-white rounded-3xl p-6 max-w-sm w-full shadow-2xl"
              onClick={(e) => e.stopPropagation()}
            >
              <div className="text-center">
                <div className="size-16 rounded-full bg-rose-100 flex items-center justify-center mx-auto mb-4">
                  <UserMinus className="size-8 text-rose-500" />
                </div>
                <h3 className="text-xl font-bold text-gray-800 mb-2">إزالة جميع المتابعين؟</h3>
                <p className="text-sm text-gray-500 mb-6">سيتم إزالة {followers.toLocaleString()} متابع من حسابك.</p>
                
                <div className="flex gap-3">
                  <Button
                    onClick={() => setShowRemoveFollowersConfirm(false)}
                    className="flex-1 bg-gray-100 hover:bg-gray-200 text-gray-700 rounded-xl py-3"
                  >
                    إلغاء
                  </Button>
                  <Button
                    data-testid="button-confirm-remove-followers"
                    onClick={() => {
                      onRemoveAllFollowers();
                      setShowRemoveFollowersConfirm(false);
                      toast.success("تم إزالة جميع المتابعين بنجاح!");
                    }}
                    className="flex-1 bg-rose-500 hover:bg-rose-600 text-white rounded-xl py-3"
                  >
                    تأكيد الإزالة
                  </Button>
                </div>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </motion.div>
  );
}

function RoomCard({ room, onClick }: { room: Room; onClick: () => void }) {
  const defaultImage = `https://images.unsplash.com/photo-1614850523296-d8c1af93d400?w=1920&h=1080&fit=crop&q=100&auto=format`;
  const [mousePos, setMousePos] = useState({ x: 0.5, y: 0.5 });
  
  const handleMouseMove = (e: React.MouseEvent<HTMLDivElement>) => {
    const rect = e.currentTarget.getBoundingClientRect();
    setMousePos({
      x: (e.clientX - rect.left) / rect.width,
      y: (e.clientY - rect.top) / rect.height,
    });
  };

  return (
    <motion.div
      whileTap={{ scale: 0.97 }}
      whileHover={{ scale: 1.02, y: -4 }}
      onClick={onClick}
      onMouseMove={handleMouseMove}
      className="relative overflow-hidden rounded-2xl aspect-[3/4] group cursor-pointer"
      style={{
        boxShadow: '0 25px 50px -12px rgba(0,0,0,0.7), 0 12px 24px -8px rgba(0,0,0,0.5), inset 0 1px 0 rgba(255,215,0,0.4)',
        border: '3px solid transparent',
        backgroundImage: `linear-gradient(#0a0a15, #0a0a15), linear-gradient(${135 + mousePos.x * 90}deg, #ffd700 0%, #ffed4a 25%, #b8860b 50%, #ffd700 75%, #ffed4a 100%)`,
        backgroundOrigin: 'border-box',
        backgroundClip: 'padding-box, border-box',
      }}
      data-testid={`room-card-${room.id}`}
    >
      {/* 1080p Full HD Image - No compression */}
      <img 
        src={(room.image || defaultImage).replace(/w=\d+/, 'w=1920').replace(/h=\d+/, 'h=1080').replace(/q=\d+/, 'q=100')} 
        className="absolute inset-0 w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
        alt={room.title}
        loading="eager"
        decoding="sync"
        fetchPriority="high"
      />
      
      {/* Cinematic Overlay - Film-like color grading */}
      <div className="absolute inset-0" style={{
        background: 'linear-gradient(180deg, rgba(0,0,0,0.1) 0%, rgba(20,10,30,0.3) 40%, rgba(0,0,0,0.85) 100%)',
        mixBlendMode: 'multiply',
      }} />
      <div className="absolute inset-0" style={{
        background: 'radial-gradient(ellipse at 50% 0%, rgba(255,200,100,0.1) 0%, transparent 60%)',
      }} />
      
      {/* Dynamic light reflection on golden frame */}
      <div 
        className="absolute inset-0 pointer-events-none opacity-40 group-hover:opacity-70 transition-opacity duration-300"
        style={{
          background: `radial-gradient(circle at ${mousePos.x * 100}% ${mousePos.y * 100}%, rgba(255,215,0,0.4) 0%, transparent 50%)`,
        }}
      />
      
      {/* Top badges with glass effect */}
      <div className="absolute top-3 left-3 flex gap-2">
        {room.live && (
          <div 
            className="text-white text-[10px] font-black px-3 py-1.5 rounded-full flex items-center gap-1.5"
            style={{
              background: 'linear-gradient(135deg, rgba(220,38,38,0.9) 0%, rgba(236,72,153,0.9) 100%)',
              backdropFilter: 'blur(10px)',
              boxShadow: '0 4px 15px rgba(220,38,38,0.4), inset 0 1px 0 rgba(255,255,255,0.2)',
            }}
          >
            <div className="size-2 bg-white rounded-full animate-pulse" />
            LIVE
          </div>
        )}
      </div>

      <div className="absolute top-3 right-3">
        <div 
          className="text-white text-[10px] font-black px-3 py-1.5 rounded-full"
          style={{
            background: 'linear-gradient(135deg, rgba(245,158,11,0.9) 0%, rgba(249,115,22,0.9) 100%)',
            backdropFilter: 'blur(10px)',
            boxShadow: '0 4px 15px rgba(245,158,11,0.4), inset 0 1px 0 rgba(255,255,255,0.2)',
          }}
        >
          {room.category}
        </div>
      </div>

      {/* Bottom info - Glass printed text effect */}
      <div className="absolute bottom-0 right-0 left-0 p-4 text-right">
        <div 
          className="absolute inset-0"
          style={{
            background: 'linear-gradient(to top, rgba(0,0,0,0.95) 0%, rgba(0,0,0,0.7) 50%, transparent 100%)',
            backdropFilter: 'blur(2px)',
          }}
        />
        
        <div className="relative z-10">
          {/* Host info with glass text */}
          <div className="flex items-center justify-end gap-2 mb-2">
            <span 
              className="text-[10px] font-bold px-2.5 py-1 rounded-full"
              style={{
                background: 'linear-gradient(135deg, rgba(251,191,36,0.2) 0%, rgba(245,158,11,0.3) 100%)',
                backdropFilter: 'blur(8px)',
                border: '1px solid rgba(251,191,36,0.4)',
                color: '#fcd34d',
                textShadow: '0 1px 2px rgba(0,0,0,0.5)',
              }}
            >
              Lv.{room.host.level}
            </span>
            <span 
              className="text-sm font-black"
              style={{
                color: '#ffffff',
                textShadow: '0 2px 8px rgba(0,0,0,0.8), 0 0 20px rgba(0,0,0,0.6)',
                WebkitFontSmoothing: 'antialiased',
              }}
            >
              {room.host.name}
            </span>
            <div className="relative">
              <div 
                className="absolute inset-[-3px] rounded-full animate-pulse"
                style={{
                  background: 'linear-gradient(45deg, #ffd700, #ffed4a, #ffd700)',
                  opacity: 0.7,
                }}
              />
              <Avatar className="size-8 border-2 border-amber-400 relative">
                <AvatarImage src={room.host.avatar} />
              </Avatar>
            </div>
          </div>
          
          {/* Room title - Glass printed effect */}
          <h3 
            className="font-black text-lg leading-tight truncate"
            style={{ 
              color: '#ffffff',
              textShadow: '0 0 30px rgba(0,0,0,1), 0 2px 15px rgba(0,0,0,0.9), 0 4px 30px rgba(0,0,0,0.7)',
              WebkitFontSmoothing: 'antialiased',
              letterSpacing: '0.02em',
            }}
          >
            {room.title}
          </h3>
          
          {/* Users count with glass effect */}
          <div className="flex items-center justify-end gap-1.5 mt-2">
            <Users className="size-3.5 text-white/70" />
            <span 
              className="text-[11px] font-bold"
              style={{
                color: 'rgba(255,255,255,0.8)',
                textShadow: '0 1px 3px rgba(0,0,0,0.5)',
              }}
            >
              {Math.floor(Math.random() * 50) + 10}
            </span>
          </div>
        </div>
      </div>
    </motion.div>
  );
}

// --- Voice Mic Visualizer ---
function MicVisualizer() {
  return (
    <div className="mic-visualizer">
      <div className="mic-bar" style={{ animationDelay: "0s" }} />
      <div className="mic-bar" style={{ animationDelay: "0.1s" }} />
      <div className="mic-bar" style={{ animationDelay: "0.2s" }} />
      <div className="mic-bar" style={{ animationDelay: "0.15s" }} />
      <div className="mic-bar" style={{ animationDelay: "0.05s" }} />
    </div>
  );
}

// --- Create Room Modal ---
function CreateRoomModal({ 
  onClose, 
  onCreate 
}: { 
  onClose: () => void; 
  onCreate: (title: string, category: string, imageUrl: string) => void;
}) {
  const [title, setTitle] = useState("");
  const [category, setCategory] = useState(ROOM_CATEGORIES[0]);
  const [imageUrl, setImageUrl] = useState("");
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleSubmit = async () => {
    if (!title.trim()) {
      toast.error("يرجى إدخال اسم الغرفة");
      return;
    }
    setIsSubmitting(true);
    await onCreate(title, category, imageUrl);
    setIsSubmitting(false);
  };

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 z-[500] flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm"
      onClick={onClose}
    >
      <motion.div
        initial={{ scale: 0.9, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        exit={{ scale: 0.9, opacity: 0 }}
        onClick={(e) => e.stopPropagation()}
        className="bg-black rounded-3xl p-6 w-full max-w-md border border-white/10"
      >
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-xl font-black">إنشاء غرفة جديدة</h2>
          <button onClick={onClose} className="p-2 rounded-xl bg-white/5 hover:bg-white/10">
            <ChevronLeft className="size-5" />
          </button>
        </div>

        <div className="space-y-4">
          <div>
            <label className="block text-sm font-bold text-white/70 mb-2">اسم الغرفة</label>
            <Input
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder="مثال: سوالف آخر الليل 🌙"
              className="bg-white/5 border-white/10 rounded-xl h-12 text-right"
              data-testid="room-title-input"
            />
          </div>

          <div>
            <label className="block text-sm font-bold text-white/70 mb-2">التصنيف</label>
            <div className="flex flex-wrap gap-2">
              {ROOM_CATEGORIES.map((cat) => (
                <button
                  key={cat}
                  onClick={() => setCategory(cat)}
                  data-testid={`select-category-${cat}`}
                  className={cn(
                    "px-4 py-2 rounded-xl text-sm font-bold transition-all",
                    category === cat
                      ? "bg-amber-600 text-white"
                      : "bg-white/5 text-white/70 hover:bg-white/10"
                  )}
                >
                  {cat}
                </button>
              ))}
            </div>
          </div>

          <div>
            <label className="block text-sm font-bold text-white/70 mb-2">صورة الغرفة (اختياري)</label>
            <div className="relative">
              <input
                type="file"
                accept="image/*"
                onChange={async (e) => {
                  const file = e.target.files?.[0];
                  if (file) {
                    // Show preview immediately
                    const reader = new FileReader();
                    reader.onload = (ev) => {
                      setImageUrl(ev.target?.result as string);
                    };
                    reader.readAsDataURL(file);
                    
                    // Upload to storage
                    try {
                      const res = await fetch("/api/uploads/request-url", {
                        method: "POST",
                        headers: { "Content-Type": "application/json" },
                        body: JSON.stringify({
                          name: file.name,
                          size: file.size,
                          contentType: file.type,
                        }),
                      });
                      const { uploadURL, objectPath } = await res.json();
                      
                      // Upload file directly to presigned URL
                      await fetch(uploadURL, {
                        method: "PUT",
                        body: file,
                        headers: { "Content-Type": file.type },
                      });
                      
                      // Store the object path for the room
                      setImageUrl(objectPath);
                    } catch (err) {
                      console.error("Upload failed:", err);
                    }
                  }
                }}
                className="hidden"
                id="room-image-upload"
                data-testid="room-image-input"
              />
              <label
                htmlFor="room-image-upload"
                className="flex items-center justify-center gap-2 w-full h-12 bg-white/5 border border-white/10 rounded-xl cursor-pointer hover:bg-white/10 transition-colors"
              >
                <Camera className="size-5 text-white/60" />
                <span className="text-white/60 font-medium">تحميل صورة من الهاتف</span>
              </label>
            </div>
            {imageUrl && (
              <div className="mt-3 rounded-xl overflow-hidden h-32 border border-white/20">
                <img 
                  src={imageUrl.startsWith('/objects/') ? imageUrl : imageUrl} 
                  alt="معاينة الصورة" 
                  className="w-full h-full object-cover" 
                />
              </div>
            )}
          </div>

          <Button
            onClick={handleSubmit}
            disabled={isSubmitting || !title.trim()}
            className="w-full h-14 rounded-2xl bg-gradient-to-r from-amber-500 to-amber-700 font-black text-lg"
            data-testid="submit-create-room"
          >
            {isSubmitting ? (
              <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-white" />
            ) : (
              <>
                <Plus className="size-5 mr-2" />
                إنشاء الغرفة
              </>
            )}
          </Button>
        </div>
      </motion.div>
    </motion.div>
  );
}

// --- Floating Hearts Animation ---
function FloatingHearts({ trigger }: { trigger: number }) {
  const [hearts, setHearts] = useState<{ id: number; x: number }[]>([]);

  useEffect(() => {
    if (trigger > 0) {
      const id = Date.now();
      setHearts(prev => [...prev, { id, x: Math.random() * 100 - 50 }]);
      setTimeout(() => {
        setHearts(prev => prev.filter(h => h.id !== id));
      }, 3000);
    }
  }, [trigger]);

  return (
    <div className="fixed inset-0 pointer-events-none z-[400] overflow-hidden">
      <AnimatePresence>
        {hearts.map(heart => (
          <motion.div
            key={heart.id}
            initial={{ y: "100vh", x: `calc(50% + ${heart.x}px)`, opacity: 1, scale: 0.5 }}
            animate={{ y: "-10vh", opacity: 0, scale: 1.5, rotate: heart.x }}
            exit={{ opacity: 0 }}
            transition={{ duration: 3, ease: "easeOut" }}
            className="absolute bottom-0"
          >
            <Heart className="size-10 text-rose-500 fill-rose-500 shadow-xl" />
          </motion.div>
        ))}
      </AnimatePresence>
    </div>
  );
}

// --- Gift Menu ---
const GIFTS = [
  { id: 1, name: "وردة", icon: "🌹", price: 10 },
  { id: 2, name: "قلب", icon: "❤️", price: 50 },
  { id: 3, name: "عطر", icon: "🧴", price: 100 },
  { id: 4, name: "نجمة", icon: "⭐", price: 200 },
  { id: 5, name: "شوكلاتة", icon: "🍫", price: 500 },
  { id: 6, name: "ماسة", icon: "💎", price: 1000 },
  { id: 7, name: "تاج", icon: "👑", price: 2000 },
  { id: 8, name: "سيارة", icon: "🚗", price: 5000 },
  { id: 9, name: "قصر", icon: "🏰", price: 10000 },
  { id: 10, name: "أسد", icon: "🦁", price: 20000 },
];

type MicSlotUser = {
  id: string;
  name: string;
  avatar: string;
  isMuted: boolean;
  isSpeaking: boolean;
  role?: string;
  isOwner?: boolean;
  hasVipFrame?: boolean;
  level?: number;
};

// Admin Action Logging System (localStorage-based for cross-component access)
type AdminActionLog = {
  id: string;
  action: string;
  actionType: 'kick' | 'mute' | 'admin' | 'settings';
  performedBy: string;
  targetUser?: string;
  roomName: string;
  timestamp: string;
};

type OwnerNotification = {
  id: string;
  message: string;
  read: boolean;
  timestamp: string;
};

const logAdminAction = (log: Omit<AdminActionLog, 'id' | 'timestamp'>) => {
  try {
    const existingLogs = JSON.parse(localStorage.getItem('adminActionLogs') || '[]') as AdminActionLog[];
    const newLog: AdminActionLog = {
      ...log,
      id: crypto.randomUUID(),
      timestamp: new Date().toISOString(),
    };
    existingLogs.unshift(newLog);
    localStorage.setItem('adminActionLogs', JSON.stringify(existingLogs.slice(0, 100)));
    
    // Dispatch custom event for real-time updates
    window.dispatchEvent(new CustomEvent('adminLogUpdated'));
  } catch (e) {
    console.error('Failed to log admin action:', e);
  }
};

const addOwnerNotification = (message: string) => {
  try {
    const existingNotifs = JSON.parse(localStorage.getItem('ownerNotifications') || '[]') as OwnerNotification[];
    const newNotif: OwnerNotification = {
      id: crypto.randomUUID(),
      message,
      read: false,
      timestamp: new Date().toISOString(),
    };
    existingNotifs.unshift(newNotif);
    localStorage.setItem('ownerNotifications', JSON.stringify(existingNotifs.slice(0, 50)));
    
    // Dispatch custom event for real-time updates
    window.dispatchEvent(new CustomEvent('ownerNotificationUpdated'));
  } catch (e) {
    console.error('Failed to add owner notification:', e);
  }
};

const getAdminActionLogs = (): AdminActionLog[] => {
  try {
    return JSON.parse(localStorage.getItem('adminActionLogs') || '[]');
  } catch {
    return [];
  }
};

const getOwnerNotifications = (): OwnerNotification[] => {
  try {
    return JSON.parse(localStorage.getItem('ownerNotifications') || '[]');
  } catch {
    return [];
  }
};

function VipKingFrame({ size = "normal" }: { size?: "small" | "normal" | "large" }) {
  const sizeClass = size === "small" ? "size-[72px]" : size === "large" ? "size-[140px]" : "size-20";
  return (
    <div className={`absolute inset-0 ${sizeClass} pointer-events-none z-20`}>
      <div className="absolute inset-[-4px] rounded-full bg-gradient-to-r from-yellow-400 via-amber-300 to-yellow-500 animate-spin-slow opacity-80" style={{ animationDuration: '3s' }} />
      <div className="absolute inset-[-2px] rounded-full bg-gradient-to-r from-yellow-300 via-orange-400 to-yellow-400 animate-pulse" />
      <div className="absolute inset-0 rounded-full border-2 border-yellow-400/50 shadow-[0_0_20px_rgba(251,191,36,0.6),inset_0_0_10px_rgba(251,191,36,0.3)]" />
      <div className="absolute -top-3 left-1/2 -translate-x-1/2 text-lg drop-shadow-[0_0_8px_rgba(251,191,36,0.8)]">👑</div>
      <div className="absolute -bottom-1 left-1/2 -translate-x-1/2 bg-gradient-to-r from-yellow-500 to-amber-400 text-[6px] font-black text-black px-1.5 py-0.5 rounded-full shadow-lg">VIP</div>
    </div>
  );
}

// Gift Explosion Effect Component with memoized particles
function GiftExplosionEffect({ giftIcon }: { giftIcon: string }) {
  const particles = useMemo(() => {
    const colors = ['#FFD700', '#FF6B6B', '#4ECDC4', '#A855F7', '#F43F5E', '#22C55E', '#3B82F6'];
    const emojis = ['✨', '💎', '⭐', '🌟', '💫'];
    return [...Array(50)].map((_, i) => {
      const angle = (i / 50) * Math.PI * 2;
      const velocity = 150 + Math.random() * 200;
      return {
        id: i,
        endX: Math.cos(angle) * velocity,
        endY: Math.sin(angle) * velocity,
        color: colors[Math.floor(Math.random() * colors.length)],
        rotation: Math.random() * 720 - 360,
        duration: 1.5 + Math.random(),
        emoji: i % 3 === 0 ? giftIcon : emojis[i % 5]
      };
    });
  }, [giftIcon]);

  return (
    <div className="fixed inset-0 z-[450] pointer-events-none overflow-hidden">
      {particles.map((p) => (
        <motion.div
          key={p.id}
          initial={{ 
            x: '50%', 
            y: '50%',
            scale: 0,
            opacity: 1
          }}
          animate={{ 
            x: `calc(50% + ${p.endX}px)`,
            y: `calc(50% + ${p.endY}px)`,
            scale: [0, 1.5, 0],
            opacity: [1, 1, 0],
            rotate: p.rotation
          }}
          transition={{ 
            duration: p.duration,
            ease: "easeOut"
          }}
          className="absolute text-2xl"
          style={{ 
            filter: `drop-shadow(0 0 10px ${p.color})`,
          }}
        >
          {p.emoji}
        </motion.div>
      ))}
      {/* Central Burst */}
      <motion.div
        initial={{ scale: 0, opacity: 0 }}
        animate={{ scale: [0, 3, 5], opacity: [0, 0.8, 0] }}
        transition={{ duration: 0.8 }}
        className="absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 size-20 rounded-full"
        style={{
          background: 'radial-gradient(circle, rgba(255,215,0,0.8) 0%, rgba(147,51,234,0.4) 50%, transparent 70%)'
        }}
      />
    </div>
  );
}

// Party Mode Particles Component with stable positions
function PartyModeParticles({ type }: { type: 'stars' | 'hearts' }) {
  const particles = useMemo(() => {
    return [...Array(20)].map((_, i) => ({
      id: i,
      left: Math.random() * 100,
      scale: 0.5 + Math.random() * 0.5,
      duration: 4 + Math.random() * 3,
      delay: Math.random() * 5,
      rotateDirection: Math.random() > 0.5 ? 1 : -1,
    }));
  }, []);

  return (
    <div className="absolute inset-0 pointer-events-none overflow-hidden z-0">
      {particles.map((p) => (
        <motion.div
          key={p.id}
          initial={{ 
            y: -50,
            opacity: 0,
            scale: p.scale,
            rotate: 0
          }}
          animate={{ 
            y: ['-50px', 'calc(100vh + 50px)'],
            opacity: [0, 1, 1, 0],
            rotate: 360 * p.rotateDirection
          }}
          transition={{ 
            duration: p.duration,
            repeat: Infinity,
            delay: p.delay,
            ease: "linear"
          }}
          className="absolute text-2xl"
          style={{ left: `${p.left}%` }}
        >
          {type === 'stars' ? '⭐' : '❤️'}
        </motion.div>
      ))}
    </div>
  );
}

function RoomView({ onExit, coins, setCoins, isOwner, currentRoom, userId }: { onExit: () => void; coins: number; setCoins: (c: number | ((prev: number) => number)) => void; isOwner: boolean; currentRoom: Room | null; userId?: string }) {
  const { user } = useAuth();
  const [muted, setMuted] = useState(false);
  const [activeSpeaker, setActiveSpeaker] = useState<number | null>(null);
  const [showEmojis, setShowEmojis] = useState(false);
  const [showGifts, setShowGifts] = useState(false);
  const [showChat, setShowChat] = useState(false);
  const [showRoomSettings, setShowRoomSettings] = useState(false);
  const [showListenersPopup, setShowListenersPopup] = useState(false);
  const [showRoomTools, setShowRoomTools] = useState(false);
  const [chatMessage, setChatMessage] = useState("");
  const [heartTrigger, setHeartTrigger] = useState(0);
  const [activeGift, setActiveGift] = useState<{ icon: string; targetId: number } | null>(null);
  const [showKingEntry, setShowKingEntry] = useState(false);
  const [showGiftExplosion, setShowGiftExplosion] = useState<string | null>(null);
  const [audioLevel, setAudioLevel] = useState(0);
  const [allMuted, setAllMuted] = useState(false);
  const [selectedSpeaker, setSelectedSpeaker] = useState<number | null>(null);
  const [selectedUser, setSelectedUser] = useState<MicSlotUser | null>(null);
  const [roomListeners, setRoomListeners] = useState<MicSlotUser[]>([
    { id: "listener1", name: "محمد", avatar: "https://api.dicebear.com/7.x/avataaars/svg?seed=listener1", level: 5, hasVipFrame: false, isSpeaking: false, isMuted: false },
    { id: "listener2", name: "أحمد", avatar: "https://api.dicebear.com/7.x/avataaars/svg?seed=listener2", level: 3, hasVipFrame: false, isSpeaking: false, isMuted: false },
    { id: "listener3", name: "سارة", avatar: "https://api.dicebear.com/7.x/avataaars/svg?seed=listener3", level: 8, hasVipFrame: true, isSpeaking: false, isMuted: false },
  ]);
  const [micSlots, setMicSlots] = useState<Record<number, MicSlotUser | null>>({
    0: null, // Host slot (reserved for room creator)
    1: null, 2: null, 3: null, 4: null,
    5: null, 6: null, 7: null, 8: null
  });
  const [mySlot, setMySlot] = useState<number | null>(null);
  const [roomLocked, setRoomLocked] = useState(false);
  const [roomPassword, setRoomPassword] = useState("");
  const [showPasswordInput, setShowPasswordInput] = useState(false);
  const [moderators, setModerators] = useState<string[]>([]);
  const [bannedUsers, setBannedUsers] = useState<string[]>([]);
  const [kickedUsers, setKickedUsers] = useState<string[]>([]);
  const [messages, setMessages] = useState<{ user: string; text: string; role?: string; isOwner?: boolean }[]>([]);
  const [audioStream, setAudioStream] = useState<MediaStream | null>(null);
  const [showMusicPlayer, setShowMusicPlayer] = useState(false);
  const [currentTrack, setCurrentTrack] = useState(0);
  const [isPlaying, setIsPlaying] = useState(false);
  const [musicVolume, setMusicVolume] = useState(50);
  const musicAudioRef = useRef<HTMLAudioElement | null>(null);
  const [localAudioFile, setLocalAudioFile] = useState<File | null>(null);
  const [localAudioPlaying, setLocalAudioPlaying] = useState(false);
  const [localAudioName, setLocalAudioName] = useState("");
  const localAudioRef = useRef<HTMLAudioElement | null>(null);
  const localAudioInputRef = useRef<HTMLInputElement | null>(null);
  const [showStudio, setShowStudio] = useState(false);
  const [audioProgress, setAudioProgress] = useState(0);
  const [audioDuration, setAudioDuration] = useState(0);
  const [audioCurrentTime, setAudioCurrentTime] = useState(0);
  const [repeatMode, setRepeatMode] = useState(false);
  const [echoEffect, setEchoEffect] = useState(false);
  const studioAudioContextRef = useRef<AudioContext | null>(null);
  const echoNodeRef = useRef<DelayNode | null>(null);
  const gainNodeRef = useRef<GainNode | null>(null);
  
  // Global Theme State (real-time sync)
  const [globalMicFrame, setGlobalMicFrame] = useState<'gold' | 'purple' | 'default'>(() => {
    return (localStorage.getItem('globalMicFrameColor') as 'gold' | 'purple' | 'default') || 'default';
  });
  const [globalParty, setGlobalParty] = useState<'off' | 'stars' | 'hearts'>(() => {
    return (localStorage.getItem('globalPartyMode') as 'off' | 'stars' | 'hearts') || 'off';
  });
  const [globalBg, setGlobalBg] = useState<string>(() => {
    return localStorage.getItem('globalRoomBg') || '';
  });

  // Listen for global theme changes
  useEffect(() => {
    const handleThemeChange = () => {
      setGlobalMicFrame((localStorage.getItem('globalMicFrameColor') as 'gold' | 'purple' | 'default') || 'default');
      setGlobalParty((localStorage.getItem('globalPartyMode') as 'off' | 'stars' | 'hearts') || 'off');
      setGlobalBg(localStorage.getItem('globalRoomBg') || '');
    };
    
    window.addEventListener('globalThemeChanged', handleThemeChange);
    window.addEventListener('storage', handleThemeChange);
    
    return () => {
      window.removeEventListener('globalThemeChanged', handleThemeChange);
      window.removeEventListener('storage', handleThemeChange);
    };
  }, []);

  // Screenshot Protection - disable right-click and keyboard shortcuts
  useEffect(() => {
    const preventScreenshot = (e: KeyboardEvent) => {
      // Block Print Screen and common screenshot shortcuts
      if (
        e.key === 'PrintScreen' ||
        (e.ctrlKey && e.shiftKey && (e.key === 's' || e.key === 'S')) ||
        (e.metaKey && e.shiftKey && (e.key === '3' || e.key === '4' || e.key === '5'))
      ) {
        e.preventDefault();
        toast.error("لقطات الشاشة معطلة في الغرف لحماية الخصوصية", { duration: 3000 });
        return false;
      }
    };

    const preventContextMenu = (e: MouseEvent) => {
      e.preventDefault();
      return false;
    };

    // Add event listeners
    document.addEventListener('keydown', preventScreenshot);
    document.addEventListener('contextmenu', preventContextMenu);

    // Add CSS class to prevent selection
    document.body.classList.add('screenshot-protected');

    return () => {
      document.removeEventListener('keydown', preventScreenshot);
      document.removeEventListener('contextmenu', preventContextMenu);
      document.body.classList.remove('screenshot-protected');
    };
  }, []);

  // King Entry Effect - Show when owner enters room
  useEffect(() => {
    if (isOwner && user?.isOwner) {
      setShowKingEntry(true);
      // Auto hide after 4 seconds
      const timer = setTimeout(() => setShowKingEntry(false), 4000);
      return () => clearTimeout(timer);
    }
  }, [isOwner, user?.isOwner]);
  
  const musicTracks = [
    { name: "Chill Vibes", url: "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-1.mp3", icon: "🎵" },
    { name: "Deep House", url: "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-2.mp3", icon: "🎧" },
    { name: "Lo-Fi Beats", url: "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-3.mp3", icon: "🎶" },
    { name: "Arabic Mix", url: "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-4.mp3", icon: "🎤" },
    { name: "Party Mode", url: "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-5.mp3", icon: "🎉" },
  ];
  const audioContextRef = useRef<AudioContext | null>(null);
  const analyserRef = useRef<AnalyserNode | null>(null);
  const wsRef = useRef<WebSocket | null>(null);
  const peerConnectionsRef = useRef<Map<number, RTCPeerConnection>>(new Map());
  const remoteAudiosRef = useRef<Map<number, HTMLAudioElement>>(new Map());
  const localStreamRef = useRef<MediaStream | null>(null);
  const pendingOffersRef = useRef<Map<number, RTCSessionDescriptionInit>>(new Map());
  const SHARED_ROOM_ID = "shaqawchiya-main-room";
  
  const ICE_SERVERS = [
    { urls: "stun:stun.l.google.com:19302" },
    { urls: "stun:stun1.l.google.com:19302" },
  ];

  // Room owner is either app admin OR the user who created this room
  const isRoomOwner = isOwner || (currentRoom && userId && String(currentRoom.hostId) === String(userId)) || (currentRoom === null);
  const speakers = Object.entries(micSlots).filter(([_, u]) => u !== null).map(([slot]) => Number(slot));
  
  // Auto-place room host in slot 0 (but not global owner who watches as hidden admin)
  const hostAutoJoinTriggered = useRef(false);
  useEffect(() => {
    // Only trigger once per room entry
    if (hostAutoJoinTriggered.current) return;
    
    if (currentRoom && user && !user.isOwner && mySlot === null && !micSlots[0]) {
      // Check if current user is the room creator (host)
      const isHostOfRoom = String(currentRoom.hostId) === String(user.id);
      if (isHostOfRoom) {
        hostAutoJoinTriggered.current = true;
        // Delay slightly to ensure WebSocket is ready
        setTimeout(() => {
          joinMicSlot(0);
        }, 500);
      }
    }
  }, [currentRoom, user]);
  
  useEffect(() => {
    const protocol = window.location.protocol === "https:" ? "wss:" : "ws:";
    const wsUrl = `${protocol}//${window.location.host}/ws`;
    const ws = new WebSocket(wsUrl);
    wsRef.current = ws;
    
    ws.onopen = () => {
      console.log("WebSocket connected for voice signaling");
    };
    
    ws.onmessage = async (event) => {
      try {
        const message = JSON.parse(event.data);
        
        switch (message.type) {
          case "user-joined":
          case "existing-user": {
            const { userId, slotNumber, displayName, avatar, hasVipFrame, isOwner: userIsOwner, role } = message;
            setMicSlots(prev => ({
              ...prev,
              [slotNumber]: {
                id: userId,
                name: displayName,
                avatar,
                isMuted: false,
                isSpeaking: false,
                role,
                isOwner: userIsOwner,
                hasVipFrame
              }
            }));
            if (message.type === "user-joined") {
              setMessages(prev => [...prev, { 
                user: "النظام", 
                text: `🎤 ${displayName} صعد على المايك ${slotNumber}` 
              }]);
            }
            
            if (localStreamRef.current && user && userId !== user.id) {
              const pc = createPeerConnection(userId);
              const offer = await pc.createOffer();
              await pc.setLocalDescription(offer);
              ws.send(JSON.stringify({
                type: "offer",
                targetUserId: userId,
                sdp: offer,
                roomId: SHARED_ROOM_ID
              }));
            }
            break;
          }
          
          case "user-left": {
            const { userId, slotNumber } = message;
            setMicSlots(prev => ({ ...prev, [slotNumber]: null }));
            setMessages(prev => [...prev, { 
              user: "النظام", 
              text: `📤 مستخدم نزل من المايك ${slotNumber}` 
            }]);
            const pc = peerConnectionsRef.current.get(userId);
            if (pc) {
              pc.close();
              peerConnectionsRef.current.delete(userId);
            }
            const audio = remoteAudiosRef.current.get(userId);
            if (audio) {
              audio.pause();
              audio.srcObject = null;
              remoteAudiosRef.current.delete(userId);
            }
            break;
          }
          
          case "offer": {
            const { fromUserId, sdp } = message;
            if (localStreamRef.current) {
              let pc = peerConnectionsRef.current.get(fromUserId);
              if (!pc) {
                pc = createPeerConnection(fromUserId);
              }
              await pc.setRemoteDescription(new RTCSessionDescription(sdp));
              const answer = await pc.createAnswer();
              await pc.setLocalDescription(answer);
              ws.send(JSON.stringify({
                type: "answer",
                targetUserId: fromUserId,
                sdp: answer,
                roomId: SHARED_ROOM_ID
              }));
            } else {
              pendingOffersRef.current.set(fromUserId, sdp);
            }
            break;
          }
          
          case "answer": {
            const { fromUserId, sdp } = message;
            const pc = peerConnectionsRef.current.get(fromUserId);
            if (pc) {
              await pc.setRemoteDescription(new RTCSessionDescription(sdp));
            }
            break;
          }
          
          case "ice-candidate": {
            const { fromUserId, candidate } = message;
            const pc = peerConnectionsRef.current.get(fromUserId);
            if (pc && candidate) {
              try {
                await pc.addIceCandidate(new RTCIceCandidate(candidate));
              } catch (e) {
                console.warn("ICE candidate error:", e);
              }
            }
            break;
          }
          
          case "mute-status": {
            const { userId, isMuted: userMuted } = message;
            setMicSlots(prev => {
              const updated = { ...prev };
              for (const slot in updated) {
                if (updated[slot]?.id === userId) {
                  updated[slot] = { ...updated[slot]!, isMuted: userMuted };
                }
              }
              return updated;
            });
            break;
          }
        }
      } catch (err) {
        console.error("WebSocket message error:", err);
      }
    };
    
    ws.onerror = (error) => console.error("WebSocket error:", error);
    ws.onclose = () => console.log("WebSocket disconnected");
    
    return () => {
      if (ws.readyState === WebSocket.OPEN) {
        ws.send(JSON.stringify({ type: "leave-room" }));
      }
      ws.close();
      peerConnectionsRef.current.forEach(pc => pc.close());
      peerConnectionsRef.current.clear();
      remoteAudiosRef.current.forEach(audio => {
        audio.pause();
        audio.srcObject = null;
      });
      remoteAudiosRef.current.clear();
    };
  }, [user]);
  
  const createPeerConnection = (targetUserId: number): RTCPeerConnection => {
    const existing = peerConnectionsRef.current.get(targetUserId);
    if (existing) {
      existing.close();
    }
    
    const pc = new RTCPeerConnection({ iceServers: ICE_SERVERS });
    
    pc.onicecandidate = (event) => {
      if (event.candidate && wsRef.current?.readyState === WebSocket.OPEN) {
        wsRef.current.send(JSON.stringify({
          type: "ice-candidate",
          targetUserId,
          candidate: event.candidate,
          roomId: SHARED_ROOM_ID
        }));
      }
    };
    
    pc.ontrack = (event) => {
      let audio = remoteAudiosRef.current.get(targetUserId);
      if (!audio) {
        audio = new Audio();
        audio.autoplay = true;
        remoteAudiosRef.current.set(targetUserId, audio);
      }
      audio.srcObject = event.streams[0];
      audio.play().catch(console.error);
    };
    
    if (localStreamRef.current) {
      localStreamRef.current.getTracks().forEach(track => {
        pc.addTrack(track, localStreamRef.current!);
      });
    }
    
    peerConnectionsRef.current.set(targetUserId, pc);
    return pc;
  };
  
  const processPendingOffers = async () => {
    if (!localStreamRef.current || !wsRef.current) return;
    
    const entries = Array.from(pendingOffersRef.current.entries());
    for (const [fromUserId, sdp] of entries) {
      let pc = peerConnectionsRef.current.get(fromUserId);
      if (!pc) {
        pc = createPeerConnection(fromUserId);
      }
      await pc.setRemoteDescription(new RTCSessionDescription(sdp));
      const answer = await pc.createAnswer();
      await pc.setLocalDescription(answer);
      wsRef.current.send(JSON.stringify({
        type: "answer",
        targetUserId: fromUserId,
        sdp: answer,
        roomId: SHARED_ROOM_ID
      }));
    }
    pendingOffersRef.current.clear();
  };

  const joinMicSlot = async (slot: number) => {
    if (!user) {
      toast.error("يجب تسجيل الدخول أولاً");
      return;
    }
    
    // Global owner (MNTZR/شقاوچي) enters as hidden listener - no mic access
    if (user.isOwner && !isRoomOwner) {
      toast.info("أنت تراقب الغرفة كمدير عام 👁️");
      return;
    }
    
    // Slot 0 is reserved for room host only
    if (slot === 0 && !isRoomOwner) {
      toast.error("هذا المايك محجوز لصاحب الغرفة فقط 👑");
      return;
    }
    
    if (roomLocked && !isRoomOwner) {
      toast.error("الغرفة مقفلة 🔒");
      return;
    }
    if (bannedUsers.includes(user.id)) {
      toast.error("أنت محظور من هذه الغرفة ⛔");
      return;
    }
    if (mySlot !== null) {
      toast.error("أنت على مايك بالفعل! انزل أولاً");
      return;
    }
    if (micSlots[slot]) {
      toast.error("هذا المايك مشغول");
      return;
    }

    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      setAudioStream(stream);
      
      const audioContext = new AudioContext();
      const analyser = audioContext.createAnalyser();
      const source = audioContext.createMediaStreamSource(stream);
      source.connect(analyser);
      analyser.fftSize = 256;
      audioContextRef.current = audioContext;
      analyserRef.current = analyser;

      const userDisplayName = user.displayName || "مستخدم";
      const userAvatar = user.avatar || `https://api.dicebear.com/7.x/avataaars/svg?seed=${user.id}`;
      const userHasVipFrame = user.hasVipFrame || user.isOwner || user.role === 'super_admin';
      
      setMicSlots(prev => ({
        ...prev,
        [slot]: {
          id: user.id,
          name: userDisplayName,
          avatar: userAvatar,
          isMuted: false,
          isSpeaking: false,
          role: user.role || undefined,
          isOwner: user.isOwner || false,
          hasVipFrame: userHasVipFrame
        }
      }));
      setMySlot(slot);
      
      localStreamRef.current = stream;
      
      if (wsRef.current?.readyState === WebSocket.OPEN) {
        wsRef.current.send(JSON.stringify({
          type: "join-room",
          roomId: SHARED_ROOM_ID,
          userId: user.id,
          slotNumber: slot,
          displayName: userDisplayName,
          avatar: userAvatar,
          hasVipFrame: userHasVipFrame,
          isOwner: user.isOwner || false,
          role: user.role || undefined
        }));
      }
      
      await processPendingOffers();
      
      toast.success("تم الصعود على المايك 🎤");
    } catch (err) {
      toast.error("فشل الوصول للميكروفون - تأكد من السماح بالأذونات");
    }
  };

  const leaveMicSlot = () => {
    if (mySlot === null) return;
    
    if (wsRef.current?.readyState === WebSocket.OPEN) {
      wsRef.current.send(JSON.stringify({ type: "leave-room" }));
    }
    
    peerConnectionsRef.current.forEach(pc => pc.close());
    peerConnectionsRef.current.clear();
    
    if (localStreamRef.current) {
      localStreamRef.current.getTracks().forEach(track => track.stop());
      localStreamRef.current = null;
    }
    if (audioStream) {
      audioStream.getTracks().forEach(track => track.stop());
      setAudioStream(null);
    }
    if (audioContextRef.current) {
      audioContextRef.current.close();
      audioContextRef.current = null;
    }
    analyserRef.current = null;
    
    const userName = micSlots[mySlot]?.name || "مستخدم";
    setMicSlots(prev => ({ ...prev, [mySlot]: null }));
    setMySlot(null);
    setMuted(false);
    setActiveSpeaker(null);
    toast.success("نزلت من المايك 👋");
  };

  const toggleMyMute = () => {
    if (mySlot === null || !audioStream) return;
    
    const newMuted = !muted;
    audioStream.getAudioTracks().forEach(track => {
      track.enabled = !newMuted;
    });
    setMuted(newMuted);
    setMicSlots(prev => ({
      ...prev,
      [mySlot]: prev[mySlot] ? { ...prev[mySlot]!, isMuted: newMuted } : null
    }));
    
    if (wsRef.current?.readyState === WebSocket.OPEN && user) {
      wsRef.current.send(JSON.stringify({
        type: "mute-status",
        userId: user.id,
        isMuted: newMuted,
        roomId: SHARED_ROOM_ID
      }));
    }
    
    toast.success(newMuted ? "تم كتم المايك 🔇" : "تم فتح المايك 🎤");
  };

  useEffect(() => {
    if (!analyserRef.current || mySlot === null) return;
    
    const analyser = analyserRef.current;
    const dataArray = new Uint8Array(analyser.frequencyBinCount);
    
    const checkAudio = () => {
      if (!analyserRef.current || mySlot === null) return;
      analyser.getByteFrequencyData(dataArray);
      const average = dataArray.reduce((a, b) => a + b) / dataArray.length;
      const isSpeaking = average > 30 && !muted;
      
      setMicSlots(prev => {
        if (!prev[mySlot]) return prev;
        if (prev[mySlot]!.isSpeaking === isSpeaking) return prev;
        return { ...prev, [mySlot]: { ...prev[mySlot]!, isSpeaking } };
      });
      
      if (isSpeaking) {
        setActiveSpeaker(mySlot);
      } else if (activeSpeaker === mySlot) {
        setActiveSpeaker(null);
      }
    };
    
    const interval = setInterval(checkAudio, 100);
    return () => clearInterval(interval);
  }, [mySlot, muted, activeSpeaker]);

  useEffect(() => {
    return () => {
      if (audioStream) {
        audioStream.getTracks().forEach(track => track.stop());
      }
      if (audioContextRef.current) {
        audioContextRef.current.close();
      }
    };
  }, []);

  const muteAll = () => {
    setAllMuted(!allMuted);
    toast.success(allMuted ? "تم فتح المايكات للجميع 🎤" : "تم كتم الجميع 🔇");
  };

  const kickFromMic = (slot: number) => {
    const slotUser = micSlots[slot];
    if (!slotUser) return;
    
    if (slotUser.id === user?.id) {
      leaveMicSlot();
    } else {
      setMicSlots(prev => ({ ...prev, [slot]: null }));
    }
    setSelectedSpeaker(null);
    toast.success("تم سحب المايك بنجاح ✅");
  };

  const kickFromRoom = (slot: number) => {
    const slotUser = micSlots[slot];
    if (!slotUser) return;
    
    setKickedUsers(prev => [...prev, slotUser.id]);
    if (slotUser.id === user?.id) {
      leaveMicSlot();
    } else {
      setMicSlots(prev => ({ ...prev, [slot]: null }));
    }
    setSelectedSpeaker(null);
    toast.success("تم طرد المستخدم من الغرفة ✅");
  };

  const banFromRoom = (slot: number) => {
    const slotUser = micSlots[slot];
    if (!slotUser) return;
    
    setBannedUsers(prev => [...prev, slotUser.id]);
    if (slotUser.id === user?.id) {
      leaveMicSlot();
    } else {
      setMicSlots(prev => ({ ...prev, [slot]: null }));
    }
    setSelectedSpeaker(null);
    toast.success("تم حظر المستخدم نهائياً 🚫");
  };

  const makeModerator = (slot: number) => {
    const slotUser = micSlots[slot];
    if (!slotUser) return;
    
    if (moderators.includes(slotUser.id)) {
      setModerators(prev => prev.filter(m => m !== slotUser.id));
      toast.success("تم إزالة صلاحيات المشرف ❌");
    } else {
      setModerators(prev => [...prev, slotUser.id]);
      toast.success("تم تعيين المستخدم كمشرف ⭐");
    }
    setSelectedSpeaker(null);
  };

  // Unified user control functions with logging
  const roomName = currentRoom?.title || "غرفة غير معروفة";
  const performerName = user?.displayName || user?.username || "مستخدم";

  const makeUserModerator = (targetUser: MicSlotUser) => {
    const isRemoving = moderators.includes(targetUser.id);
    if (isRemoving) {
      setModerators(prev => prev.filter(m => m !== targetUser.id));
      toast.success("تم إزالة صلاحيات المشرف ❌");
    } else {
      setModerators(prev => [...prev, targetUser.id]);
      toast.success("تم تعيين المستخدم كمشرف ⭐");
    }
    
    // Log the action
    logAdminAction({
      action: isRemoving ? 'إزالة صلاحيات مشرف' : 'تعيين مشرف جديد',
      actionType: 'admin',
      performedBy: performerName,
      targetUser: targetUser.name,
      roomName,
    });
    
    // Notify owner if performed by moderator (not owner)
    if (!isOwner) {
      addOwnerNotification(`${performerName} قام ${isRemoving ? 'بإزالة' : 'بتعيين'} مشرف في ${roomName}`);
    }
    
    setSelectedUser(null);
  };

  const muteUser = (targetUser: MicSlotUser) => {
    const slotEntry = Object.entries(micSlots).find(([_, u]) => u?.id === targetUser.id);
    if (slotEntry) {
      const [slot, slotUser] = slotEntry;
      if (slotUser) {
        const wasMuted = slotUser.isMuted;
        setMicSlots(prev => ({
          ...prev,
          [slot]: { ...slotUser, isMuted: !slotUser.isMuted }
        }));
        toast.success(wasMuted ? "تم فتح المايك 🎙️" : "تم كتم المايك 🔇");
        
        // Log the action
        logAdminAction({
          action: wasMuted ? 'فتح مايك مستخدم' : 'كتم مايك مستخدم',
          actionType: 'mute',
          performedBy: performerName,
          targetUser: targetUser.name,
          roomName,
        });
      }
    }
    setSelectedUser(null);
  };

  const kickUser = (targetUser: MicSlotUser) => {
    const slotEntry = Object.entries(micSlots).find(([_, u]) => u?.id === targetUser.id);
    if (slotEntry) {
      const [slot] = slotEntry;
      setMicSlots(prev => ({ ...prev, [slot]: null }));
    }
    setRoomListeners(prev => prev.filter(l => l.id !== targetUser.id));
    toast.success("تم طرد المستخدم من الغرفة ✅");
    
    // Log the action
    logAdminAction({
      action: 'طرد مستخدم من الغرفة',
      actionType: 'kick',
      performedBy: performerName,
      targetUser: targetUser.name,
      roomName,
    });
    
    // Notify owner if performed by moderator (not owner)
    if (!isOwner) {
      addOwnerNotification(`${performerName} قام بطرد ${targetUser.name} من ${roomName}`);
    }
    
    setSelectedUser(null);
  };

  const putUserOnMic = (targetUser: MicSlotUser) => {
    const emptySlot = Object.entries(micSlots).find(([_, u]) => u === null);
    if (emptySlot) {
      const [slot] = emptySlot;
      setMicSlots(prev => ({ ...prev, [slot]: targetUser }));
      setRoomListeners(prev => prev.filter(l => l.id !== targetUser.id));
      toast.success("تم رفع المستخدم على المايك 🎙️");
    } else {
      toast.error("جميع المايكات ممتلئة!");
    }
    setSelectedUser(null);
  };

  const isUserOnMic = (targetUser: MicSlotUser) => {
    return Object.values(micSlots).some(u => u?.id === targetUser.id);
  };

  const toggleRoomLock = () => {
    const wasLocked = roomLocked;
    setRoomLocked(!roomLocked);
    toast.success(wasLocked ? "تم فتح الغرفة للجميع 🔓" : "تم قفل الغرفة 🔒");
    
    // Log the action
    logAdminAction({
      action: wasLocked ? 'فتح الغرفة للجميع' : 'قفل الغرفة',
      actionType: 'settings',
      performedBy: performerName,
      roomName,
    });
    
    // Notify owner if performed by moderator (not owner)
    if (!isOwner) {
      addOwnerNotification(`${performerName} قام ${wasLocked ? 'بفتح' : 'بقفل'} ${roomName}`);
    }
  };

  const clearChat = () => {
    setMessages([]);
    toast.success("تم مسح المحادثة 🗑️");
    
    // Log the action
    logAdminAction({
      action: 'مسح المحادثة',
      actionType: 'settings',
      performedBy: performerName,
      roomName,
    });
  };

  const playMusic = () => {
    if (!musicAudioRef.current) {
      musicAudioRef.current = new Audio(musicTracks[currentTrack].url);
      musicAudioRef.current.volume = musicVolume / 100;
      musicAudioRef.current.onended = () => nextTrack();
    }
    musicAudioRef.current.play();
    setIsPlaying(true);
    toast.success(`🎵 تشغيل: ${musicTracks[currentTrack].name}`);
  };

  const pauseMusic = () => {
    musicAudioRef.current?.pause();
    setIsPlaying(false);
  };

  const nextTrack = () => {
    const next = (currentTrack + 1) % musicTracks.length;
    setCurrentTrack(next);
    if (musicAudioRef.current) {
      musicAudioRef.current.src = musicTracks[next].url;
      if (isPlaying) musicAudioRef.current.play();
    }
  };

  const prevTrack = () => {
    const prev = currentTrack === 0 ? musicTracks.length - 1 : currentTrack - 1;
    setCurrentTrack(prev);
    if (musicAudioRef.current) {
      musicAudioRef.current.src = musicTracks[prev].url;
      if (isPlaying) musicAudioRef.current.play();
    }
  };

  const changeMusicVolume = (vol: number) => {
    setMusicVolume(vol);
    if (musicAudioRef.current) musicAudioRef.current.volume = vol / 100;
  };

  const selectTrack = (index: number) => {
    setCurrentTrack(index);
    if (musicAudioRef.current) {
      musicAudioRef.current.src = musicTracks[index].url;
      musicAudioRef.current.volume = musicVolume / 100;
      musicAudioRef.current.play();
      setIsPlaying(true);
    } else {
      musicAudioRef.current = new Audio(musicTracks[index].url);
      musicAudioRef.current.volume = musicVolume / 100;
      musicAudioRef.current.onended = () => nextTrack();
      musicAudioRef.current.play();
      setIsPlaying(true);
    }
    toast.success(`🎵 تشغيل: ${musicTracks[index].name}`);
  };

  const openLocalAudioPicker = () => {
    localAudioInputRef.current?.click();
  };

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = Math.floor(seconds % 60);
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  const handleLocalAudioSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      setLocalAudioFile(file);
      setLocalAudioName(file.name.replace(/\.[^/.]+$/, ""));
      const url = URL.createObjectURL(file);
      
      if (localAudioRef.current) {
        localAudioRef.current.pause();
      }
      
      localAudioRef.current = new Audio(url);
      localAudioRef.current.volume = 1;
      
      localAudioRef.current.onloadedmetadata = () => {
        setAudioDuration(localAudioRef.current?.duration || 0);
      };
      
      localAudioRef.current.ontimeupdate = () => {
        const current = localAudioRef.current?.currentTime || 0;
        const duration = localAudioRef.current?.duration || 1;
        setAudioCurrentTime(current);
        setAudioProgress((current / duration) * 100);
      };
      
      localAudioRef.current.onended = () => {
        if (repeatMode) {
          localAudioRef.current!.currentTime = 0;
          localAudioRef.current!.play();
        } else {
          setLocalAudioPlaying(false);
          setAudioProgress(0);
          setAudioCurrentTime(0);
        }
      };
      
      localAudioRef.current.play();
      setLocalAudioPlaying(true);
      setShowStudio(true);
      toast.success(`🎧 تشغيل: ${file.name}`);
    }
  };

  const toggleLocalAudio = () => {
    if (!localAudioRef.current) return;
    if (localAudioPlaying) {
      localAudioRef.current.pause();
      setLocalAudioPlaying(false);
    } else {
      localAudioRef.current.play();
      setLocalAudioPlaying(true);
    }
  };

  const seekAudio = (percent: number) => {
    if (!localAudioRef.current) return;
    const time = (percent / 100) * audioDuration;
    localAudioRef.current.currentTime = time;
    setAudioCurrentTime(time);
    setAudioProgress(percent);
  };

  const toggleRepeat = () => {
    setRepeatMode(!repeatMode);
    toast.success(repeatMode ? "تكرار متوقف" : "تكرار مفعل 🔁");
  };

  const toggleEcho = () => {
    setEchoEffect(!echoEffect);
    toast.success(echoEffect ? "صدى متوقف" : "صدى مفعل 🎭");
  };

  const stopLocalAudio = () => {
    if (localAudioRef.current) {
      localAudioRef.current.pause();
      localAudioRef.current.currentTime = 0;
    }
    setLocalAudioPlaying(false);
    setLocalAudioFile(null);
    setLocalAudioName("");
    setAudioProgress(0);
    setAudioCurrentTime(0);
    setShowStudio(false);
  };

  const unbanUser = (userId: string) => {
    setBannedUsers(prev => prev.filter(u => u !== userId));
    toast.success("تم إلغاء حظر المستخدم ✅");
  };

  const sendChatMessage = () => {
    if (chatMessage.trim()) {
      setMessages(prev => [...prev, { 
        user: user?.displayName || "أنا", 
        text: chatMessage,
        role: user?.role || undefined,
        isOwner: user?.isOwner || false
      }]);
      setChatMessage("");
    }
  };

  const emojis = ["❤️", "🔥", "👑", "✨", "👏", "😂", "🌹", "💎", "⭐", "🎉", "🍬", "🍭"];
  
  const sendEmoji = (emoji: string) => {
    setMessages(prev => [...prev, { user: "أنا", text: emoji }]);
    setShowEmojis(false);
    if (emoji === "❤️" || emoji === "🌹") {
      setHeartTrigger(prev => prev + 1);
    }
  };

  const sendGift = (gift: typeof GIFTS[0]) => {
    if (coins < gift.price) {
      toast.error("رصيدك غير كافٍ لشراء هذه الهدية! 💎");
      return;
    }
    
    setCoins(prev => prev - gift.price);
    setShowGifts(false);
    
    // Show gift animation on a speaker (mock targeting speaker 1)
    setActiveGift({ icon: gift.icon, targetId: 1 });
    
    // Trigger particle explosion effect
    setShowGiftExplosion(gift.icon);
    setTimeout(() => setShowGiftExplosion(null), 3000);
    
    toast.success(`تم إرسال ${gift.name} بنجاح!`);
    
    setTimeout(() => setActiveGift(null), 3000);
    
    setMessages(prev => [...prev, { user: "أنا", text: `أرسل هدية: ${gift.icon} ${gift.name}` }]);
  };

  useEffect(() => {
    const interval = setInterval(() => {
      setActiveSpeaker(prev => (prev === null ? Math.floor(Math.random() * 8) + 1 : null));
    }, 3000);
    return () => clearInterval(interval);
  }, []);

  useVoiceChat(true);

  return (
    <motion.div 
      initial={{ y: "100%" }}
      animate={{ y: 0 }}
      exit={{ y: "100%" }}
      transition={{ type: "spring", damping: 25, stiffness: 200 }}
      className="fixed inset-0 z-[300] flex flex-col font-cairo overflow-hidden"
    >
      {/* Moon Background Image - Aspect Fill (supports global custom background) */}
      <div className="absolute inset-0">
        <img 
          src={globalBg || "/room-bg-moon.jpg"} 
          alt="" 
          className="w-full h-full object-cover"
        />
        {/* Vignette Effect - Darkened Edges */}
        <div 
          className="absolute inset-0" 
          style={{
            background: 'radial-gradient(ellipse at center, transparent 30%, rgba(0,0,0,0.6) 70%, rgba(0,0,0,0.9) 100%)'
          }}
        />
        {/* Light Purple Moonlight Overlay */}
        <div className="absolute inset-0 bg-purple-900/20 mix-blend-overlay" />
      </div>

      <FloatingHearts trigger={heartTrigger} />
      
      {/* Party Mode Particles - Stable positions using useMemo pattern */}
      {globalParty !== 'off' && (
        <PartyModeParticles type={globalParty} />
      )}

      {/* King Entry Effect - Owner Welcome */}
      <AnimatePresence>
        {showKingEntry && (
          <>
            {/* Purple & Gold Flash */}
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: [0, 0.8, 0.3, 0.8, 0] }}
              transition={{ duration: 2, times: [0, 0.2, 0.5, 0.7, 1] }}
              className="fixed inset-0 z-[500] pointer-events-none"
              style={{
                background: 'linear-gradient(45deg, rgba(147,51,234,0.6) 0%, rgba(255,215,0,0.5) 50%, rgba(147,51,234,0.6) 100%)'
              }}
            />
            {/* King Entry Popup */}
            <motion.div 
              initial={{ scale: 0, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.8, opacity: 0 }}
              transition={{ type: "spring", damping: 15, stiffness: 200 }}
              className="fixed inset-0 z-[501] flex items-center justify-center pointer-events-none"
            >
              <div className="bg-black/80 backdrop-blur-2xl border-2 border-amber-400/50 rounded-3xl p-8 shadow-[0_0_60px_rgba(255,215,0,0.4)]">
                <div className="text-center">
                  <motion.div 
                    animate={{ rotate: [0, -10, 10, -10, 0], scale: [1, 1.2, 1] }}
                    transition={{ duration: 0.8, repeat: 2 }}
                    className="text-6xl mb-4"
                  >
                    👑
                  </motion.div>
                  <h2 className="text-2xl font-black text-transparent bg-clip-text bg-gradient-to-r from-amber-300 via-yellow-400 to-amber-500">
                    المالك في الغرفة
                  </h2>
                  <p className="text-sm text-amber-200/60 mt-2">مرحباً بالمالك شقاوچي</p>
                  <motion.div 
                    className="mt-4 flex justify-center gap-1"
                    animate={{ opacity: [0.5, 1, 0.5] }}
                    transition={{ duration: 1.5, repeat: Infinity }}
                  >
                    {['✨', '💎', '⭐', '💎', '✨'].map((emoji, i) => (
                      <span key={i} className="text-lg">{emoji}</span>
                    ))}
                  </motion.div>
                </div>
              </div>
            </motion.div>
          </>
        )}
      </AnimatePresence>

      {/* Gift Explosion Particles Effect - Memoized */}
      <AnimatePresence>
        {showGiftExplosion && (
          <GiftExplosionEffect giftIcon={showGiftExplosion} />
        )}
      </AnimatePresence>

      {/* Top Header Bar - New Design */}
      <div className="p-3 flex items-center justify-between relative z-10">
        {/* Left Side - Exit, Share, Settings */}
        <div className="flex items-center gap-1">
          <button 
            onClick={onExit}
            className="size-9 rounded-full bg-black/30 backdrop-blur-sm flex items-center justify-center border border-white/10"
          >
            <Power className="size-4 text-rose-400" />
          </button>
          <button 
            onClick={() => toast.info("تم نسخ رابط الغرفة!")}
            className="size-9 rounded-full bg-black/30 backdrop-blur-sm flex items-center justify-center border border-white/10"
          >
            <Share2 className="size-4 text-white/70" />
          </button>
          {isRoomOwner && (
            <button 
              onClick={() => setShowRoomSettings(true)}
              className="size-9 rounded-full bg-black/30 backdrop-blur-sm flex items-center justify-center border border-white/10"
            >
              <Settings className="size-4 text-white/70" />
            </button>
          )}
        </div>
        
        {/* Right Side - Attendees Count */}
        <button 
          onClick={() => setShowListenersPopup(true)}
          className="flex items-center gap-1 bg-black/30 backdrop-blur-sm px-3 py-1.5 rounded-full border border-white/10"
        >
          <Users className="size-4 text-purple-300" />
          <span className="text-sm font-bold text-white">{speakers.length + roomListeners.length || 1}</span>
        </button>
      </div>

      {/* Host Mic Section - 1+8 Layout */}
      <div className="flex flex-col items-center relative z-10 pt-4">
        {/* Host (Room Creator) - Distinguished Top Mic */}
        <div className="relative mb-6">
          <motion.div 
            whileTap={{ scale: 0.95 }}
            onClick={() => {
              // Host can click to leave/join their slot
              if (micSlots[0]?.id === user?.id) {
                leaveMicSlot();
              } else if (isRoomOwner && !micSlots[0]) {
                joinMicSlot(0);
              }
            }}
            className="relative cursor-pointer"
          >
            <div className={cn(
              "size-20 rounded-full p-[3px] shadow-[0_0_40px_rgba(192,132,252,0.6)]",
              globalMicFrame === 'gold' 
                ? "bg-gradient-to-br from-amber-300 via-yellow-400 to-amber-500"
                : globalMicFrame === 'purple'
                  ? "bg-gradient-to-br from-fuchsia-300 via-pink-400 to-fuchsia-500"
                  : "bg-gradient-to-br from-purple-300 via-violet-400 to-purple-500"
            )}>
              <div className="size-full rounded-full overflow-hidden bg-purple-900 flex items-center justify-center">
                {micSlots[0] ? (
                  <img 
                    src={micSlots[0].avatar}
                    alt="Host"
                    className="size-full object-cover"
                  />
                ) : currentRoom?.host ? (
                  <img 
                    src={currentRoom.host.avatar || `https://api.dicebear.com/7.x/avataaars/svg?seed=${currentRoom.hostId || 'host'}`}
                    alt="Host"
                    className="size-full object-cover"
                  />
                ) : (
                  <Crown className="size-8 text-amber-400" />
                )}
              </div>
            </div>
            {/* Host Crown Badge */}
            <div className="absolute -top-2 left-1/2 -translate-x-1/2 text-xl z-30">👑</div>
            {/* Host Mic Badge - shows speaking/muted status */}
            {micSlots[0] ? (
              micSlots[0].isMuted || allMuted ? (
                <div className="absolute -bottom-1 right-0 size-8 bg-rose-500 rounded-full flex items-center justify-center border-2 border-rose-300 shadow-lg">
                  <MicOff className="size-4 text-white" />
                </div>
              ) : micSlots[0].isSpeaking ? (
                <div className="absolute -bottom-1 right-0 size-8 bg-green-500 rounded-full flex items-center justify-center border-2 border-green-300 shadow-lg animate-pulse">
                  <Mic className="size-4 text-white" />
                </div>
              ) : (
                <div className={cn(
                  "absolute -bottom-1 right-0 size-8 rounded-full flex items-center justify-center border-2 shadow-lg",
                  globalMicFrame === 'gold' 
                    ? "bg-gradient-to-br from-amber-400 to-yellow-500 border-amber-200"
                    : globalMicFrame === 'purple'
                      ? "bg-gradient-to-br from-fuchsia-400 to-pink-500 border-fuchsia-200"
                      : "bg-gradient-to-br from-purple-300 to-violet-500 border-purple-200"
                )}>
                  <Mic className="size-4 text-white" />
                </div>
              )
            ) : (
              <div className={cn(
                "absolute -bottom-1 right-0 size-8 rounded-full flex items-center justify-center border-2 shadow-lg",
                globalMicFrame === 'gold' 
                  ? "bg-gradient-to-br from-amber-400 to-yellow-500 border-amber-200"
                  : globalMicFrame === 'purple'
                    ? "bg-gradient-to-br from-fuchsia-400 to-pink-500 border-fuchsia-200"
                    : "bg-gradient-to-br from-purple-300 to-violet-500 border-purple-200"
              )}>
                <Mic className="size-4 text-white" />
              </div>
            )}
          </motion.div>
          
          {/* Host Name */}
          <div className="text-center mt-2">
            <h3 className="text-sm font-black text-white" style={{ fontFamily: 'Cairo, sans-serif' }}>
              {micSlots[0]?.name || currentRoom?.host?.name || currentRoom?.title || "مضيف الغرفة"}
            </h3>
            <div className="flex items-center justify-center gap-1">
              <span className="text-[10px] text-amber-400 font-bold">صاحب الغرفة</span>
            </div>
          </div>
        </div>
      </div>
      
      {/* 8 Mic Slots - Transparent Circular Design */}
      <div className="flex-1 flex flex-col justify-center px-6 pb-4 relative z-10">
        {/* Mic Grid - 8 Transparent Circles with Numbers */}
        <div className="grid grid-cols-4 gap-x-4 gap-y-6">
          {[1,2,3,4,5,6,7,8].map(i => {
            const slotUser = micSlots[i];
            const isOnMic = slotUser !== null;
            const isMuted = (allMuted && isOnMic) || slotUser?.isMuted;
            const isMe = slotUser?.id === user?.id;
            const isSpeaking = slotUser?.isSpeaking && !isMuted;
            
            const handleSlotClick = () => {
              if (!isOnMic) {
                joinMicSlot(i);
              } else if (isMe) {
                leaveMicSlot();
              } else if (isRoomOwner || moderators.includes(user?.id || '')) {
                if (slotUser) {
                  setSelectedUser(slotUser);
                }
              }
            };
            
            return (
              <motion.div 
                key={i}
                whileTap={{ scale: 0.95 }}
                onClick={handleSlotClick}
                data-testid={`mic-slot-${i}`}
                className="flex flex-col items-center gap-2"
              >
                <div className={cn(
                  "size-16 rounded-full flex items-center justify-center relative transition-all duration-300 cursor-pointer",
                  isOnMic 
                    ? "bg-purple-500/30 border-2 border-purple-400/60 shadow-[0_0_20px_rgba(147,51,234,0.4)]"
                    : "bg-white/10 border-2 border-white/20 backdrop-blur-sm",
                  isSpeaking && "ring-2 ring-green-400 shadow-[0_0_30px_rgba(34,197,94,0.6)]"
                )}>
                  {isOnMic ? (
                    <>
                      <Avatar className="size-full">
                        <AvatarImage src={slotUser.avatar} />
                        <AvatarFallback className="bg-purple-600 text-white text-sm font-bold">
                          {slotUser.name.charAt(0)}
                        </AvatarFallback>
                      </Avatar>
                      {slotUser.hasVipFrame && (
                        <div className="absolute -top-2 left-1/2 -translate-x-1/2 text-sm z-30">👑</div>
                      )}
                      {isSpeaking && (
                        <motion.div 
                          className="absolute inset-0 rounded-full z-10"
                          animate={{ scale: [1, 1.1, 1], opacity: [0.5, 0.2, 0.5] }}
                          transition={{ duration: 0.8, repeat: Infinity }}
                          style={{ background: 'radial-gradient(circle, transparent 50%, rgba(34,197,94,0.4) 100%)' }}
                        />
                      )}
                      {isMuted && (
                        <div className="absolute -bottom-1 -right-1 size-5 bg-rose-500 rounded-full flex items-center justify-center z-30">
                          <MicOff className="size-3 text-white" />
                        </div>
                      )}
                    </>
                  ) : (
                    <Plus className="size-6 text-white/50" strokeWidth={1.5} />
                  )}
                </div>
                
                {/* Slot Number Label */}
                <span className="text-xs text-white/60 font-bold">{i}</span>
              </motion.div>
            );
          })}
        </div>
      </div>
      
      {/* Invite Friends Popup - Blue */}
      <div className="px-4 pb-3 relative z-10">
        <button 
          onClick={() => toast.success("تم نسخ رابط الدعوة!")}
          className="w-full bg-blue-500/90 backdrop-blur-sm rounded-2xl py-3 flex items-center justify-center gap-2"
        >
          <UserPlus className="size-5 text-white" />
          <span className="text-white font-bold text-sm">دعوة الأصدقاء</span>
        </button>
      </div>

      {/* متواجدون في الغرفة - White Bottom Sheet */}
      <AnimatePresence>
        {showListenersPopup && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-[500] bg-black/40"
            onClick={() => setShowListenersPopup(false)}
          >
            <motion.div
              initial={{ y: '100%' }}
              animate={{ y: 0 }}
              exit={{ y: '100%' }}
              transition={{ type: 'spring', damping: 25, stiffness: 300 }}
              onClick={(e) => e.stopPropagation()}
              className="absolute bottom-0 left-0 right-0 bg-white rounded-t-3xl p-6 max-h-[50vh] overflow-y-auto"
            >
              <div className="w-12 h-1 bg-gray-300 rounded-full mx-auto mb-4" />
              <h3 className="text-center text-lg font-bold text-gray-800 mb-6" style={{ fontFamily: 'Cairo, sans-serif' }}>
                متواجدون في الغرفة
              </h3>
              
              <div className="space-y-3">
                {/* Show all people on mic */}
                {Object.entries(micSlots).filter(([_, u]) => u !== null).map(([slot, slotUser]) => (
                  <div
                    key={`mic-${slot}`}
                    className="flex items-center justify-between py-2"
                  >
                    <div className="flex items-center gap-3">
                      <span className="text-gray-800 font-medium" style={{ fontFamily: 'Cairo, sans-serif' }}>
                        {slotUser?.name}
                        {slot === '0' && (
                          <span className="text-purple-600 text-sm mr-2">مالك</span>
                        )}
                      </span>
                    </div>
                    <Avatar className="size-12 border-2 border-purple-200">
                      <AvatarImage src={slotUser?.avatar} />
                      <AvatarFallback className="bg-purple-100 text-purple-600">
                        {slotUser?.name?.charAt(0)}
                      </AvatarFallback>
                    </Avatar>
                  </div>
                ))}
                
                {/* Show all listeners */}
                {roomListeners.map((listener) => (
                  <div
                    key={`listener-${listener.id}`}
                    className="flex items-center justify-between py-2"
                  >
                    <div className="flex items-center gap-3">
                      <span className="text-gray-800 font-medium" style={{ fontFamily: 'Cairo, sans-serif' }}>
                        {listener.name}
                      </span>
                    </div>
                    <Avatar className="size-12 border-2 border-gray-200">
                      <AvatarImage src={listener.avatar} />
                      <AvatarFallback className="bg-gray-100 text-gray-600">
                        {listener.name.charAt(0)}
                      </AvatarFallback>
                    </Avatar>
                  </div>
                ))}
                
                {speakers.length === 0 && roomListeners.length === 0 && (
                  <div className="text-center py-8 text-gray-400">
                    <Users className="size-10 mx-auto mb-2 opacity-50" />
                    <span className="text-sm">لا يوجد متواجدون حالياً</span>
                  </div>
                )}
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Unified User Control Panel */}
      <AnimatePresence>
        {selectedUser && (isRoomOwner || moderators.includes(user?.id || '')) && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-[500] bg-black/60 backdrop-blur-xl flex items-center justify-center p-4"
            onClick={() => setSelectedUser(null)}
          >
            <motion.div
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              onClick={(e) => e.stopPropagation()}
              className="bg-black/70 backdrop-blur-2xl rounded-3xl p-5 w-full max-w-sm border border-white/20 shadow-2xl shadow-purple-500/20"
            >
              <div className="flex items-center justify-between mb-4">
                <div className="flex items-center gap-3">
                  <div className="relative">
                    <Avatar className="size-14">
                      <AvatarImage src={selectedUser.avatar} />
                      <AvatarFallback className="bg-purple-600 text-white font-bold">
                        {selectedUser.name.charAt(0)}
                      </AvatarFallback>
                    </Avatar>
                    {moderators.includes(selectedUser.id) && (
                      <div className="absolute -top-1 left-1/2 -translate-x-1/2 text-sm">👑</div>
                    )}
                  </div>
                  <div>
                    <div className="text-white text-lg font-bold">{selectedUser.name}</div>
                    <div className="text-purple-400/60 text-xs">
                      {moderators.includes(selectedUser.id) ? 'مشرف' : 'مستخدم'} • المستوى {selectedUser.level || 1}
                    </div>
                  </div>
                </div>
                <button 
                  onClick={() => setSelectedUser(null)}
                  className="size-8 rounded-full bg-white/10 flex items-center justify-center"
                >
                  <X className="size-4 text-white" />
                </button>
              </div>
              
              <div className="grid grid-cols-2 gap-3">
                {/* Give Admin Button */}
                {isRoomOwner && selectedUser.id !== user?.id && (
                  <button
                    onClick={() => makeUserModerator(selectedUser)}
                    className={cn(
                      "flex flex-col items-center justify-center gap-2 rounded-2xl py-4 px-3 transition-colors",
                      moderators.includes(selectedUser.id)
                        ? "bg-gray-500/20 hover:bg-gray-500/30 text-gray-400"
                        : "bg-amber-500/20 hover:bg-amber-500/30 text-amber-400"
                    )}
                  >
                    <Crown className="size-6" />
                    <span className="text-xs font-bold">
                      {moderators.includes(selectedUser.id) ? 'إزالة الإدمن' : 'إعطاء إدمن'}
                    </span>
                  </button>
                )}
                
                {/* Mute Button - Only for users on mic */}
                {isUserOnMic(selectedUser) && (
                  <button
                    onClick={() => muteUser(selectedUser)}
                    className="flex flex-col items-center justify-center gap-2 bg-purple-500/20 hover:bg-purple-500/30 text-purple-400 rounded-2xl py-4 px-3 transition-colors"
                  >
                    <MicOff className="size-6" />
                    <span className="text-xs font-bold">كتم</span>
                  </button>
                )}
                
                {/* Kick Button */}
                <button
                  onClick={() => kickUser(selectedUser)}
                  className="flex flex-col items-center justify-center gap-2 bg-rose-500/20 hover:bg-rose-500/30 text-rose-400 rounded-2xl py-4 px-3 transition-colors"
                >
                  <UserMinus className="size-6" />
                  <span className="text-xs font-bold">طرد</span>
                </button>
                
                {/* Put on Mic Button - Only for listeners not on mic */}
                {!isUserOnMic(selectedUser) && (
                  <button
                    onClick={() => putUserOnMic(selectedUser)}
                    className="flex flex-col items-center justify-center gap-2 bg-green-500/20 hover:bg-green-500/30 text-green-400 rounded-2xl py-4 px-3 transition-colors"
                  >
                    <Mic className="size-6" />
                    <span className="text-xs font-bold">رفع على المايك</span>
                  </button>
                )}
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Speaker Action Menu */}
      <AnimatePresence>
        {selectedSpeaker !== null && micSlots[selectedSpeaker] && (isRoomOwner || moderators.includes(user?.id || '')) && (
          <motion.div
            initial={{ opacity: 0, scale: 0.9, y: 10 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.9, y: 10 }}
            className="mx-4 mt-3 bg-black/90 backdrop-blur-xl rounded-2xl p-3 border border-purple-500/30 relative z-50"
          >
            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center gap-2">
                <Avatar className="size-8">
                  <AvatarImage src={micSlots[selectedSpeaker]?.avatar} />
                  <AvatarFallback className="bg-purple-600 text-white text-xs">
                    {micSlots[selectedSpeaker]?.name.charAt(0)}
                  </AvatarFallback>
                </Avatar>
                <div>
                  <div className="text-white text-sm font-bold">{micSlots[selectedSpeaker]?.name}</div>
                  <div className="text-purple-400/60 text-[10px]">
                    {moderators.includes(micSlots[selectedSpeaker]?.id || '') ? 'مشرف 👑' : 'مستخدم'}
                  </div>
                </div>
              </div>
              <button 
                onClick={() => setSelectedSpeaker(null)}
                className="size-6 rounded-full bg-white/10 flex items-center justify-center"
              >
                <X className="size-3 text-white" />
              </button>
            </div>
            
            <div className="grid grid-cols-2 gap-2">
              {/* Mute/Unmute Button */}
              <button
                onClick={() => {
                  const slotUser = micSlots[selectedSpeaker];
                  if (slotUser) {
                    setMicSlots(prev => ({
                      ...prev,
                      [selectedSpeaker]: { ...slotUser, isMuted: !slotUser.isMuted }
                    }));
                    toast.success(slotUser.isMuted ? "تم فتح المايك 🎙️" : "تم كتم المايك 🔇");
                  }
                  setSelectedSpeaker(null);
                }}
                className="flex items-center justify-center gap-2 bg-amber-500/20 hover:bg-amber-500/30 text-amber-400 rounded-xl py-2 px-3 transition-colors"
              >
                {micSlots[selectedSpeaker]?.isMuted ? <Mic className="size-4" /> : <MicOff className="size-4" />}
                <span className="text-xs font-medium">{micSlots[selectedSpeaker]?.isMuted ? 'فتح المايك' : 'كتم المايك'}</span>
              </button>
              
              {/* Kick Button */}
              <button
                onClick={() => {
                  const slotUser = micSlots[selectedSpeaker];
                  if (!slotUser) return;
                  if (slotUser.id === user?.id) {
                    leaveMicSlot();
                  } else {
                    setMicSlots(prev => ({ ...prev, [selectedSpeaker]: null }));
                  }
                  setSelectedSpeaker(null);
                  toast.success("تم طرد المستخدم من الغرفة ✅");
                }}
                className="flex items-center justify-center gap-2 bg-rose-500/20 hover:bg-rose-500/30 text-rose-400 rounded-xl py-2 px-3 transition-colors"
              >
                <UserMinus className="size-4" />
                <span className="text-xs font-medium">طرد</span>
              </button>
              
              {/* Set as Admin Button - Only for Room Owner */}
              {isRoomOwner && micSlots[selectedSpeaker]?.id !== user?.id && (
                <button
                  onClick={() => makeModerator(selectedSpeaker)}
                  className={cn(
                    "flex items-center justify-center gap-2 rounded-xl py-2 px-3 transition-colors col-span-2",
                    moderators.includes(micSlots[selectedSpeaker]?.id || '')
                      ? "bg-gray-500/20 hover:bg-gray-500/30 text-gray-400"
                      : "bg-purple-500/20 hover:bg-purple-500/30 text-purple-400"
                  )}
                >
                  <Crown className="size-4" />
                  <span className="text-xs font-medium">
                    {moderators.includes(micSlots[selectedSpeaker]?.id || '') ? 'إزالة صلاحيات المشرف' : 'تعيين كمشرف'}
                  </span>
                </button>
              )}
              
              {/* Ban Button - Only for Room Owner */}
              {isRoomOwner && micSlots[selectedSpeaker]?.id !== user?.id && (
                <button
                  onClick={() => banFromRoom(selectedSpeaker)}
                  className="flex items-center justify-center gap-2 bg-red-600/20 hover:bg-red-600/30 text-red-400 rounded-xl py-2 px-3 transition-colors col-span-2"
                >
                  <Ban className="size-4" />
                  <span className="text-xs font-medium">حظر نهائي</span>
                </button>
              )}
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Professional Studio Control Panel */}
      <AnimatePresence>
        {showStudio && localAudioFile && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: 20 }}
            className="mx-4 mt-3 bg-black/80 backdrop-blur-xl rounded-3xl p-4 border border-amber-500/30 relative z-10 shadow-2xl shadow-amber-500/10"
          >
            {/* Studio Header */}
            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center gap-2">
                <div className="size-8 rounded-xl bg-gradient-to-br from-amber-500 to-orange-600 flex items-center justify-center">
                  <Music className="size-4 text-white" />
                </div>
                <div>
                  <div className="text-white text-xs font-black">استوديو البث</div>
                  <div className="text-amber-400/60 text-[9px]">مايك 1 - جودة عالية</div>
                </div>
              </div>
              <div className="flex items-center gap-1">
                {localAudioPlaying && (
                  <div className="flex gap-0.5 mx-2">
                    {[3,5,4,6,3,4,5].map((h, i) => (
                      <div key={i} className={`w-1 bg-gradient-to-t from-amber-500 to-orange-400 rounded-full animate-pulse`} style={{ height: `${h * 3}px`, animationDelay: `${i * 0.1}s` }} />
                    ))}
                  </div>
                )}
                <div className="bg-green-500/20 px-2 py-0.5 rounded-full">
                  <span className="text-[9px] font-bold text-green-400">LIVE</span>
                </div>
              </div>
            </div>

            {/* Track Info */}
            <div className="bg-white/5 rounded-2xl p-3 mb-3">
              <div className="flex items-center gap-3">
                <div className="size-12 rounded-xl bg-gradient-to-br from-purple-500 via-pink-500 to-rose-500 flex items-center justify-center text-2xl shadow-lg">
                  🎵
                </div>
                <div className="flex-1 min-w-0">
                  <div className="text-white text-sm font-bold truncate">{localAudioName}</div>
                  <div className="text-white/40 text-[10px]">{localAudioPlaying ? "🔊 يبث للغرفة الآن" : "⏸️ متوقف مؤقتاً"}</div>
                </div>
              </div>
            </div>

            {/* Progress Bar */}
            <div className="mb-3">
              <div 
                className="h-2 bg-white/10 rounded-full overflow-hidden cursor-pointer relative"
                onClick={(e) => {
                  const rect = e.currentTarget.getBoundingClientRect();
                  const percent = ((e.clientX - rect.left) / rect.width) * 100;
                  seekAudio(percent);
                }}
              >
                <div 
                  className="h-full bg-gradient-to-r from-amber-500 via-orange-500 to-rose-500 rounded-full transition-all duration-100 relative"
                  style={{ width: `${audioProgress}%` }}
                >
                  <div className="absolute right-0 top-1/2 -translate-y-1/2 size-3 bg-white rounded-full shadow-lg" />
                </div>
              </div>
              <div className="flex justify-between mt-1">
                <span className="text-[10px] text-white/40 font-mono">{formatTime(audioCurrentTime)}</span>
                <span className="text-[10px] text-white/40 font-mono">{formatTime(audioDuration)}</span>
              </div>
            </div>

            {/* Main Controls */}
            <div className="flex items-center justify-center gap-4 mb-3">
              <button 
                onClick={toggleRepeat}
                className={cn(
                  "size-10 rounded-full flex items-center justify-center transition-all",
                  repeatMode ? "bg-amber-500/30 text-amber-400" : "bg-white/10 text-white/40 hover:bg-white/20"
                )}
              >
                <span className="text-lg">🔁</span>
              </button>
              
              <button 
                onClick={toggleLocalAudio}
                className="size-14 rounded-full bg-gradient-to-br from-amber-500 to-orange-600 flex items-center justify-center shadow-xl shadow-amber-500/30 hover:scale-105 transition-transform"
              >
                {localAudioPlaying ? (
                  <div className="flex gap-1">
                    <div className="w-1.5 h-6 bg-white rounded-full" />
                    <div className="w-1.5 h-6 bg-white rounded-full" />
                  </div>
                ) : (
                  <div className="w-0 h-0 border-l-[14px] border-l-white border-y-[9px] border-y-transparent ml-1" />
                )}
              </button>
              
              <button 
                onClick={toggleEcho}
                className={cn(
                  "size-10 rounded-full flex items-center justify-center transition-all",
                  echoEffect ? "bg-purple-500/30 text-purple-400" : "bg-white/10 text-white/40 hover:bg-white/20"
                )}
              >
                <span className="text-lg">🎭</span>
              </button>
            </div>

            {/* Effect Labels */}
            <div className="flex items-center justify-center gap-6 mb-3">
              <div className="text-center">
                <span className={cn("text-[9px] font-bold", repeatMode ? "text-amber-400" : "text-white/30")}>تكرار</span>
              </div>
              <div className="text-center">
                <span className={cn("text-[9px] font-bold", echoEffect ? "text-purple-400" : "text-white/30")}>صدى صوت</span>
              </div>
            </div>

            {/* Stop Button */}
            <button 
              onClick={stopLocalAudio}
              className="w-full py-2.5 bg-rose-500/20 hover:bg-rose-500/30 rounded-2xl flex items-center justify-center gap-2 transition-colors border border-rose-500/30"
            >
              <MicOff className="size-4 text-rose-400" />
              <span className="text-xs font-bold text-rose-400">إيقاف البث</span>
            </button>
          </motion.div>
        )}
      </AnimatePresence>
      
      {/* Chat Messages Section */}
      <div className="flex-1 mt-2 px-4 overflow-y-auto space-y-2 relative z-10 max-h-[30vh]">
        <div className="bg-yellow-500/10 border border-yellow-500/20 rounded-2xl p-3 text-[11px] text-yellow-200/80 leading-relaxed">
          ⚠️ تنبيه: يرجى الالتزام بقوانين الغرفة والاحترام المتبادل. أي تجاوز يعرض حسابك للحظر الدائم.
        </div>
        
        {messages.map((msg, i) => (
          <motion.div 
            initial={{ opacity: 0, x: -10 }} 
            animate={{ opacity: 1, x: 0 }} 
            key={i} 
            className="flex items-start gap-2"
          >
            <div className="bg-white/5 rounded-2xl px-3 py-1.5 border border-white/5 max-w-[80%]">
              <div className="flex items-center gap-1 mb-0.5">
                {(msg.role === 'super_admin' || msg.isOwner) && (
                  <Crown className="size-3 text-yellow-400 fill-yellow-400" />
                )}
                <span className={cn(
                  "text-[10px] font-black",
                  (msg.role === 'super_admin' || msg.isOwner) ? "text-yellow-400" : "text-amber-400"
                )}>{msg.user}</span>
              </div>
              <p className="text-sm text-white/90">{msg.text}</p>
            </div>
          </motion.div>
        ))}
      </div>

      <div className="p-4 bg-black/40 backdrop-blur-2xl border-t border-white/5 relative z-20">
        <AnimatePresence>
          {showEmojis && (
            <motion.div 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: 20 }}
              className="absolute bottom-full left-4 mb-4 bg-black/80 backdrop-blur-xl border border-white/10 rounded-[24px] p-4 grid grid-cols-4 gap-3 shadow-2xl"
            >
              {emojis.map(e => (
                <button 
                  key={e} 
                  onClick={() => sendEmoji(e)}
                  className="size-10 flex items-center justify-center text-xl hover:bg-white/10 rounded-xl transition-colors"
                >
                  {e}
                </button>
              ))}
            </motion.div>
          )}
        </AnimatePresence>

        <AnimatePresence>
          {showGifts && (
            <motion.div 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: 20 }}
              className="absolute bottom-full right-4 mb-4 night-glass rounded-[32px] p-4 w-[280px] shadow-2xl overflow-hidden"
            >
              <div className="flex items-center justify-between mb-4 px-2">
                <h4 className="text-xs font-black text-white">إرسال هدية</h4>
                <div className="text-[10px] text-yellow-500 font-bold">{coins.toLocaleString()} 💎</div>
              </div>
              <div className="grid grid-cols-3 gap-2 max-h-[300px] overflow-y-auto no-scrollbar">
                {GIFTS.map(gift => (
                  <button 
                    key={gift.id} 
                    onClick={() => sendGift(gift)}
                    className="flex flex-col items-center gap-1 p-2 rounded-2xl hover:bg-white/5 border border-transparent hover:border-white/10 transition-all group"
                  >
                    <span className="text-2xl group-hover:scale-125 transition-transform">{gift.icon}</span>
                    <span className="text-[9px] font-bold text-white/60">{gift.name}</span>
                    <span className="text-[8px] font-black text-yellow-500">{gift.price} 💎</span>
                  </button>
                ))}
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        <AnimatePresence>
          {showChat && (
            <motion.div 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: 20 }}
              className="absolute bottom-full left-4 right-4 mb-4 bg-black/80 backdrop-blur-xl border border-white/10 rounded-[24px] p-4 shadow-2xl"
            >
              <div className="flex items-center gap-2">
                <input
                  type="text"
                  data-testid="input-chat-message"
                  value={chatMessage}
                  onChange={(e) => setChatMessage(e.target.value)}
                  onKeyDown={(e) => e.key === "Enter" && sendChatMessage()}
                  placeholder="اكتب رسالتك..."
                  className="flex-1 bg-white/10 border border-white/10 rounded-xl px-4 py-3 text-sm text-white placeholder:text-white/40 focus:outline-none focus:border-amber-500/50 text-right"
                />
                <Button 
                  data-testid="button-send-message"
                  onClick={sendChatMessage}
                  disabled={!chatMessage.trim()}
                  className="bg-gradient-to-r from-amber-500 to-amber-700 hover:from-purple-500 hover:to-indigo-500 rounded-xl px-4 py-3"
                >
                  <Send className="size-5" />
                </Button>
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Room Settings Panel */}
        <AnimatePresence>
          {showRoomSettings && isRoomOwner && (
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="fixed inset-0 z-[400] bg-black/80 backdrop-blur-sm flex items-center justify-center p-4"
              onClick={() => setShowRoomSettings(false)}
            >
              <motion.div 
                initial={{ scale: 0.9, opacity: 0 }}
                animate={{ scale: 1, opacity: 1 }}
                exit={{ scale: 0.9, opacity: 0 }}
                onClick={(e) => e.stopPropagation()}
                className="night-glass rounded-3xl p-6 w-full max-w-sm"
              >
                <h3 className="text-lg font-black text-white mb-4 text-center">إعدادات الغرفة</h3>
                
                <div className="space-y-3">
                  <button
                    data-testid="settings-lock-room"
                    onClick={toggleRoomLock}
                    className={cn(
                      "w-full flex items-center justify-between gap-3 p-4 rounded-2xl transition-all",
                      roomLocked ? "bg-yellow-500/20 border border-yellow-500/30" : "bg-white/5 border border-white/10"
                    )}
                  >
                    <div className="flex items-center gap-3">
                      {roomLocked ? <Shield className="size-5 text-yellow-400" /> : <Users className="size-5 text-white/60" />}
                      <span className="font-bold text-sm">{roomLocked ? "الغرفة مقفلة" : "الغرفة مفتوحة"}</span>
                    </div>
                    <Switch checked={roomLocked} />
                  </button>

                  <button
                    data-testid="settings-mute-all"
                    onClick={muteAll}
                    className={cn(
                      "w-full flex items-center justify-between gap-3 p-4 rounded-2xl transition-all",
                      allMuted ? "bg-rose-500/20 border border-rose-500/30" : "bg-white/5 border border-white/10"
                    )}
                  >
                    <div className="flex items-center gap-3">
                      {allMuted ? <VolumeX className="size-5 text-rose-400" /> : <Volume2 className="size-5 text-white/60" />}
                      <span className="font-bold text-sm">{allMuted ? "الجميع مكتوم" : "الصوت مفتوح"}</span>
                    </div>
                    <Switch checked={allMuted} />
                  </button>

                  <button
                    data-testid="settings-clear-chat"
                    onClick={() => { clearChat(); setShowRoomSettings(false); }}
                    className="w-full flex items-center gap-3 p-4 rounded-2xl bg-white/5 border border-white/10 hover:bg-orange-500/20 hover:border-orange-500/30 transition-all"
                  >
                    <MessageSquare className="size-5 text-orange-400" />
                    <span className="font-bold text-sm">مسح المحادثة</span>
                  </button>

                  {/* Room Password Feature */}
                  <div className="p-4 rounded-2xl bg-white/5 border border-white/10">
                    <div className="flex items-center gap-3 mb-3">
                      <Lock className="size-5 text-emerald-400" />
                      <span className="font-bold text-sm">كلمة مرور الغرفة</span>
                    </div>
                    {showPasswordInput ? (
                      <div className="space-y-2">
                        <input
                          type="password"
                          placeholder="أدخل كلمة المرور..."
                          value={roomPassword}
                          onChange={(e) => setRoomPassword(e.target.value)}
                          className="w-full bg-black/40 border border-white/10 rounded-xl px-3 py-2 text-white text-sm placeholder:text-white/40 focus:outline-none focus:border-emerald-500/50"
                          data-testid="input-room-password"
                        />
                        <div className="flex gap-2">
                          <button
                            onClick={async () => {
                              if (roomPassword.trim() && currentRoom?.id) {
                                try {
                                  const res = await fetch(`/api/rooms/${currentRoom.id}/password`, {
                                    method: "POST",
                                    headers: { "Content-Type": "application/json" },
                                    body: JSON.stringify({ password: roomPassword, userId: user?.id }),
                                  });
                                  if (res.ok) {
                                    setRoomLocked(true);
                                    toast.success("تم تعيين كلمة المرور للغرفة");
                                  } else {
                                    const data = await res.json();
                                    toast.error(data.error || "حدث خطأ");
                                  }
                                } catch {
                                  toast.error("حدث خطأ في الاتصال");
                                }
                              }
                              setShowPasswordInput(false);
                            }}
                            className="flex-1 py-2 bg-emerald-500/20 hover:bg-emerald-500/30 rounded-xl text-emerald-300 text-xs font-bold transition-colors"
                            data-testid="btn-save-password"
                          >
                            حفظ
                          </button>
                          <button
                            onClick={async () => {
                              if (currentRoom?.id) {
                                try {
                                  await fetch(`/api/rooms/${currentRoom.id}/password`, {
                                    method: "POST",
                                    headers: { "Content-Type": "application/json" },
                                    body: JSON.stringify({ password: null, userId: user?.id }),
                                  });
                                } catch {}
                              }
                              setRoomPassword("");
                              setShowPasswordInput(false);
                              setRoomLocked(false);
                              toast.info("تم إزالة كلمة المرور");
                            }}
                            className="flex-1 py-2 bg-red-500/20 hover:bg-red-500/30 rounded-xl text-red-300 text-xs font-bold transition-colors"
                            data-testid="btn-remove-password"
                          >
                            إزالة
                          </button>
                        </div>
                      </div>
                    ) : (
                      <button
                        onClick={() => setShowPasswordInput(true)}
                        className={cn(
                          "w-full py-2 rounded-xl text-xs font-bold transition-colors",
                          roomPassword ? "bg-emerald-500/20 text-emerald-300" : "bg-white/5 text-white/60 hover:bg-white/10"
                        )}
                        data-testid="btn-set-password"
                      >
                        {roomPassword ? "تغيير كلمة المرور" : "تعيين كلمة مرور"}
                      </button>
                    )}
                  </div>

                  {bannedUsers.length > 0 && (
                    <div className="p-4 rounded-2xl bg-white/5 border border-white/10">
                      <div className="flex items-center gap-2 mb-3">
                        <Shield className="size-4 text-red-400" />
                        <span className="text-xs font-bold text-white/60">المستخدمين المحظورين ({bannedUsers.length})</span>
                      </div>
                      <div className="flex flex-wrap gap-2">
                        {bannedUsers.map(userId => (
                          <button
                            key={userId}
                            onClick={() => unbanUser(userId)}
                            className="flex items-center gap-1 px-3 py-1.5 bg-red-500/20 rounded-lg text-xs font-bold text-red-300 hover:bg-red-500/30 transition-colors"
                          >
                            مستخدم {userId}
                            <span className="text-white/40">✕</span>
                          </button>
                        ))}
                      </div>
                    </div>
                  )}

                  {moderators.length > 0 && (
                    <div className="p-4 rounded-2xl bg-white/5 border border-white/10">
                      <div className="flex items-center gap-2 mb-3">
                        <Star className="size-4 text-yellow-400" />
                        <span className="text-xs font-bold text-white/60">المشرفين ({moderators.length})</span>
                      </div>
                      <div className="flex flex-wrap gap-2">
                        {moderators.map(userId => (
                          <div
                            key={userId}
                            className="flex items-center gap-1 px-3 py-1.5 bg-yellow-500/20 rounded-lg text-xs font-bold text-yellow-300"
                          >
                            <Star className="size-3" />
                            مستخدم {userId}
                          </div>
                        ))}
                      </div>
                    </div>
                  )}
                </div>

                <button
                  onClick={() => setShowRoomSettings(false)}
                  className="w-full mt-4 py-3 bg-amber-600 hover:bg-amber-500 rounded-2xl font-black text-sm transition-colors"
                >
                  إغلاق
                </button>
              </motion.div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Room Tools Panel */}
        <AnimatePresence>
          {showRoomTools && (
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="fixed inset-0 z-[400] bg-black/80 backdrop-blur-sm flex items-end justify-center"
              onClick={() => setShowRoomTools(false)}
            >
              <motion.div 
                initial={{ y: "100%" }}
                animate={{ y: 0 }}
                exit={{ y: "100%" }}
                transition={{ type: "spring", damping: 25, stiffness: 200 }}
                onClick={(e) => e.stopPropagation()}
                className="bg-black rounded-t-[32px] p-6 w-full max-w-lg border-t border-white/10"
              >
                <div className="w-12 h-1 bg-white/20 rounded-full mx-auto mb-6" />
                <h3 className="text-lg font-black text-white mb-6 text-center">أدوات الغرفة</h3>
                
                {/* Game Center Section */}
                <div className="mb-6">
                  <div className="flex items-center gap-2 mb-3">
                    <div className="size-6 rounded-lg bg-gradient-to-br from-orange-500 to-red-500 flex items-center justify-center">
                      <Flame className="size-4 text-white" />
                    </div>
                    <span className="text-sm font-black text-white">مركز اللعبة</span>
                  </div>
                  <div className="grid grid-cols-3 gap-3">
                    <button onClick={() => toast.info("لعبة اللودو قريباً!")} className="flex flex-col items-center gap-2 p-4 rounded-2xl bg-gradient-to-br from-blue-500/20 to-cyan-500/20 border border-blue-500/30 hover:scale-105 transition-transform">
                      <span className="text-3xl">🎲</span>
                      <span className="text-xs font-bold text-blue-300">لودو</span>
                    </button>
                    <button onClick={() => toast.info("PK المايك قريباً!")} className="flex flex-col items-center gap-2 p-4 rounded-2xl bg-gradient-to-br from-pink-500/20 to-rose-500/20 border border-pink-500/30 hover:scale-105 transition-transform">
                      <span className="text-3xl">🎤</span>
                      <span className="text-xs font-bold text-pink-300">PK المايك</span>
                    </button>
                    <button onClick={() => toast.info("صناديق الهدايا قريباً!")} className="flex flex-col items-center gap-2 p-4 rounded-2xl bg-gradient-to-br from-yellow-500/20 to-orange-500/20 border border-yellow-500/30 hover:scale-105 transition-transform">
                      <span className="text-3xl">🎁</span>
                      <span className="text-xs font-bold text-yellow-300">صناديق الهدايا</span>
                    </button>
                  </div>
                </div>

                {/* Premium Section */}
                <div className="mb-6">
                  <div className="flex items-center gap-2 mb-3">
                    <div className="size-6 rounded-lg bg-gradient-to-br from-yellow-500 to-amber-500 flex items-center justify-center">
                      <Crown className="size-4 text-white" />
                    </div>
                    <span className="text-sm font-black text-white">قسم التميز</span>
                  </div>
                  <div className="grid grid-cols-2 gap-3">
                    <button onClick={() => toast.info("VIP قريباً!")} className="flex flex-col items-center gap-2 p-4 rounded-2xl bg-gradient-to-br from-purple-500/20 to-violet-500/20 border border-amber-500/30 hover:scale-105 transition-transform">
                      <span className="text-3xl">💎</span>
                      <span className="text-xs font-bold text-amber-300">VIP</span>
                    </button>
                    <button onClick={() => toast.info("رتب النبلاء قريباً!")} className="flex flex-col items-center gap-2 p-4 rounded-2xl bg-gradient-to-br from-amber-500/20 to-yellow-500/20 border border-amber-500/30 hover:scale-105 transition-transform">
                      <span className="text-3xl">👑</span>
                      <span className="text-xs font-bold text-amber-300">رتب النبلاء</span>
                    </button>
                  </div>
                </div>

                {/* Room Tools Section */}
                <div className="mb-4">
                  <div className="flex items-center gap-2 mb-3">
                    <div className="size-6 rounded-lg bg-gradient-to-br from-indigo-500 to-blue-500 flex items-center justify-center">
                      <Settings className="size-4 text-white" />
                    </div>
                    <span className="text-sm font-black text-white">أدوات الغرفة</span>
                  </div>
                  <div className="grid grid-cols-3 gap-3">
                    <button onClick={() => toast.info("تغيير الخلفية قريباً!")} className="flex flex-col items-center gap-2 p-4 rounded-2xl bg-gradient-to-br from-green-500/20 to-emerald-500/20 border border-green-500/30 hover:scale-105 transition-transform">
                      <span className="text-3xl">🖼️</span>
                      <span className="text-xs font-bold text-green-300">الخلفية</span>
                    </button>
                    <button onClick={() => setShowMusicPlayer(true)} className="flex flex-col items-center gap-2 p-4 rounded-2xl bg-gradient-to-br from-rose-500/20 to-pink-500/20 border border-rose-500/30 hover:scale-105 transition-transform">
                      <span className="text-3xl">🎵</span>
                      <span className="text-xs font-bold text-rose-300">الموسيقى</span>
                    </button>
                    <button onClick={() => toast.info("المؤثرات الصوتية قريباً!")} className="flex flex-col items-center gap-2 p-4 rounded-2xl bg-gradient-to-br from-cyan-500/20 to-teal-500/20 border border-cyan-500/30 hover:scale-105 transition-transform">
                      <span className="text-3xl">🔊</span>
                      <span className="text-xs font-bold text-cyan-300">المؤثرات</span>
                    </button>
                  </div>
                </div>

                <button
                  onClick={() => setShowRoomTools(false)}
                  className="w-full py-3 bg-white/5 hover:bg-white/10 rounded-2xl font-bold text-sm text-white/60 transition-colors"
                >
                  إغلاق
                </button>
              </motion.div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Music Player Panel */}
        <AnimatePresence>
          {showMusicPlayer && (
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="fixed inset-0 z-[400] bg-black/80 backdrop-blur-sm flex items-end justify-center"
              onClick={() => setShowMusicPlayer(false)}
            >
              <motion.div 
                initial={{ y: "100%" }}
                animate={{ y: 0 }}
                exit={{ y: "100%" }}
                transition={{ type: "spring", damping: 25, stiffness: 200 }}
                onClick={(e) => e.stopPropagation()}
                className="bg-gradient-to-b from-gray-900 to-black rounded-t-[32px] p-6 w-full max-w-lg border-t border-rose-500/20"
              >
                <div className="w-12 h-1 bg-rose-500/40 rounded-full mx-auto mb-6" />
                <h3 className="text-lg font-black text-white mb-6 text-center flex items-center justify-center gap-2">
                  <Music className="size-5 text-rose-400" />
                  مشغل الموسيقى
                </h3>
                
                {/* Current Track Display */}
                <div className="bg-gradient-to-br from-rose-500/20 to-pink-500/20 rounded-3xl p-6 mb-6 border border-rose-500/30">
                  <div className="flex items-center gap-4">
                    <div className="size-16 rounded-2xl bg-gradient-to-br from-rose-500 to-pink-600 flex items-center justify-center text-3xl shadow-lg shadow-rose-500/30">
                      {musicTracks[currentTrack].icon}
                    </div>
                    <div className="flex-1">
                      <div className="text-white font-bold text-lg">{musicTracks[currentTrack].name}</div>
                      <div className="text-rose-300/60 text-sm">{isPlaying ? "🎵 يتم التشغيل..." : "⏸️ متوقف"}</div>
                    </div>
                  </div>
                </div>

                {/* Playback Controls */}
                <div className="flex items-center justify-center gap-6 mb-6">
                  <button onClick={prevTrack} className="size-12 rounded-full bg-white/10 flex items-center justify-center hover:bg-white/20 transition-colors">
                    <ChevronLeft className="size-6 text-white" />
                  </button>
                  <button 
                    onClick={isPlaying ? pauseMusic : playMusic} 
                    className="size-16 rounded-full bg-gradient-to-br from-rose-500 to-pink-600 flex items-center justify-center shadow-lg shadow-rose-500/30 hover:scale-105 transition-transform"
                  >
                    {isPlaying ? (
                      <div className="flex gap-1">
                        <div className="w-1.5 h-6 bg-white rounded-full" />
                        <div className="w-1.5 h-6 bg-white rounded-full" />
                      </div>
                    ) : (
                      <div className="w-0 h-0 border-l-[16px] border-l-white border-y-[10px] border-y-transparent ml-1" />
                    )}
                  </button>
                  <button onClick={nextTrack} className="size-12 rounded-full bg-white/10 flex items-center justify-center hover:bg-white/20 transition-colors">
                    <ChevronRight className="size-6 text-white" />
                  </button>
                </div>

                {/* Volume Control */}
                <div className="flex items-center gap-3 mb-6 px-4">
                  <VolumeX className="size-5 text-white/40" />
                  <input 
                    type="range" 
                    min="0" 
                    max="100" 
                    value={musicVolume} 
                    onChange={(e) => changeMusicVolume(Number(e.target.value))}
                    className="flex-1 h-2 bg-white/10 rounded-full appearance-none cursor-pointer accent-rose-500"
                  />
                  <Volume2 className="size-5 text-white/40" />
                  <span className="text-xs text-white/60 w-8">{musicVolume}%</span>
                </div>

                {/* Track List */}
                <div className="space-y-2 max-h-[200px] overflow-y-auto">
                  {musicTracks.map((track, index) => (
                    <button
                      key={index}
                      onClick={() => selectTrack(index)}
                      className={cn(
                        "w-full flex items-center gap-3 p-3 rounded-2xl transition-all",
                        currentTrack === index 
                          ? "bg-rose-500/20 border border-rose-500/40" 
                          : "bg-white/5 border border-white/10 hover:bg-white/10"
                      )}
                    >
                      <div className={cn(
                        "size-10 rounded-xl flex items-center justify-center text-lg",
                        currentTrack === index ? "bg-rose-500/30" : "bg-white/10"
                      )}>
                        {track.icon}
                      </div>
                      <span className={cn(
                        "font-bold text-sm",
                        currentTrack === index ? "text-rose-300" : "text-white/80"
                      )}>{track.name}</span>
                      {currentTrack === index && isPlaying && (
                        <div className="mr-auto flex gap-0.5">
                          <div className="w-1 h-3 bg-rose-400 rounded-full animate-pulse" />
                          <div className="w-1 h-4 bg-rose-400 rounded-full animate-pulse" style={{ animationDelay: '0.1s' }} />
                          <div className="w-1 h-2 bg-rose-400 rounded-full animate-pulse" style={{ animationDelay: '0.2s' }} />
                        </div>
                      )}
                    </button>
                  ))}
                </div>

                <button
                  onClick={() => setShowMusicPlayer(false)}
                  className="w-full mt-4 py-3 bg-white/5 hover:bg-white/10 rounded-2xl font-bold text-sm text-white/60 transition-colors"
                >
                  إغلاق
                </button>
              </motion.div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* New Bottom Bar - Ordered Controls */}
        <div className="flex items-center justify-between px-2">
          {/* Left Side */}
          <div className="flex items-center gap-3">
            {/* Grid/Tools */}
            <button 
              onClick={() => setShowRoomTools(true)}
              className="size-11 rounded-full bg-white/10 backdrop-blur-sm flex items-center justify-center border border-white/20"
            >
              <LayoutGrid className="size-5 text-white/80" />
            </button>
            
            {/* Person/Profile */}
            <button 
              onClick={() => toast.info("الملف الشخصي")}
              className="size-11 rounded-full bg-white/10 backdrop-blur-sm flex items-center justify-center border border-white/20"
            >
              <User className="size-5 text-white/80" />
            </button>
          </div>
          
          {/* Center - Pink Gift Button */}
          <button 
            onClick={() => { setShowGifts(!showGifts); setShowEmojis(false); setShowChat(false); }}
            className="size-14 rounded-full flex items-center justify-center bg-gradient-to-br from-pink-400 to-rose-500 shadow-lg shadow-pink-500/30 -mt-6"
          >
            <Gift className="size-7 text-white" />
          </button>
          
          {/* Right Side */}
          <div className="flex items-center gap-3">
            {/* Chat */}
            <button 
              onClick={() => { setShowChat(!showChat); setShowEmojis(false); setShowGifts(false); }}
              className="size-11 rounded-full bg-white/10 backdrop-blur-sm flex items-center justify-center border border-white/20"
            >
              <MessageSquare className="size-5 text-blue-400" />
            </button>
            
            {/* Emoji */}
            <button 
              onClick={() => { setShowEmojis(!showEmojis); setShowGifts(false); setShowChat(false); }}
              className="size-11 rounded-full bg-white/10 backdrop-blur-sm flex items-center justify-center border border-white/20"
            >
              <Smile className="size-5 text-yellow-400" />
            </button>
            
            {/* Mic Control */}
            {mySlot !== null ? (
              <button 
                onClick={toggleMyMute}
                data-testid="button-toggle-mute"
                className="size-11 rounded-full bg-white/10 backdrop-blur-sm flex items-center justify-center border border-white/20"
              >
                {!muted ? (
                  <Mic className="size-5 text-green-400" />
                ) : (
                  <MicOff className="size-5 text-rose-400" />
                )}
              </button>
            ) : (
              <button 
                onClick={() => {
                  const emptySlot = [1,2,3,4,5,6,7,8].find(s => !micSlots[s]);
                  if (emptySlot) joinMicSlot(emptySlot);
                  else toast.error("جميع المايكات مشغولة!");
                }}
                data-testid="button-join-any-mic"
                className="size-11 rounded-full bg-white/10 backdrop-blur-sm flex items-center justify-center border border-white/20"
              >
                <Mic className="size-5 text-purple-400" />
              </button>
            )}
            
            {/* Speaker/Volume */}
            <button 
              onClick={() => setAllMuted(!allMuted)}
              className="size-11 rounded-full bg-white/10 backdrop-blur-sm flex items-center justify-center border border-white/20"
            >
              {allMuted ? (
                <VolumeX className="size-5 text-rose-400" />
              ) : (
                <Volume2 className="size-5 text-white/80" />
              )}
            </button>
          </div>
        </div>
        
        <input 
          ref={localAudioInputRef}
          type="file" 
          accept="audio/*" 
          className="hidden" 
          onChange={handleLocalAudioSelect}
        />
      </div>
    </motion.div>
  );
}

export default function VoiceHome() {
  const { user, logout } = useAuth();
  const [activeTab, setActiveTab] = useState<"home" | "message" | "feed" | "me">("home");
  const [inRoom, setInRoom] = useState(false);
  const [currentRoom, setCurrentRoom] = useState<Room | null>(null);
  const [showProfile, setShowProfile] = useState(false);
  const [showSettings, setShowSettings] = useState(false);
  const [showWallet, setShowWallet] = useState(false);
  const [showEditProfile, setShowEditProfile] = useState(false);
  const [showSecurity, setShowSecurity] = useState(false);
  const [showAdminPanel, setShowAdminPanel] = useState(false);
  const [showCreateRoom, setShowCreateRoom] = useState(false);
  const [showMessages, setShowMessages] = useState(false);
  const [showForum, setShowForum] = useState(false);
  const [coins, setCoins] = useState(user?.coins || 0);
  const [followers, setFollowers] = useState(user?.followers || 0);
  const [rooms, setRooms] = useState<Room[]>([]);
  const [selectedCategory, setSelectedCategory] = useState<string>("الكل");
  const [searchQuery, setSearchQuery] = useState("");
  const [isLoadingRooms, setIsLoadingRooms] = useState(true);
  const [userSearchResults, setUserSearchResults] = useState<Array<{id: string; username: string; displayName: string; avatar: string; level: number}>>([]);
  const [isSearchingUsers, setIsSearchingUsers] = useState(false);
  const [showSearchResults, setShowSearchResults] = useState(false);
  const [showAdminLogs, setShowAdminLogs] = useState(false);
  const [adminActionLogs, setAdminActionLogs] = useState<AdminActionLog[]>([]);
  const [ownerNotifications, setOwnerNotifications] = useState<OwnerNotification[]>([]);
  const [adminStats, setAdminStats] = useState({ onlineUsers: 0, openRooms: 0, totalGiftsSent: 0 });
  const [banSearchResult, setBanSearchResult] = useState<{id: string; username: string; displayName: string; isBanned: boolean} | null>(null);
  const [isBanning, setIsBanning] = useState(false);
  const [isSendingBroadcast, setIsSendingBroadcast] = useState(false);
  
  // Global Theme Control State
  const [globalMicFrameColor, setGlobalMicFrameColor] = useState<'gold' | 'purple' | 'default'>(() => {
    return (localStorage.getItem('globalMicFrameColor') as 'gold' | 'purple' | 'default') || 'default';
  });
  const [globalPartyMode, setGlobalPartyMode] = useState<'off' | 'stars' | 'hearts'>(() => {
    return (localStorage.getItem('globalPartyMode') as 'off' | 'stars' | 'hearts') || 'off';
  });
  const [globalRoomBg, setGlobalRoomBg] = useState<string>(() => {
    return localStorage.getItem('globalRoomBg') || '';
  });
  
  // Load admin logs from localStorage and listen for updates
  useEffect(() => {
    const loadLogs = () => {
      setAdminActionLogs(getAdminActionLogs());
      setOwnerNotifications(getOwnerNotifications());
    };
    
    loadLogs();
    
    // Listen for updates from RoomView
    window.addEventListener('adminLogUpdated', loadLogs);
    window.addEventListener('ownerNotificationUpdated', loadLogs);
    
    return () => {
      window.removeEventListener('adminLogUpdated', loadLogs);
      window.removeEventListener('ownerNotificationUpdated', loadLogs);
    };
  }, []);

  // Load admin stats when panel opens
  useEffect(() => {
    if (showAdminLogs && user?.isOwner) {
      fetch(`/api/admin/stats?email=${encodeURIComponent(user.email || '')}`)
        .then(res => res.json())
        .then(data => {
          if (data.onlineUsers !== undefined) {
            setAdminStats(data);
          }
        })
        .catch(console.error);
    }
  }, [showAdminLogs, user?.isOwner, user?.email]);

  // Listen for global theme changes (real-time sync across app)
  useEffect(() => {
    const handleThemeChange = () => {
      setGlobalMicFrameColor((localStorage.getItem('globalMicFrameColor') as 'gold' | 'purple' | 'default') || 'default');
      setGlobalPartyMode((localStorage.getItem('globalPartyMode') as 'off' | 'stars' | 'hearts') || 'off');
      setGlobalRoomBg(localStorage.getItem('globalRoomBg') || '');
    };
    
    window.addEventListener('globalThemeChanged', handleThemeChange);
    window.addEventListener('storage', handleThemeChange);
    
    return () => {
      window.removeEventListener('globalThemeChanged', handleThemeChange);
      window.removeEventListener('storage', handleThemeChange);
    };
  }, []);
  
  // Helper functions for global theme control
  const updateGlobalMicFrame = (color: 'gold' | 'purple' | 'default') => {
    localStorage.setItem('globalMicFrameColor', color);
    setGlobalMicFrameColor(color);
    window.dispatchEvent(new CustomEvent('globalThemeChanged'));
    toast.success(`تم تغيير إطارات المايكات إلى ${color === 'gold' ? 'ذهبي' : color === 'purple' ? 'بنفسجي' : 'الافتراضي'} ✨`);
  };
  
  const updateGlobalPartyMode = (mode: 'off' | 'stars' | 'hearts') => {
    localStorage.setItem('globalPartyMode', mode);
    setGlobalPartyMode(mode);
    window.dispatchEvent(new CustomEvent('globalThemeChanged'));
    toast.success(mode === 'off' ? 'تم إيقاف وضع الاحتفال 🎉' : `تم تفعيل وضع الاحتفال مع ${mode === 'stars' ? 'النجوم ⭐' : 'القلوب ❤️'}`);
  };
  
  const updateGlobalRoomBg = (bgUrl: string) => {
    localStorage.setItem('globalRoomBg', bgUrl);
    setGlobalRoomBg(bgUrl);
    window.dispatchEvent(new CustomEvent('globalThemeChanged'));
    toast.success('تم تغيير خلفية جميع الغرف 🖼️');
  };
  
  const isOwner = user?.isOwner || false;
  const userEmail = user?.email || "";

  // Fetch rooms from API
  const fetchRooms = async () => {
    try {
      setIsLoadingRooms(true);
      const response = await fetch("/api/rooms");
      if (response.ok) {
        const data: RoomFromApi[] = await response.json();
        const formattedRooms: Room[] = data.map((r) => ({
          id: String(r.id),
          title: r.title,
          category: r.category,
          live: r.isLive ?? true,
          listeners: r.listenersCount ?? 0,
          tags: r.tags ?? [],
          image: r.image,
          hostId: r.hostId,
          host: {
            name: r.host?.displayName || "مستخدم",
            avatar: r.host?.avatar || `https://api.dicebear.com/7.x/avataaars/svg?seed=${r.host?.id || r.hostId}`,
            level: r.host?.level ?? 1,
          },
        }));
        setRooms(formattedRooms);
      }
    } catch (error) {
      console.error("Error fetching rooms:", error);
    } finally {
      setIsLoadingRooms(false);
    }
  };

  useEffect(() => {
    fetchRooms();
  }, []);

  // Filter rooms by category and search query
  const filteredRooms = useMemo(() => {
    let result = rooms;
    
    // Filter by search query (search by title, host name, or host ID)
    if (searchQuery.trim()) {
      const query = searchQuery.toLowerCase().trim();
      result = result.filter((r) => 
        r.title.toLowerCase().includes(query) ||
        r.host.name.toLowerCase().includes(query) ||
        r.id.toString().includes(query)
      );
    }
    
    // Filter by category
    if (selectedCategory !== "الكل") {
      result = result.filter((r) => r.category === selectedCategory);
    }
    
    return result;
  }, [rooms, selectedCategory, searchQuery]);

  // Global user search with real-time updates
  useEffect(() => {
    const searchUsers = async () => {
      if (!searchQuery.trim() || searchQuery.length < 1) {
        setUserSearchResults([]);
        setShowSearchResults(false);
        return;
      }
      
      setIsSearchingUsers(true);
      setShowSearchResults(true);
      try {
        const response = await fetch(`/api/search/users?q=${encodeURIComponent(searchQuery.trim())}`);
        if (response.ok) {
          const data = await response.json();
          setUserSearchResults(data);
        }
      } catch (error) {
        console.error("Error searching users:", error);
      } finally {
        setIsSearchingUsers(false);
      }
    };

    const debounceTimer = setTimeout(searchUsers, 300);
    return () => clearTimeout(debounceTimer);
  }, [searchQuery]);

  // Create a new room
  const handleCreateRoom = async (title: string, category: string, imageUrl: string) => {
    if (!user) {
      toast.error("يجب تسجيل الدخول أولاً");
      return;
    }
    try {
      const response = await fetch("/api/rooms", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        credentials: "include",
        body: JSON.stringify({
          title,
          category,
          image: imageUrl || null,
          hostId: user.id,
          isLive: true,
          listenersCount: 0,
          tags: [],
        }),
      });
      if (response.ok) {
        setShowCreateRoom(false);
        toast.success("تم إنشاء الغرفة بنجاح!");
        await fetchRooms();
      } else {
        const error = await response.json();
        toast.error(error.error || "فشل في إنشاء الغرفة");
      }
    } catch (error) {
      toast.error("حدث خطأ أثناء إنشاء الغرفة");
    }
  };

  const handleLogout = () => {
    logout();
  };

  const handleRemoveAllFollowers = () => {
    setFollowers(0);
  };

  return (
    <div className="min-h-dvh font-cairo bg-white text-gray-900 selection:bg-amber-500/30">
      <AnimatePresence>{inRoom && <RoomView coins={coins} setCoins={setCoins} isOwner={isOwner} currentRoom={currentRoom} userId={user?.id} onExit={() => { setInRoom(false); setCurrentRoom(null); }} />}</AnimatePresence>
      <AnimatePresence>{showProfile && <ProfileView coins={coins} followers={followers} isOwner={isOwner} onRemoveAllFollowers={handleRemoveAllFollowers} onBack={() => setShowProfile(false)} onSettings={() => setShowSettings(true)} />}</AnimatePresence>
      <AnimatePresence>{showSettings && (
        <SettingsView 
          onBack={() => setShowSettings(false)} 
          onWallet={() => setShowWallet(true)} 
          onEditProfile={() => setShowEditProfile(true)}
          onSecurity={() => setShowSecurity(true)}
          onLogout={handleLogout}
          isOwner={isOwner}
          onAdminPanel={() => setShowAdminPanel(true)}
          onAdminLogs={() => setShowAdminLogs(true)}
        />
      )}</AnimatePresence>
      <AnimatePresence>{showEditProfile && <EditProfileView onBack={() => setShowEditProfile(false)} />}</AnimatePresence>
      <AnimatePresence>{showSecurity && <SecurityView onBack={() => setShowSecurity(false)} />}</AnimatePresence>
      <AnimatePresence>{showMessages && <PrivateMessagesView onBack={() => setShowMessages(false)} />}</AnimatePresence>
      <AnimatePresence>{showForum && <ForumView onBack={() => setShowForum(false)} />}</AnimatePresence>
      <AnimatePresence>{showAdminPanel && <AdminPanelView onBack={() => setShowAdminPanel(false)} userEmail={userEmail} />}</AnimatePresence>
      
      {/* Hidden Admin Logs Panel - Owner Only */}
      <AnimatePresence>
        {showAdminLogs && isOwner && (
          <motion.div 
            initial={{ x: "100%" }}
            animate={{ x: 0 }}
            exit={{ x: "100%" }}
            className="fixed inset-0 z-[200] bg-black flex flex-col font-cairo overflow-y-auto"
          >
            {/* Royal Black Header with Gold Accents */}
            <header className="p-4 flex items-center justify-between sticky top-0 z-10 border-b"
              style={{
                background: 'linear-gradient(135deg, #0a0a0a 0%, #1a1a1a 50%, #0a0a0a 100%)',
                borderColor: 'rgba(255, 215, 0, 0.3)',
              }}>
              <Button variant="ghost" size="icon" className="text-amber-400 bg-amber-500/10 rounded-2xl border border-amber-500/30" onClick={() => setShowAdminLogs(false)}>
                <ChevronLeft className="size-6" />
              </Button>
              <div className="flex items-center gap-2">
                <Crown className="size-5 text-amber-400" />
                <h2 className="text-lg font-black" style={{
                  background: 'linear-gradient(135deg, #ffd700 0%, #ffed4a 50%, #ffd700 100%)',
                  WebkitBackgroundClip: 'text',
                  WebkitTextFillColor: 'transparent',
                }}>لوحة تحكم المالك</h2>
              </div>
              <div className="size-10" />
            </header>

            <div className="p-4 space-y-4" style={{
              background: 'linear-gradient(180deg, #0a0a0a 0%, #121212 100%)',
            }}>
              
              {/* Live Statistics Section */}
              <div className="rounded-2xl p-4 border" style={{
                background: 'linear-gradient(135deg, rgba(255,215,0,0.05) 0%, rgba(0,0,0,0.8) 100%)',
                borderColor: 'rgba(255, 215, 0, 0.2)',
              }}>
                <div className="flex items-center gap-2 mb-4">
                  <Activity className="size-5 text-amber-400" />
                  <span className="text-sm font-black text-amber-300">إحصائيات مباشرة</span>
                </div>
                <div className="grid grid-cols-3 gap-3">
                  <div className="bg-black/40 rounded-xl p-3 border border-amber-500/20 text-center">
                    <Users className="size-6 mx-auto mb-2 text-green-400" />
                    <div className="text-2xl font-black text-white">{adminStats.onlineUsers}</div>
                    <div className="text-[10px] text-white/60">المتصلين الآن</div>
                  </div>
                  <div className="bg-black/40 rounded-xl p-3 border border-amber-500/20 text-center">
                    <Home className="size-6 mx-auto mb-2 text-purple-400" />
                    <div className="text-2xl font-black text-white">{adminStats.openRooms}</div>
                    <div className="text-[10px] text-white/60">الغرف المفتوحة</div>
                  </div>
                  <div className="bg-black/40 rounded-xl p-3 border border-amber-500/20 text-center">
                    <Gift className="size-6 mx-auto mb-2 text-pink-400" />
                    <div className="text-2xl font-black text-white">{adminStats.totalGiftsSent}</div>
                    <div className="text-[10px] text-white/60">الهدايا المرسلة</div>
                  </div>
                </div>
              </div>

              {/* Global Theme Control Section */}
              <div className="rounded-2xl p-4 border" style={{
                background: 'linear-gradient(135deg, rgba(255,215,0,0.08) 0%, rgba(0,0,0,0.8) 100%)',
                borderColor: 'rgba(255, 215, 0, 0.3)',
              }}>
                <div className="flex items-center gap-2 mb-4">
                  <Sparkles className="size-5 text-amber-400" />
                  <span className="text-sm font-black text-amber-300">المظهر العام</span>
                </div>
                
                {/* Room Background Control */}
                <div className="mb-4">
                  <div className="text-xs font-bold text-white/70 mb-2">خلفية جميع الغرف</div>
                  <div className="flex gap-2">
                    <input
                      type="text"
                      placeholder="رابط صورة الخلفية..."
                      className="flex-1 bg-black/60 border border-amber-500/30 rounded-xl px-3 py-2 text-white placeholder:text-white/40 text-sm focus:outline-none focus:border-amber-400"
                      value={globalRoomBg}
                      onChange={(e) => setGlobalRoomBg(e.target.value)}
                    />
                    <button 
                      onClick={() => {
                        if (globalRoomBg.trim()) {
                          updateGlobalRoomBg(globalRoomBg.trim());
                        }
                      }}
                      className="px-4 py-2 bg-amber-500/20 border border-amber-500/40 rounded-xl text-amber-300 font-bold text-xs hover:bg-amber-500/30 transition-colors"
                    >
                      تطبيق
                    </button>
                  </div>
                  {globalRoomBg && (
                    <button 
                      onClick={() => {
                        setGlobalRoomBg('');
                        updateGlobalRoomBg('');
                      }}
                      className="mt-2 text-[10px] text-red-400 hover:text-red-300"
                    >
                      إعادة للافتراضي
                    </button>
                  )}
                </div>

                {/* Mic Frames Control */}
                <div className="mb-4">
                  <div className="text-xs font-bold text-white/70 mb-2">إطارات المايكات</div>
                  <div className="grid grid-cols-3 gap-2">
                    <button 
                      onClick={() => updateGlobalMicFrame('default')}
                      className={cn(
                        "py-2 px-3 rounded-xl text-xs font-bold transition-all border",
                        globalMicFrameColor === 'default' 
                          ? "bg-white/20 border-white/40 text-white" 
                          : "bg-black/40 border-white/10 text-white/60 hover:bg-white/10"
                      )}
                    >
                      افتراضي
                    </button>
                    <button 
                      onClick={() => updateGlobalMicFrame('gold')}
                      className={cn(
                        "py-2 px-3 rounded-xl text-xs font-bold transition-all border",
                        globalMicFrameColor === 'gold' 
                          ? "bg-gradient-to-r from-amber-500 to-yellow-400 border-amber-400 text-black" 
                          : "bg-amber-500/20 border-amber-500/30 text-amber-300 hover:bg-amber-500/30"
                      )}
                    >
                      ⭐ ذهبي
                    </button>
                    <button 
                      onClick={() => updateGlobalMicFrame('purple')}
                      className={cn(
                        "py-2 px-3 rounded-xl text-xs font-bold transition-all border",
                        globalMicFrameColor === 'purple' 
                          ? "bg-gradient-to-r from-purple-500 to-pink-500 border-purple-400 text-white" 
                          : "bg-purple-500/20 border-purple-500/30 text-purple-300 hover:bg-purple-500/30"
                      )}
                    >
                      💜 بنفسجي
                    </button>
                  </div>
                </div>

                {/* Party Mode Control */}
                <div>
                  <div className="text-xs font-bold text-white/70 mb-2">وضع الاحتفال 🎉</div>
                  <div className="grid grid-cols-3 gap-2">
                    <button 
                      onClick={() => updateGlobalPartyMode('off')}
                      className={cn(
                        "py-2 px-3 rounded-xl text-xs font-bold transition-all border",
                        globalPartyMode === 'off' 
                          ? "bg-white/20 border-white/40 text-white" 
                          : "bg-black/40 border-white/10 text-white/60 hover:bg-white/10"
                      )}
                    >
                      إيقاف
                    </button>
                    <button 
                      onClick={() => updateGlobalPartyMode('stars')}
                      className={cn(
                        "py-2 px-3 rounded-xl text-xs font-bold transition-all border",
                        globalPartyMode === 'stars' 
                          ? "bg-gradient-to-r from-yellow-400 to-orange-400 border-yellow-400 text-black" 
                          : "bg-yellow-500/20 border-yellow-500/30 text-yellow-300 hover:bg-yellow-500/30"
                      )}
                    >
                      ⭐ نجوم
                    </button>
                    <button 
                      onClick={() => updateGlobalPartyMode('hearts')}
                      className={cn(
                        "py-2 px-3 rounded-xl text-xs font-bold transition-all border",
                        globalPartyMode === 'hearts' 
                          ? "bg-gradient-to-r from-pink-500 to-red-500 border-pink-400 text-white" 
                          : "bg-pink-500/20 border-pink-500/30 text-pink-300 hover:bg-pink-500/30"
                      )}
                    >
                      ❤️ قلوب
                    </button>
                  </div>
                </div>
              </div>

              {/* Account Management Section */}
              <div className="rounded-2xl p-4 border" style={{
                background: 'linear-gradient(135deg, rgba(255,215,0,0.05) 0%, rgba(0,0,0,0.8) 100%)',
                borderColor: 'rgba(255, 215, 0, 0.2)',
              }}>
                <div className="flex items-center gap-2 mb-4">
                  <UserX className="size-5 text-amber-400" />
                  <span className="text-sm font-black text-amber-300">إدارة الحسابات</span>
                </div>
                <div className="space-y-3">
                  <div className="flex gap-2">
                    <input
                      type="text"
                      placeholder="ابحث بـ ID المستخدم..."
                      className="flex-1 bg-black/60 border border-amber-500/30 rounded-xl px-4 py-3 text-white placeholder:text-white/40 text-sm focus:outline-none focus:border-amber-400"
                      id="ban-user-search"
                    />
                    <button 
                      onClick={async () => {
                        const input = document.getElementById('ban-user-search') as HTMLInputElement;
                        if (input?.value?.trim()) {
                          try {
                            const res = await fetch(`/api/users/search?q=${encodeURIComponent(input.value.trim())}`);
                            const users = await res.json();
                            if (users.length > 0) {
                              setBanSearchResult(users[0]);
                              toast.success(`تم العثور على: ${users[0].displayName || users[0].username}`);
                            } else {
                              setBanSearchResult(null);
                              toast.error("لم يتم العثور على المستخدم");
                            }
                          } catch {
                            toast.error("حدث خطأ في البحث");
                          }
                        }
                      }}
                      className="px-4 py-3 bg-amber-500/20 border border-amber-500/40 rounded-xl text-amber-300 font-bold text-sm hover:bg-amber-500/30 transition-colors"
                    >
                      <Search className="size-5" />
                    </button>
                  </div>
                  
                  {banSearchResult && (
                    <div className="bg-black/40 border border-amber-500/30 rounded-xl p-3 flex items-center justify-between">
                      <div>
                        <div className="text-sm font-bold text-white">{banSearchResult.displayName || banSearchResult.username}</div>
                        <div className="text-[10px] text-white/60">ID: {banSearchResult.id}</div>
                        <div className={cn("text-[10px] font-bold", banSearchResult.isBanned ? "text-red-400" : "text-green-400")}>
                          {banSearchResult.isBanned ? "محظور حالياً" : "نشط"}
                        </div>
                      </div>
                      <button onClick={() => setBanSearchResult(null)} className="text-white/40 hover:text-white">
                        <X className="size-4" />
                      </button>
                    </div>
                  )}
                  
                  <button 
                    disabled={!banSearchResult || isBanning}
                    onClick={async () => {
                      if (!banSearchResult) {
                        toast.error("ابحث عن المستخدم أولاً");
                        return;
                      }
                      setIsBanning(true);
                      try {
                        const res = await fetch(`/api/admin/users/${banSearchResult.id}/ban`, {
                          method: 'POST',
                          headers: { 'Content-Type': 'application/json' },
                          body: JSON.stringify({ adminEmail: user?.email, banned: !banSearchResult.isBanned }),
                        });
                        const data = await res.json();
                        if (data.success) {
                          const action = banSearchResult.isBanned ? 'فك الحظر عن' : 'حظر';
                          toast.success(`تم ${action} المستخدم ${banSearchResult.displayName} 🚫`);
                          setBanSearchResult(null);
                          const input = document.getElementById('ban-user-search') as HTMLInputElement;
                          if (input) input.value = '';
                        } else {
                          toast.error(data.error || "حدث خطأ");
                        }
                      } catch {
                        toast.error("حدث خطأ في الاتصال");
                      } finally {
                        setIsBanning(false);
                      }
                    }}
                    className={cn(
                      "w-full py-3 rounded-xl text-white font-bold text-sm flex items-center justify-center gap-2 transition-all border",
                      banSearchResult?.isBanned 
                        ? "bg-gradient-to-r from-green-600 to-green-700 border-green-500/50 hover:from-green-700 hover:to-green-800"
                        : "bg-gradient-to-r from-red-600 to-red-700 border-red-500/50 hover:from-red-700 hover:to-red-800",
                      (!banSearchResult || isBanning) && "opacity-50 cursor-not-allowed"
                    )}
                  >
                    <Ban className="size-4" />
                    {isBanning ? "جاري التنفيذ..." : banSearchResult?.isBanned ? "فك الحظر" : "حظر نهائي من التطبيق"}
                  </button>
                </div>
              </div>

              {/* Broadcast Message Section */}
              <div className="rounded-2xl p-4 border" style={{
                background: 'linear-gradient(135deg, rgba(255,215,0,0.05) 0%, rgba(0,0,0,0.8) 100%)',
                borderColor: 'rgba(255, 215, 0, 0.2)',
              }}>
                <div className="flex items-center gap-2 mb-4">
                  <Megaphone className="size-5 text-amber-400" />
                  <span className="text-sm font-black text-amber-300">رسالة عامة للجميع</span>
                </div>
                <div className="space-y-3">
                  <textarea
                    placeholder="اكتب رسالتك التي ستظهر لجميع المستخدمين..."
                    className="w-full bg-black/60 border border-amber-500/30 rounded-xl px-4 py-3 text-white placeholder:text-white/40 text-sm focus:outline-none focus:border-amber-400 resize-none h-24"
                    id="broadcast-message"
                  />
                  <button 
                    disabled={isSendingBroadcast}
                    onClick={async () => {
                      const textarea = document.getElementById('broadcast-message') as HTMLTextAreaElement;
                      if (textarea?.value?.trim()) {
                        setIsSendingBroadcast(true);
                        try {
                          const res = await fetch('/api/admin/broadcast', {
                            method: 'POST',
                            headers: { 'Content-Type': 'application/json' },
                            body: JSON.stringify({
                              adminEmail: user?.email,
                              message: textarea.value.trim(),
                              expiresInMinutes: 60,
                            }),
                          });
                          const data = await res.json();
                          if (data.success) {
                            toast.success("تم إرسال الرسالة العامة لجميع المستخدمين 📢");
                            textarea.value = '';
                          } else {
                            toast.error(data.error || "حدث خطأ");
                          }
                        } catch {
                          toast.error("حدث خطأ في الاتصال");
                        } finally {
                          setIsSendingBroadcast(false);
                        }
                      } else {
                        toast.error("اكتب رسالة أولاً");
                      }
                    }}
                    className={cn(
                      "w-full py-3 rounded-xl text-black font-bold text-sm flex items-center justify-center gap-2 transition-all",
                      isSendingBroadcast && "opacity-50 cursor-not-allowed"
                    )}
                    style={{
                      background: 'linear-gradient(135deg, #ffd700 0%, #ffed4a 50%, #ffd700 100%)',
                    }}
                  >
                    <Send className="size-4" />
                    {isSendingBroadcast ? "جاري الإرسال..." : "إرسال للجميع الآن"}
                  </button>
                </div>
              </div>

              {/* Notifications Section */}
              {ownerNotifications.length > 0 && (
                <div className="rounded-2xl p-4 border" style={{
                  background: 'linear-gradient(135deg, rgba(255,215,0,0.05) 0%, rgba(0,0,0,0.8) 100%)',
                  borderColor: 'rgba(255, 215, 0, 0.2)',
                }}>
                  <div className="flex items-center gap-2 mb-3">
                    <Bell className="size-4 text-amber-400" />
                    <span className="text-sm font-bold text-amber-300">تنبيهات المشرفين ({ownerNotifications.filter(n => !n.read).length})</span>
                  </div>
                  <div className="space-y-2">
                    {ownerNotifications.slice(0, 5).map((notif) => (
                      <div key={notif.id} className={cn(
                        "p-3 rounded-xl text-xs border",
                        notif.read ? "bg-black/40 text-white/60 border-white/10" : "bg-amber-500/10 text-amber-200 border-amber-500/30"
                      )}>
                        <div className="flex items-center justify-between">
                          <span>{notif.message}</span>
                          <span className="text-[10px] text-white/40">{new Date(notif.timestamp).toLocaleTimeString('ar-EG')}</span>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Action Logs */}
              <div className="rounded-2xl p-4 border" style={{
                background: 'linear-gradient(135deg, rgba(255,215,0,0.05) 0%, rgba(0,0,0,0.8) 100%)',
                borderColor: 'rgba(255, 215, 0, 0.2)',
              }}>
                <div className="flex items-center gap-2 mb-4">
                  <ScrollText className="size-5 text-amber-400" />
                  <span className="text-sm font-black text-amber-300">سجل الأحداث</span>
                </div>
                
                {adminActionLogs.length === 0 ? (
                  <div className="text-center py-8 text-white/40">
                    <Activity className="size-8 mx-auto mb-2 opacity-50" />
                    <p className="text-sm">لا توجد أحداث مسجلة حتى الآن</p>
                    <p className="text-[10px] mt-1">سيتم تسجيل عمليات الطرد، الكتم، وتعيين المشرفين</p>
                  </div>
                ) : (
                  <div className="space-y-2 max-h-[40vh] overflow-y-auto">
                    {adminActionLogs.map((log) => (
                      <div 
                        key={log.id}
                        className={cn(
                          "p-3 rounded-xl border",
                          log.actionType === 'kick' && "bg-rose-500/10 border-rose-500/30",
                          log.actionType === 'mute' && "bg-amber-500/10 border-amber-500/30",
                          log.actionType === 'admin' && "bg-purple-500/10 border-purple-500/30",
                          log.actionType === 'settings' && "bg-blue-500/10 border-blue-500/30"
                        )}
                      >
                        <div className="flex items-start justify-between">
                          <div>
                            <div className="text-sm font-bold text-white">{log.action}</div>
                            <div className="text-[10px] text-white/60 mt-1">
                              بواسطة: {log.performedBy} {log.targetUser && `• الهدف: ${log.targetUser}`}
                            </div>
                            <div className="text-[10px] text-white/40">الغرفة: {log.roomName}</div>
                          </div>
                          <div className="text-[10px] text-white/40">
                            {new Date(log.timestamp).toLocaleString('ar-EG')}
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
      <AnimatePresence>{showWallet && <WalletView coins={coins} isOwner={isOwner} userId={user?.id || ""} onAddCoins={(amount) => setCoins(prev => prev + amount)} onBack={() => setShowWallet(false)} />}</AnimatePresence>
      <AnimatePresence>{showCreateRoom && <CreateRoomModal onClose={() => setShowCreateRoom(false)} onCreate={handleCreateRoom} />}</AnimatePresence>

      {/* New Top Header with Tabs */}
      <header className="sticky top-0 bg-white z-40 border-b border-gray-100">
        {/* Top Row: Logo + Icons */}
        <div className="px-4 py-3 flex items-center justify-between">
          {/* Left Side - Icons */}
          <div className="flex items-center gap-2">
            <Button onClick={() => setShowWallet(true)} variant="ghost" size="sm" className="bg-yellow-500/10 text-yellow-600 rounded-full px-3 h-8 gap-1 font-bold text-xs">
              <Gem className="size-3.5 fill-yellow-500" />
              {coins.toLocaleString()}
            </Button>
          </div>
          
          {/* Center - Top Tabs (RTL order: أشخاص، غرفة، لعبة، اكتشاف) */}
          <div className="flex gap-4">
            {["أشخاص", "غرفة", "لعبة", "اكتشاف"].map((tab) => (
              <button 
                key={tab}
                onClick={() => setSelectedCategory(tab === "غرفة" ? "الكل" : tab)}
                className={cn(
                  "text-sm font-bold transition-colors",
                  (tab === "غرفة" && selectedCategory === "الكل") || selectedCategory === tab
                    ? "text-gray-900" 
                    : "text-gray-400"
                )}
              >
                {tab}
              </button>
            ))}
          </div>
          
          {/* Right Side - Search & Carnival Icons */}
          <div className="flex items-center gap-2">
            <button onClick={() => setShowSearchResults(true)} className="size-9 rounded-full bg-gray-100 flex items-center justify-center">
              <Search className="size-4 text-gray-600" />
            </button>
            <button className="size-9 rounded-full bg-purple-100 flex items-center justify-center">
              <ScrollText className="size-4 text-purple-600" />
            </button>
          </div>
        </div>
        
        {/* Category Bar */}
        <div className="px-4 pb-3 flex gap-2 overflow-x-auto no-scrollbar">
          {["ترند", "تم انضمام", "لودو", "فقرات", "القرآن", "لعبة", "أصدقاء"].map((cat) => (
            <button 
              key={cat}
              onClick={() => setSelectedCategory(cat === "ترند" ? "الكل" : cat)}
              className={cn(
                "px-4 py-1.5 rounded-full text-xs font-bold whitespace-nowrap transition-all border",
                selectedCategory === cat || (cat === "ترند" && selectedCategory === "الكل")
                  ? "bg-purple-600 text-white border-purple-600"
                  : "bg-white text-gray-600 border-gray-200 hover:border-purple-300"
              )}
            >
              {cat}
            </button>
          ))}
        </div>
      </header>
      
      {/* Search Overlay */}
      <AnimatePresence>
        {showSearchResults && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 bg-white"
          >
            <div className="p-4">
              <div className="flex items-center gap-3 mb-4">
                <button onClick={() => setShowSearchResults(false)} className="size-10 rounded-full bg-gray-100 flex items-center justify-center">
                  <X className="size-5 text-gray-600" />
                </button>
                <div className="flex-1 relative">
                  <Search className="absolute right-3 top-1/2 -translate-y-1/2 size-4 text-gray-400" />
                  <Input
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    placeholder="ابحث بالـ ID أو اسم المستخدم..."
                    className="w-full bg-gray-100 border-0 rounded-full h-10 pr-10 text-gray-900"
                    autoFocus
                  />
                </div>
              </div>
              
              {isSearchingUsers ? (
                <div className="py-12 text-center text-gray-500">
                  <div className="animate-spin size-6 border-2 border-purple-500 border-t-transparent rounded-full mx-auto mb-2" />
                  <span className="text-sm">جاري البحث...</span>
                </div>
              ) : userSearchResults.length > 0 ? (
                <div className="space-y-2">
                  {userSearchResults.map((foundUser) => (
                    <button
                      key={foundUser.id}
                      onClick={() => {
                        toast.success(`تم العثور على: ${foundUser.displayName || foundUser.username}`);
                        setSearchQuery("");
                        setShowSearchResults(false);
                      }}
                      className="w-full flex items-center gap-3 p-3 bg-gray-50 rounded-2xl hover:bg-gray-100 transition-colors"
                    >
                      <Avatar className="size-12">
                        <AvatarImage src={foundUser.avatar || `https://api.dicebear.com/7.x/avataaars/svg?seed=${foundUser.id}`} />
                        <AvatarFallback className="bg-purple-500 text-white font-bold">
                          {(foundUser.displayName || foundUser.username || "U").charAt(0)}
                        </AvatarFallback>
                      </Avatar>
                      <div className="flex-1 text-right">
                        <div className="font-bold text-gray-900">{foundUser.displayName || foundUser.username}</div>
                        <div className="text-xs text-gray-400">ID: {(foundUser as any).shortId || "1"}</div>
                      </div>
                    </button>
                  ))}
                </div>
              ) : searchQuery ? (
                <div className="py-12 text-center text-gray-400">
                  <User className="size-10 mx-auto mb-2 opacity-50" />
                  <span className="text-sm">لم يتم العثور على نتائج</span>
                </div>
              ) : (
                <div className="py-12 text-center text-gray-400">
                  <Search className="size-10 mx-auto mb-2 opacity-50" />
                  <span className="text-sm">ابحث عن مستخدم أو غرفة</span>
                </div>
              )}
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      <main className="pb-28 bg-gray-50">
        {/* Trend Section - Top 4 Rooms in 2x2 Grid */}
        <div className="px-4 mt-4">
          <div className="flex items-center justify-between mb-3">
            <div className="flex items-center gap-2">
              <span className="text-lg">🔥</span>
              <h3 className="text-base font-black text-gray-800">ترند</h3>
            </div>
            <button 
              onClick={() => setShowCreateRoom(true)}
              className="text-xs text-purple-600 font-bold flex items-center gap-1"
            >
              <Plus className="size-3" />
              إنشاء غرفة
            </button>
          </div>
          
          {isLoadingRooms ? (
            <div className="flex items-center justify-center py-12">
              <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-purple-500" />
            </div>
          ) : (
            <div className="grid grid-cols-2 gap-2">
              {/* Top 4 Trend Rooms - 2x2 Grid with Rank Badges */}
              {(filteredRooms.length > 0 ? filteredRooms.slice(0, 4) : [
                { id: "demo1", title: "غرفة المرح", category: "لودو", listeners: 130, host: { name: "أحمد", avatar: "https://api.dicebear.com/7.x/avataaars/svg?seed=demo1" }},
                { id: "demo2", title: "أصدقاء للأبد", category: "أصدقاء", listeners: 86, host: { name: "سارة", avatar: "https://api.dicebear.com/7.x/avataaars/svg?seed=demo2" }},
                { id: "demo3", title: "ليالي رومانسية", category: "رومانسي", listeners: 64, host: { name: "نور", avatar: "https://api.dicebear.com/7.x/avataaars/svg?seed=demo3" }},
                { id: "demo4", title: "عائلة السعادة", category: "عائلة", listeners: 52, host: { name: "محمد", avatar: "https://api.dicebear.com/7.x/avataaars/svg?seed=demo4" }},
              ]).map((room: any, idx: number) => {
                const categoryColors: Record<string, string> = {
                  "لودو": "bg-green-500",
                  "أصدقاء": "bg-blue-500",
                  "رومانسي": "bg-pink-500",
                  "عائلة": "bg-amber-500",
                  "القرآن": "bg-emerald-600",
                  "فقرات": "bg-purple-500"
                };
                const rankBadges = ["🥇", "🥈", "🥉", "4️⃣"];
                
                return (
                  <div 
                    key={room.id}
                    onClick={() => { if (filteredRooms.length > 0) { setCurrentRoom(room); setInRoom(true); }}}
                    className="relative rounded-2xl overflow-hidden h-36 cursor-pointer group"
                  >
                    <img 
                      src={(room as any).image || `https://picsum.photos/seed/${room.id}/200/200`} 
                      className="absolute inset-0 w-full h-full object-cover group-hover:scale-105 transition-transform duration-300" 
                      alt="" 
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/30 to-transparent" />
                    
                    {/* Rank Badge */}
                    <div className="absolute top-2 left-2 text-xl drop-shadow-lg">
                      {rankBadges[idx]}
                    </div>
                    
                    {/* Category Label */}
                    <div className={cn(
                      "absolute top-2 right-2 text-[9px] font-bold text-white px-2 py-0.5 rounded-full",
                      categoryColors[room.category] || "bg-gray-500"
                    )}>
                      {room.category || "عام"}
                    </div>
                    
                    {/* Listeners Count */}
                    <div className="absolute top-8 right-2 flex items-center gap-1 bg-black/50 text-white text-[10px] font-bold px-1.5 py-0.5 rounded-full backdrop-blur-sm">
                      <Users className="size-3" />
                      {room.listeners || Math.floor(Math.random() * 100) + 50}
                    </div>
                    
                    {/* Room Info */}
                    <div className="absolute bottom-0 left-0 right-0 p-2">
                      <h4 className="text-white font-bold text-xs line-clamp-1">{room.title}</h4>
                      <div className="flex items-center gap-1 mt-0.5">
                        <Avatar className="size-4 border border-white/30">
                          <AvatarImage src={room.host?.avatar} />
                          <AvatarFallback className="text-[8px]">{room.host?.name?.charAt(0)}</AvatarFallback>
                        </Avatar>
                        <span className="text-white/70 text-[9px]">{room.host?.name}</span>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>

        {/* Activity Banners - Colored Sections */}
        <div className="px-4 mt-4 flex gap-2">
          {/* Anonymous Chat - Purple */}
          <button 
            onClick={() => toast.info("الدردشة المجهولة قريباً!")}
            className="flex-1 h-20 rounded-2xl relative overflow-hidden"
          >
            <div className="absolute inset-0 bg-gradient-to-br from-purple-600 to-violet-700" />
            <div className="absolute inset-0 p-3 flex flex-col justify-center">
              <span className="text-lg mb-0.5">👻</span>
              <h4 className="text-white font-black text-sm">دردشة مجهولة</h4>
            </div>
          </button>
          
          {/* Dating - Pink */}
          <button 
            onClick={() => toast.info("مواعدة سي بي قريباً!")}
            className="flex-1 h-20 rounded-2xl relative overflow-hidden"
          >
            <div className="absolute inset-0 bg-gradient-to-br from-pink-500 to-rose-500" />
            <div className="absolute inset-0 p-3 flex flex-col justify-center">
              <span className="text-lg mb-0.5">💕</span>
              <h4 className="text-white font-black text-sm">مواعدة سي بي</h4>
            </div>
          </button>
        </div>

        {/* New Rooms Section with Country Selector */}
        <div className="px-4 mt-6">
          <div className="flex items-center justify-between mb-3">
            <div className="flex items-center gap-2">
              <Globe className="size-5 text-purple-600" />
              <h3 className="text-base font-black text-gray-800">جديدة</h3>
            </div>
            <button className="flex items-center gap-1 bg-gray-100 px-3 py-1.5 rounded-full text-xs font-bold text-gray-700">
              <span>العراق</span>
              <span>🇮🇶</span>
              <ChevronLeft className="size-3" />
            </button>
          </div>
          
          {/* 3x3 Dense Grid */}
          <div className="grid grid-cols-3 gap-2">
            {(filteredRooms.length > 4 ? filteredRooms.slice(4) : [
              { id: "new1", title: "سهرة الليل", category: "لودو", listeners: 42, host: { name: "علي", avatar: "https://api.dicebear.com/7.x/avataaars/svg?seed=new1" }},
              { id: "new2", title: "قلوب حائرة", category: "رومانسي", listeners: 35, host: { name: "ليلى", avatar: "https://api.dicebear.com/7.x/avataaars/svg?seed=new2" }},
              { id: "new3", title: "شباب العراق", category: "أصدقاء", listeners: 28, host: { name: "كرار", avatar: "https://api.dicebear.com/7.x/avataaars/svg?seed=new3" }},
              { id: "new4", title: "عائلة الخير", category: "عائلة", listeners: 24, host: { name: "زهراء", avatar: "https://api.dicebear.com/7.x/avataaars/svg?seed=new4" }},
              { id: "new5", title: "تلاوات", category: "القرآن", listeners: 56, host: { name: "حسين", avatar: "https://api.dicebear.com/7.x/avataaars/svg?seed=new5" }},
              { id: "new6", title: "ضحك ومرح", category: "فقرات", listeners: 31, host: { name: "مريم", avatar: "https://api.dicebear.com/7.x/avataaars/svg?seed=new6" }},
            ]).map((room: any) => {
              const categoryColors: Record<string, string> = {
                "لودو": "bg-green-500",
                "أصدقاء": "bg-blue-500",
                "رومانسي": "bg-pink-500",
                "عائلة": "bg-amber-500",
                "القرآن": "bg-emerald-600",
                "فقرات": "bg-purple-500"
              };
              
              return (
                <div 
                  key={room.id}
                  onClick={() => { if (filteredRooms.length > 4) { setCurrentRoom(room); setInRoom(true); }}}
                  className="relative rounded-xl overflow-hidden h-28 cursor-pointer group"
                >
                  <img 
                    src={(room as any).image || `https://picsum.photos/seed/${room.id}/150/150`} 
                    className="absolute inset-0 w-full h-full object-cover group-hover:scale-105 transition-transform duration-300" 
                    alt="" 
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/30 to-transparent" />
                  
                  {/* Category Label */}
                  <div className={cn(
                    "absolute top-1.5 right-1.5 text-[8px] font-bold text-white px-1.5 py-0.5 rounded-full",
                    categoryColors[room.category] || "bg-gray-500"
                  )}>
                    {room.category || "عام"}
                  </div>
                  
                  {/* Listeners */}
                  <div className="absolute top-1.5 left-1.5 flex items-center gap-0.5 bg-black/50 text-white text-[9px] font-bold px-1 py-0.5 rounded-full backdrop-blur-sm">
                    <Users className="size-2.5" />
                    {room.listeners || Math.floor(Math.random() * 50) + 10}
                  </div>
                  
                  {/* Room Info */}
                  <div className="absolute bottom-0 left-0 right-0 p-1.5">
                    <h4 className="text-white font-bold text-[10px] line-clamp-1">{room.title}</h4>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </main>

      {/* New Bottom Navigation */}
      <nav className="fixed bottom-0 left-0 right-0 h-20 bg-white border-t border-gray-100 flex items-center justify-around px-4 z-50 shadow-lg shadow-black/5">
        {/* Home */}
        <button 
          onClick={() => { setActiveTab("home"); window.scrollTo({ top: 0, behavior: "smooth" }); }} 
          className={cn("flex flex-col items-center gap-1 min-w-[50px]", activeTab === "home" ? "text-gray-900" : "text-gray-400")}
        >
          <Home className="size-6" />
          <span className="text-[10px] font-bold">الرئيسية</span>
        </button>
        
        {/* Forum */}
        <button 
          onClick={() => setShowForum(true)} 
          className="flex flex-col items-center gap-1 min-w-[50px] text-gray-400"
        >
          <LayoutGrid className="size-6" />
          <span className="text-[10px] font-bold">المنتدى</span>
        </button>
        
        {/* My Room - Center Purple Button */}
        <button 
          onClick={() => { setCurrentRoom(null); setInRoom(true); }} 
          className="relative -top-5"
        >
          <div className="size-16 rounded-full bg-gradient-to-tr from-purple-600 to-violet-500 shadow-xl shadow-purple-500/30 flex items-center justify-center ring-4 ring-white active:scale-95 transition-transform">
            <Plus className="size-8 text-white" />
          </div>
          <span className="absolute -bottom-4 left-1/2 -translate-x-1/2 text-[10px] font-black text-purple-600 whitespace-nowrap">غرفتي</span>
        </button>
        
        {/* Messages */}
        <button 
          onClick={() => setShowMessages(true)} 
          className="flex flex-col items-center gap-1 min-w-[50px] text-gray-400 relative"
        >
          <MsgCircle className="size-6" />
          <div className="absolute -top-1 right-1 bg-rose-500 text-white text-[9px] font-black min-w-[18px] h-[18px] flex items-center justify-center rounded-full">53</div>
          <span className="text-[10px] font-bold">رسالة</span>
        </button>
        
        {/* Me */}
        <button 
          onClick={() => setShowProfile(true)} 
          className={cn("flex flex-col items-center gap-1 min-w-[50px]", activeTab === "me" ? "text-gray-900" : "text-gray-400")}
        >
          <User className="size-6" />
          <span className="text-[10px] font-bold">أنا</span>
        </button>
      </nav>
    </div>
  );
}
