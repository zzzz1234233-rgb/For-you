import { Link } from "wouter";
import { Button } from "@/components/ui/button";

export default function NotFound() {
  return (
    <div
      className="min-h-dvh hello-noise grid place-items-center px-6"
      data-testid="page-not-found"
    >
      <div className="hello-glass rounded-3xl p-6 text-center max-w-md">
        <div className="text-xs text-muted-foreground" data-testid="text-404-label">
          404
        </div>
        <div className="mt-2 text-2xl font-extrabold" data-testid="text-404-title">
          الصفحة غير موجودة
        </div>
        <p className="mt-2 text-sm text-muted-foreground" data-testid="text-404-desc">
          الرابط غير صحيح أو تم نقل الصفحة.
        </p>
        <Button asChild className="mt-5 rounded-2xl" data-testid="button-go-home">
          <Link href="/" data-testid="link-home">
            العودة للرئيسية
          </Link>
        </Button>
      </div>
    </div>
  );
}
