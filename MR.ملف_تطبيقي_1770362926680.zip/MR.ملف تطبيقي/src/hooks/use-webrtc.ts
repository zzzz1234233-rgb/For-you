import { useRef, useState, useCallback, useEffect } from "react";

const ICE_SERVERS = [
  { urls: "stun:stun.l.google.com:19302" },
  { urls: "stun:stun1.l.google.com:19302" },
  { urls: "stun:stun2.l.google.com:19302" },
];

interface Participant {
  userId: number;
  slotNumber: number;
  displayName: string;
  avatar: string;
  hasVipFrame?: boolean;
  isOwner?: boolean;
  role?: string;
  stream?: MediaStream;
  isMuted?: boolean;
}

interface UseWebRTCOptions {
  roomId: string;
  userId: number;
  displayName: string;
  avatar: string;
  hasVipFrame?: boolean;
  isOwner?: boolean;
  role?: string;
  onParticipantJoined?: (participant: Participant) => void;
  onParticipantLeft?: (userId: number, slotNumber: number) => void;
  onMuteStatusChanged?: (userId: number, isMuted: boolean) => void;
}

export function useWebRTC(options: UseWebRTCOptions) {
  const wsRef = useRef<WebSocket | null>(null);
  const localStreamRef = useRef<MediaStream | null>(null);
  const peerConnectionsRef = useRef<Map<number, RTCPeerConnection>>(new Map());
  const [isConnected, setIsConnected] = useState(false);
  const [participants, setParticipants] = useState<Map<number, Participant>>(new Map());
  const [mySlot, setMySlot] = useState<number | null>(null);
  const [isMuted, setIsMuted] = useState(false);
  const audioContextRef = useRef<AudioContext | null>(null);
  const analyserRef = useRef<AnalyserNode | null>(null);
  const [isSpeaking, setIsSpeaking] = useState(false);

  const getWebSocketUrl = useCallback(() => {
    const protocol = window.location.protocol === "https:" ? "wss:" : "ws:";
    return `${protocol}//${window.location.host}/ws`;
  }, []);

  const createPeerConnection = useCallback((targetUserId: number): RTCPeerConnection => {
    const pc = new RTCPeerConnection({ iceServers: ICE_SERVERS });

    pc.onicecandidate = (event) => {
      if (event.candidate && wsRef.current?.readyState === WebSocket.OPEN) {
        wsRef.current.send(JSON.stringify({
          type: "ice-candidate",
          targetUserId,
          candidate: event.candidate,
          roomId: options.roomId,
        }));
      }
    };

    pc.ontrack = (event) => {
      setParticipants((prev) => {
        const updated = new Map(prev);
        const existing = updated.get(targetUserId);
        if (existing) {
          updated.set(targetUserId, { ...existing, stream: event.streams[0] });
        }
        return updated;
      });

      const audio = new Audio();
      audio.srcObject = event.streams[0];
      audio.autoplay = true;
      audio.play().catch(console.error);
    };

    if (localStreamRef.current) {
      localStreamRef.current.getTracks().forEach((track) => {
        pc.addTrack(track, localStreamRef.current!);
      });
    }

    peerConnectionsRef.current.set(targetUserId, pc);
    return pc;
  }, [options.roomId]);

  const joinMic = useCallback(async (slotNumber: number) => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      localStreamRef.current = stream;
      setMySlot(slotNumber);

      const audioContext = new AudioContext();
      const analyser = audioContext.createAnalyser();
      const source = audioContext.createMediaStreamSource(stream);
      source.connect(analyser);
      analyser.fftSize = 256;
      audioContextRef.current = audioContext;
      analyserRef.current = analyser;

      const wsUrl = getWebSocketUrl();
      const ws = new WebSocket(wsUrl);
      wsRef.current = ws;

      ws.onopen = () => {
        setIsConnected(true);
        ws.send(JSON.stringify({
          type: "join-room",
          roomId: options.roomId,
          userId: options.userId,
          slotNumber,
          displayName: options.displayName,
          avatar: options.avatar,
          hasVipFrame: options.hasVipFrame,
          isOwner: options.isOwner,
          role: options.role,
        }));
      };

      ws.onmessage = async (event) => {
        const message = JSON.parse(event.data);

        switch (message.type) {
          case "existing-user":
          case "user-joined": {
            const { userId, slotNumber: slot, displayName, avatar, hasVipFrame, isOwner, role } = message;
            setParticipants((prev) => {
              const updated = new Map(prev);
              updated.set(userId, { userId, slotNumber: slot, displayName, avatar, hasVipFrame, isOwner, role });
              return updated;
            });
            options.onParticipantJoined?.({ userId, slotNumber: slot, displayName, avatar, hasVipFrame, isOwner, role });

            if (message.type === "user-joined" || message.type === "existing-user") {
              const pc = createPeerConnection(userId);
              const offer = await pc.createOffer();
              await pc.setLocalDescription(offer);
              ws.send(JSON.stringify({
                type: "offer",
                targetUserId: userId,
                sdp: offer,
                roomId: options.roomId,
              }));
            }
            break;
          }

          case "offer": {
            const { fromUserId, sdp } = message;
            let pc = peerConnectionsRef.current.get(fromUserId);
            if (!pc) {
              pc = createPeerConnection(fromUserId);
            }
            await pc.setRemoteDescription(new RTCSessionDescription(sdp));
            const answer = await pc.createAnswer();
            await pc.setLocalDescription(answer);
            ws.send(JSON.stringify({
              type: "answer",
              targetUserId: fromUserId,
              sdp: answer,
              roomId: options.roomId,
            }));
            break;
          }

          case "answer": {
            const { fromUserId, sdp } = message;
            const pc = peerConnectionsRef.current.get(fromUserId);
            if (pc) {
              await pc.setRemoteDescription(new RTCSessionDescription(sdp));
            }
            break;
          }

          case "ice-candidate": {
            const { fromUserId, candidate } = message;
            const pc = peerConnectionsRef.current.get(fromUserId);
            if (pc && candidate) {
              await pc.addIceCandidate(new RTCIceCandidate(candidate));
            }
            break;
          }

          case "user-left": {
            const { userId, slotNumber: slot } = message;
            const pc = peerConnectionsRef.current.get(userId);
            if (pc) {
              pc.close();
              peerConnectionsRef.current.delete(userId);
            }
            setParticipants((prev) => {
              const updated = new Map(prev);
              updated.delete(userId);
              return updated;
            });
            options.onParticipantLeft?.(userId, slot);
            break;
          }

          case "mute-status": {
            const { userId, isMuted: muted } = message;
            setParticipants((prev) => {
              const updated = new Map(prev);
              const existing = updated.get(userId);
              if (existing) {
                updated.set(userId, { ...existing, isMuted: muted });
              }
              return updated;
            });
            options.onMuteStatusChanged?.(userId, muted);
            break;
          }
        }
      };

      ws.onclose = () => {
        setIsConnected(false);
      };

      ws.onerror = (error) => {
        console.error("WebSocket error:", error);
      };

      const checkSpeaking = () => {
        if (analyserRef.current) {
          const dataArray = new Uint8Array(analyserRef.current.frequencyBinCount);
          analyserRef.current.getByteFrequencyData(dataArray);
          const average = dataArray.reduce((a, b) => a + b, 0) / dataArray.length;
          setIsSpeaking(average > 30);
        }
        if (mySlot !== null) {
          requestAnimationFrame(checkSpeaking);
        }
      };
      checkSpeaking();

      return true;
    } catch (err) {
      console.error("Failed to join mic:", err);
      return false;
    }
  }, [options, getWebSocketUrl, createPeerConnection]);

  const leaveMic = useCallback(() => {
    if (wsRef.current?.readyState === WebSocket.OPEN) {
      wsRef.current.send(JSON.stringify({ type: "leave-room" }));
      wsRef.current.close();
    }
    wsRef.current = null;

    if (localStreamRef.current) {
      localStreamRef.current.getTracks().forEach((track) => track.stop());
      localStreamRef.current = null;
    }

    peerConnectionsRef.current.forEach((pc) => pc.close());
    peerConnectionsRef.current.clear();

    if (audioContextRef.current) {
      audioContextRef.current.close();
      audioContextRef.current = null;
    }

    setParticipants(new Map());
    setMySlot(null);
    setIsConnected(false);
    setIsSpeaking(false);
  }, []);

  const toggleMute = useCallback(() => {
    if (localStreamRef.current) {
      const audioTrack = localStreamRef.current.getAudioTracks()[0];
      if (audioTrack) {
        audioTrack.enabled = !audioTrack.enabled;
        const newMuteState = !audioTrack.enabled;
        setIsMuted(newMuteState);

        if (wsRef.current?.readyState === WebSocket.OPEN) {
          wsRef.current.send(JSON.stringify({
            type: "mute-status",
            userId: options.userId,
            isMuted: newMuteState,
            roomId: options.roomId,
          }));
        }
      }
    }
  }, [options.userId, options.roomId]);

  useEffect(() => {
    return () => {
      leaveMic();
    };
  }, [leaveMic]);

  return {
    isConnected,
    participants,
    mySlot,
    isMuted,
    isSpeaking,
    joinMic,
    leaveMic,
    toggleMute,
  };
}
